from flask import Blueprint, render_template, abort
from app.models import Article

blog_bp = Blueprint('blog', __name__)


@blog_bp.route('/')
def index():
    articles = Article.query.filter_by(published=True).order_by(Article.created_at.desc()).all()
    return render_template('blog/index.html', articles=articles)


@blog_bp.route('/<int:aid>')
def detail(aid):
    a = Article.query.get_or_404(aid)
    if not a.published:
        abort(404)
    recent = (Article.query.filter_by(published=True)
              .filter(Article.id != aid)
              .order_by(Article.created_at.desc()).limit(3).all())
    return render_template('blog/detail.html', a=a, recent=recent)
