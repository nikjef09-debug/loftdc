import secrets, os
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, flash, session
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import User, Wishlist, Product, PasswordResetToken
from app.email_service import send_password_reset

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        from app.security import check_login_rate_limit, record_login_attempt
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        # Проверяем rate limit
        allowed, wait_sec = check_login_rate_limit(email)
        if not allowed:
            mins = wait_sec // 60 + 1
            flash(f'Слишком много попыток входа. Попробуйте через {mins} мин.', 'error')
            return render_template('auth/login.html')

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password) and user.is_active:
            record_login_attempt(email, success=True)
            login_user(user, remember=True)
            user.last_login = datetime.utcnow()
            db.session.commit()
            next_page = request.args.get('next') or (
                url_for('admin.dashboard') if user.is_manager else url_for('main.index')
            )
            flash(f'Добро пожаловать, {user.name.split()[0]}!', 'success')
            return redirect(next_page)

        record_login_attempt(email, success=False)
        # Считаем сколько попыток осталось
        _, _ = check_login_rate_limit(email)
        from app.models import LoginAttempt
        from datetime import timedelta
        fails = LoginAttempt.query.filter(
            LoginAttempt.ip == request.remote_addr,
            LoginAttempt.success == False,
            LoginAttempt.created_at >= datetime.utcnow() - timedelta(minutes=10)
        ).count()
        left = max(0, 5 - fails)
        if left > 0:
            flash(f'Неверный email или пароль. Осталось попыток: {left}', 'error')
        else:
            flash('Аккаунт заблокирован на 15 минут из-за множества неудачных попыток.', 'error')
    return render_template('auth/login.html')


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        name     = (request.form.get('name','').strip()+' '+request.form.get('surname','').strip()).strip()
        email    = request.form.get('email','').strip()
        phone    = request.form.get('phone','').strip()
        password = request.form.get('password','')
        password2= request.form.get('password2','')

        errors = []
        if not name:            errors.append('Введите имя.')
        if len(password) < 6:  errors.append('Пароль минимум 6 символов.')
        if password != password2: errors.append('Пароли не совпадают.')
        if User.query.filter_by(email=email).first(): errors.append('Email уже зарегистрирован.')
        if 'agree_terms' not in request.form:   errors.append('Необходимо принять пользовательское соглашение.')
        if 'agree_privacy' not in request.form: errors.append('Необходимо дать согласие на обработку персональных данных.')

        if errors:
            for e in errors: flash(e, 'error')
        else:
            user = User(name=name, email=email, phone=phone)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user, remember=True)
            flash('Регистрация прошла успешно!', 'success')
            return redirect(url_for('main.index'))

    return render_template('auth/register.html')


@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из аккаунта.', 'info')
    return redirect(url_for('main.index'))


@auth_bp.route('/profile')
@login_required
def profile():
    orders = current_user.orders.order_by(db.text('created_at DESC')).all()
    wl_ids = [w.product_id for w in current_user.wishlist.all()]
    wishlist_products = Product.query.filter(Product.id.in_(wl_ids)).all()
    return render_template('auth/profile.html', orders=orders, wishlist=wishlist_products)


@auth_bp.route('/profile/save', methods=['POST'])
@login_required
def profile_save():
    current_user.name    = request.form.get('name', current_user.name).strip()
    current_user.phone   = request.form.get('phone', current_user.phone).strip()
    current_user.address = request.form.get('address', current_user.address).strip()
    new_pw = request.form.get('password', '')
    if new_pw:
        if len(new_pw) < 6:
            flash('Пароль минимум 6 символов.', 'error')
            return redirect(url_for('auth.profile'))
        current_user.set_password(new_pw)
    db.session.commit()
    flash('Настройки сохранены.', 'success')
    return redirect(url_for('auth.profile'))


# ─── Сброс пароля ────────────────────────────────────────────────────────────

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        user  = User.query.filter_by(email=email).first()
        # Одно сообщение для всех — защита от перебора email
        flash('Если этот email зарегистрирован, вы получите письмо со ссылкой.', 'info')
        if user:
            # Удаляем старые токены этого пользователя
            PasswordResetToken.query.filter_by(user_id=user.id).delete()
            # Создаём новый токен в БД
            token = secrets.token_urlsafe(48)
            db.session.add(PasswordResetToken(user_id=user.id, token=token))
            db.session.commit()
            # Формируем ссылку через url_for — Flask сам подставит правильный префикс
            reset_url = url_for('auth.reset_password', token=token, _external=True)
            send_password_reset(user.name, user.email, reset_url)
        return redirect(url_for('auth.login'))
    return render_template('auth/forgot_password.html')


@auth_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    rec = PasswordResetToken.query.filter_by(token=token, used=False).first()
    if not rec or rec.is_expired:
        if rec and rec.is_expired:
            db.session.delete(rec)
            db.session.commit()
        flash('Ссылка недействительна или истёк срок действия (30 мин). Запросите новую.', 'error')
        return redirect(url_for('auth.forgot_password'))

    user = rec.user
    if request.method == 'POST':
        pw  = request.form.get('password', '')
        pw2 = request.form.get('password2', '')
        if len(pw) < 6:
            flash('Пароль минимум 6 символов.', 'error')
        elif pw != pw2:
            flash('Пароли не совпадают.', 'error')
        else:
            user.set_password(pw)
            rec.used = True
            db.session.commit()
            # Удаляем все токены этого пользователя
            PasswordResetToken.query.filter_by(user_id=user.id).delete()
            db.session.commit()
            flash('Пароль успешно изменён. Войдите с новым паролем.', 'success')
            return redirect(url_for('auth.login'))
    return render_template('auth/reset_password.html', token=token)
