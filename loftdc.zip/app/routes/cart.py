from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import current_user, login_required
from app import db
from app.models import Product, Order, OrderItem, Coupon, Wishlist

cart_bp = Blueprint('cart', __name__)


def get_cart():
    return session.get('cart', {})

def save_cart(cart):
    session['cart'] = cart
    session.modified = True


@cart_bp.route('/')
def view():
    cart = get_cart()
    items, total = _cart_items(cart)
    return render_template('cart/index.html', items=items, total=total,
                           coupon=session.get('coupon'))


@cart_bp.route('/add/<int:pid>', methods=['POST'])
def add(pid):
    p = Product.query.get_or_404(pid)
    qty = int(request.form.get('qty', 1))
    cart = get_cart()
    key = str(pid)
    if key in cart:
        cart[key]['qty'] = min(cart[key]['qty'] + qty, p.stock)
    else:
        first_img = p.images.first()
        cart[key] = {'id': pid, 'name': p.name, 'price': p.price,
                     'emoji': p.emoji, 'qty': qty,
                     'image': first_img.filename if first_img else None}
    save_cart(cart)
    total_qty = sum(v['qty'] for v in cart.values())
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        from flask import jsonify
        return jsonify({'ok': True, 'msg': f'✓ {p.name} добавлен в корзину.', 'cart_count': total_qty})
    flash(f'✓ {p.name} добавлен в корзину.', 'success')
    return redirect(request.referrer or url_for('catalog.index'))


@cart_bp.route('/remove/<int:pid>', methods=['POST'])
def remove(pid):
    cart = get_cart()
    cart.pop(str(pid), None)
    save_cart(cart)
    return redirect(url_for('cart.view'))


@cart_bp.route('/update/<int:pid>', methods=['POST'])
def update(pid):
    qty = int(request.form.get('qty', 1))
    cart = get_cart()
    key = str(pid)
    if key in cart:
        if qty <= 0:
            cart.pop(key)
        else:
            cart[key]['qty'] = qty
    save_cart(cart)
    return redirect(url_for('cart.view'))


@cart_bp.route('/coupon', methods=['POST'])
def apply_coupon():
    code = request.form.get('code', '').strip().upper()
    c = Coupon.query.filter_by(code=code, active=True).first()
    if c:
        session['coupon'] = {'code': c.code, 'discount': c.discount}
        flash(f'✓ Промокод применён! Скидка {c.discount}%.', 'success')
    else:
        flash('Промокод не найден или неактивен.', 'error')
    return redirect(url_for('cart.view'))


@cart_bp.route('/clear', methods=['POST'])
def clear():
    session.pop('cart', None)
    session.pop('coupon', None)
    return redirect(url_for('cart.view'))


def _cart_items(cart):
    items = list(cart.values())
    total = sum(i['price'] * i['qty'] for i in items)
    return items, total


# ─── WISHLIST ───────────────────────────────────────────────────────────────

@cart_bp.route('/wish/toggle/<int:pid>', methods=['POST'])
@login_required
def wish_toggle(pid):
    w = Wishlist.query.filter_by(user_id=current_user.id, product_id=pid).first()
    if w:
        db.session.delete(w)
        msg, added = 'Удалено из избранного.', False
    else:
        db.session.add(Wishlist(user_id=current_user.id, product_id=pid))
        msg, added = '♡ Добавлено в избранное.', True
    db.session.commit()
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        from flask import jsonify
        return jsonify({'ok': True, 'added': added, 'msg': msg})
    flash(msg, 'info')
    return redirect(request.referrer or url_for('catalog.index'))
