import csv, io
from datetime import datetime, timedelta
from functools import wraps
from flask import (Blueprint, render_template, redirect, url_for,
                   flash, request, abort, Response, g, current_app)
from flask_login import login_required, current_user
from app import db
from app.models import User, Product, Order, Review, Article, Coupon, Message, RefundRequest
from app.doc_router import generate_invoice, generate_waybill, generate_proxy, generate_refund
from app.email_service import send_order_status_update

admin_bp = Blueprint('admin', __name__)

def manager_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if not current_user.is_authenticated or not current_user.is_manager:
            abort(403)
        return f(*a, **kw)
    return dec

def admin_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*a, **kw)
    return dec

@admin_bp.context_processor
def inject_counts():
    if current_user.is_authenticated and current_user.is_manager:
        return {
            'new_orders_count':      Order.query.filter_by(status='Новый').count(),
            'unread_msg_count':      Message.query.filter_by(read=False).count(),
            'pending_refunds_count': RefundRequest.query.filter_by(status='pending').count(),
        }
    return {'new_orders_count': 0, 'unread_msg_count': 0, 'pending_refunds_count': 0}

STATUSES = ['Новый','В обработке','Отправлен','Доставлен','Отменён']

@admin_bp.route('/')
@manager_required
def dashboard():
    from datetime import timedelta
    from app.models import FinanceTransaction
    period = request.args.get('period', 'month')
    delta_map = {'day':timedelta(days=1),'week':timedelta(weeks=1),
                 'month':timedelta(days=30),'quarter':timedelta(days=90),'year':timedelta(days=365)}
    since = datetime.utcnow() - delta_map.get(period, timedelta(days=30))

    txs_period = FinanceTransaction.query.filter(FinanceTransaction.created_at >= since).all()
    income_period  = sum(t.amount for t in txs_period if t.type == 'income')
    refunds_period = sum(t.amount for t in txs_period if t.type == 'refund')
    expense_period = sum(t.amount for t in txs_period if t.type == 'expense')
    net_period     = income_period - refunds_period - expense_period

    stats = {
        'products': Product.query.count(),
        'orders':   Order.query.count(),
        'users':    User.query.count(),
        'reviews':  Review.query.count(),
        'revenue':  db.session.query(db.func.sum(Order.total)).scalar() or 0,
        'messages': Message.query.filter_by(read=False).count(),
        'new_orders': Order.query.filter_by(status='Новый').count(),
        'income_period': income_period,
        'refunds_period': refunds_period,
        'expense_period': expense_period,
        'net_period': net_period,
    }
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(8).all()
    return render_template('admin/dashboard.html', stats=stats,
                           recent_orders=recent_orders, period=period)

@admin_bp.route('/products')
@manager_required
def products():
    q   = request.args.get('q','')
    cat = request.args.get('cat','')
    items = Product.query
    if q:   items = items.filter(Product.name.ilike(f'%{q}%'))
    if cat: items = items.filter_by(category=cat)
    items = items.order_by(Product.created_at.desc()).all()
    cats = [r[0] for r in db.session.query(Product.category).distinct().all()]
    return render_template('admin/products/list.html', items=items, q=q, cat=cat, cats=cats)

@admin_bp.route('/products/new', methods=['GET','POST'])
@manager_required
def products_new():
    if request.method == 'POST':
        p = Product(
            name=request.form['name'], category=request.form['category'],
            price=int(request.form.get('price') or 0),
            old_price=int(request.form['old_price']) if request.form.get('old_price') else None,
            description=request.form.get('description',''), emoji=request.form.get('emoji','📦'),
            material=request.form.get('material',''), size=request.form.get('size',''),
            badge=request.form.get('badge',''), badge_class=request.form.get('badge_class',''),
            stock=int(request.form.get('stock',0)), is_active='is_active' in request.form,
        )
        db.session.add(p)
        db.session.flush()
        _save_product_images(p, request)
        db.session.commit()
        flash('Товар создан.', 'success')
        return redirect(url_for('admin.products'))
    return render_template('admin/products/form.html', p=None)


@admin_bp.route('/products/<int:pid>/edit', methods=['GET','POST'])
@manager_required
def products_edit(pid):
    from app.models import ProductImage
    p = Product.query.get_or_404(pid)
    if request.method == 'POST':
        p.name=request.form['name']; p.category=request.form['category']
        p.price=int(request.form.get('price') or 0)
        p.old_price=int(request.form['old_price']) if request.form.get('old_price') else None
        p.description=request.form.get('description',''); p.emoji=request.form.get('emoji',p.emoji)
        p.material=request.form.get('material',''); p.size=request.form.get('size','')
        p.badge=request.form.get('badge',''); p.badge_class=request.form.get('badge_class','')
        p.stock=int(request.form.get('stock',0)); p.is_active='is_active' in request.form
        # Удаляем отмеченные фото
        delete_ids = request.form.getlist('delete_image')
        if delete_ids:
            for img_id in delete_ids:
                img = ProductImage.query.get(int(img_id))
                if img and img.product_id == p.id:
                    import os as _os
                    try:
                        _os.remove(_os.path.join(
                            current_app.config['UPLOAD_FOLDER'], img.filename))
                    except Exception:
                        pass
                    db.session.delete(img)
        _save_product_images(p, request)
        db.session.commit()
        flash('Товар обновлён.', 'success')
        return redirect(url_for('admin.products'))
    return render_template('admin/products/form.html', p=p)


def _save_product_images(product, req):
    """Сохраняет загруженные изображения товара."""
    from app.models import ProductImage
    from werkzeug.utils import secure_filename
    import os as _os, uuid as _uuid
    files = req.files.getlist('images')
    allowed = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    sort_start = product.images.count()
    for i, f in enumerate(files):
        if not f or not f.filename:
            continue
        ext = f.filename.rsplit('.', 1)[-1].lower()
        if ext not in allowed:
            continue
        fname = f'{_uuid.uuid4().hex}.{ext}'
        f.save(_os.path.join(current_app.config['UPLOAD_FOLDER'], fname))
        db.session.add(ProductImage(product_id=product.id,
                                    filename=fname, sort_order=sort_start+i))

@admin_bp.route('/products/<int:pid>/delete', methods=['POST'])
@manager_required
def products_delete(pid):
    p = Product.query.get_or_404(pid); db.session.delete(p); db.session.commit()
    flash('Товар удалён.', 'success'); return redirect(url_for('admin.products'))

@admin_bp.route('/orders')
@manager_required
def orders():
    status = request.args.get('status','')
    q = Order.query
    if status: q = q.filter_by(status=status)
    items = q.order_by(Order.created_at.desc()).all()
    return render_template('admin/orders/list.html', items=items, statuses=STATUSES, current_status=status)

@admin_bp.route('/orders/<int:oid>')
@manager_required
def orders_detail(oid):
    o = Order.query.get_or_404(oid)
    return render_template('admin/orders/detail.html', o=o, statuses=o.available_next_statuses)

@admin_bp.route('/orders/<int:oid>/status', methods=['POST'])
@manager_required
def orders_status(oid):
    o = Order.query.get_or_404(oid)
    ns = request.form.get('status')
    allowed = o.available_next_statuses
    if ns in allowed:
        # Статус "Доставлен" может поставить только пользователь через код подтверждения
        if ns == 'Доставлен':
            flash('Статус «Доставлен» устанавливается только пользователем через подтверждение на странице заказа.', 'error')
            return redirect(url_for('admin.orders_detail', oid=oid))
        old_status = o.status
        o.status = ns
        db.session.commit()
        flash(f'Статус изменён: {ns}', 'success')
        if ns != 'Новый' and ns != old_status:
            user = User.query.get(o.user_id) if o.user_id else None
            if user and user.email:
                sent = send_order_status_update(o, user.email)
                if sent:
                    flash(f'✉ Уведомление отправлено на {user.email}', 'info')
    else:
        flash('Недопустимый статус.', 'error')
    return redirect(url_for('admin.orders_detail', oid=oid))


# ─── Документы заказа ───────────────────────────────────────────────────────

@admin_bp.route('/orders/<int:oid>/doc/invoice')
@manager_required
def orders_doc_invoice(oid):
    o = Order.query.get_or_404(oid)
    data, mime, fname = generate_invoice(o)
    return Response(data, mimetype=mime,
                    headers={'Content-Disposition': f'inline; filename="{fname}"'})


@admin_bp.route('/orders/<int:oid>/doc/waybill')
@manager_required
def orders_doc_waybill(oid):
    o = Order.query.get_or_404(oid)
    data, mime, fname = generate_waybill(o)
    return Response(data, mimetype=mime,
                    headers={'Content-Disposition': f'inline; filename="{fname}"'})


@admin_bp.route('/orders/<int:oid>/doc/proxy')
@manager_required
def orders_doc_proxy(oid):
    o = Order.query.get_or_404(oid)
    courier_name     = request.args.get('courier_name', '')
    courier_passport = request.args.get('courier_passport', '')
    data, mime, fname = generate_proxy(o, courier_name, courier_passport)
    return Response(data, mimetype=mime,
                    headers={'Content-Disposition': f'inline; filename="{fname}"'})


@admin_bp.route('/orders/<int:oid>/send-email', methods=['POST'])
@manager_required
def orders_send_email(oid):
    """Вручную отправить email о статусе заказа."""
    o = Order.query.get_or_404(oid)
    user = User.query.get(o.user_id) if o.user_id else None
    if user and user.email:
        sent = send_order_status_update(o, user.email)
        flash(('✉ Письмо отправлено на ' + user.email) if sent else '✗ Ошибка отправки письма',
              'success' if sent else 'error')
    else:
        flash('Email покупателя не найден.', 'error')
    return redirect(url_for('admin.orders_detail', oid=oid))


@admin_bp.route('/orders/<int:oid>/delete', methods=['POST'])
@admin_required
def orders_delete(oid):
    o = Order.query.get_or_404(oid)
    # Удаляем связанные записи перед удалением заказа
    RefundRequest.query.filter_by(order_id=oid).delete()
    from app.models import DeliveryConfirmCode
    DeliveryConfirmCode.query.filter_by(order_id=oid).delete()
    db.session.delete(o)
    db.session.commit()
    flash('Заказ удалён.', 'success')
    return redirect(url_for('admin.orders'))

@admin_bp.route('/orders/export')
@manager_required
def orders_export():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    buf = io.StringIO(); w = csv.writer(buf, delimiter=';')
    w.writerow(['ID','Клиент','Телефон','Сумма','Адрес','Оплата','Статус','Дата'])
    for o in orders:
        w.writerow([o.id,o.user_name,o.phone,o.total,o.address,o.payment,o.status,o.created_at.strftime('%d.%m.%Y')])
    return Response('\ufeff'+buf.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition':'attachment;filename=orders.csv'})

@admin_bp.route('/users')
@admin_required
def users():
    q = request.args.get('q','')
    items = User.query
    if q: items = items.filter(db.or_(User.name.ilike(f'%{q}%'), User.email.ilike(f'%{q}%')))
    items = items.order_by(User.created_at.desc()).all()
    return render_template('admin/users/list.html', items=items, q=q)

@admin_bp.route('/users/<int:uid>/role', methods=['POST'])
@admin_required
def users_role(uid):
    u = User.query.get_or_404(uid)
    if u.id == current_user.id: flash('Нельзя изменить свою роль.', 'error'); return redirect(url_for('admin.users'))
    nr = request.form.get('role')
    if nr in ('admin','manager','user'): u.role = nr; db.session.commit(); flash(f'Роль: {nr}', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:uid>/toggle', methods=['POST'])
@admin_required
def users_toggle(uid):
    u = User.query.get_or_404(uid)
    if u.id == current_user.id: flash('Нельзя заблокировать себя.', 'error'); return redirect(url_for('admin.users'))
    u.is_active = not u.is_active; db.session.commit()
    flash(('Активирован' if u.is_active else 'Заблокирован')+f': {u.name}', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:uid>/delete', methods=['POST'])
@admin_required
def users_delete(uid):
    u = User.query.get_or_404(uid)
    if u.id == current_user.id: flash('Нельзя удалить себя.', 'error'); return redirect(url_for('admin.users'))
    db.session.delete(u); db.session.commit(); flash('Пользователь удалён.', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/reviews')
@manager_required
def reviews():
    items = Review.query.order_by(Review.created_at.desc()).all()
    return render_template('admin/reviews.html', items=items)

@admin_bp.route('/reviews/<int:rid>/toggle', methods=['POST'])
@manager_required
def reviews_toggle(rid):
    r = Review.query.get_or_404(rid); r.approved = not r.approved; db.session.commit()
    flash(('Опубликован' if r.approved else 'Скрыт')+f': отзыв #{rid}', 'success')
    return redirect(url_for('admin.reviews'))

@admin_bp.route('/reviews/<int:rid>/delete', methods=['POST'])
@manager_required
def reviews_delete(rid):
    r = Review.query.get_or_404(rid); db.session.delete(r); db.session.commit()
    flash('Отзыв удалён.', 'success'); return redirect(url_for('admin.reviews'))

@admin_bp.route('/articles')
@manager_required
def articles():
    items = Article.query.order_by(Article.created_at.desc()).all()
    return render_template('admin/articles/list.html', items=items)

@admin_bp.route('/articles/new', methods=['GET','POST'])
@manager_required
def articles_new():
    if request.method == 'POST':
        a = Article(title=request.form['title'], category=request.form.get('category',''),
                    emoji=request.form.get('emoji','📄'), description=request.form.get('description',''),
                    body=request.form.get('body',''), published='published' in request.form)
        db.session.add(a); db.session.commit(); flash('Статья создана.', 'success')
        return redirect(url_for('admin.articles'))
    return render_template('admin/articles/form.html', a=None)

@admin_bp.route('/articles/<int:aid>/edit', methods=['GET','POST'])
@manager_required
def articles_edit(aid):
    a = Article.query.get_or_404(aid)
    if request.method == 'POST':
        a.title=request.form['title']; a.category=request.form.get('category','')
        a.emoji=request.form.get('emoji',a.emoji); a.description=request.form.get('description','')
        a.body=request.form.get('body',''); a.published='published' in request.form
        db.session.commit(); flash('Статья обновлена.', 'success')
        return redirect(url_for('admin.articles'))
    return render_template('admin/articles/form.html', a=a)

@admin_bp.route('/articles/<int:aid>/delete', methods=['POST'])
@manager_required
def articles_delete(aid):
    a = Article.query.get_or_404(aid); db.session.delete(a); db.session.commit()
    flash('Статья удалена.', 'success'); return redirect(url_for('admin.articles'))

@admin_bp.route('/coupons')
@admin_required
def coupons():
    items = Coupon.query.all()
    return render_template('admin/coupons.html', items=items)

@admin_bp.route('/coupons/new', methods=['POST'])
@admin_required
def coupons_new():
    code = request.form.get('code','').strip().upper()
    disc = int(request.form.get('discount',10))
    if not code: flash('Введите код.', 'error')
    elif Coupon.query.filter_by(code=code).first(): flash('Промокод уже существует.', 'error')
    else:
        db.session.add(Coupon(code=code, discount=disc)); db.session.commit()
        flash('Промокод создан.', 'success')
    return redirect(url_for('admin.coupons'))

@admin_bp.route('/coupons/<int:cid>/toggle', methods=['POST'])
@admin_required
def coupons_toggle(cid):
    c = Coupon.query.get_or_404(cid); c.active = not c.active; db.session.commit()
    flash(('Активирован' if c.active else 'Деактивирован')+f': {c.code}', 'success')
    return redirect(url_for('admin.coupons'))

@admin_bp.route('/coupons/<int:cid>/delete', methods=['POST'])
@admin_required
def coupons_delete(cid):
    c = Coupon.query.get_or_404(cid); db.session.delete(c); db.session.commit()
    flash('Промокод удалён.', 'success'); return redirect(url_for('admin.coupons'))

@admin_bp.route('/messages')
@manager_required
def messages():
    items = Message.query.order_by(Message.created_at.desc()).all()
    Message.query.filter_by(read=False).update({'read': True}); db.session.commit()
    return render_template('admin/messages.html', items=items)

@admin_bp.route('/messages/<int:mid>/delete', methods=['POST'])
@manager_required
def messages_delete(mid):
    m = Message.query.get_or_404(mid); db.session.delete(m); db.session.commit()
    flash('Сообщение удалено.', 'success'); return redirect(url_for('admin.messages'))


# ─── Возвраты ────────────────────────────────────────────────────────────────

@admin_bp.route('/refunds')
@manager_required
def refunds():
    status = request.args.get('status', 'all')
    q = RefundRequest.query.order_by(RefundRequest.created_at.desc())
    if status != 'all':
        q = q.filter_by(status=status)
    return render_template('admin/refunds.html', items=q.all(), current_status=status)


@admin_bp.route('/refunds/<int:rid>')
@manager_required
def refund_detail(rid):
    r = RefundRequest.query.get_or_404(rid)
    return render_template('admin/refund_detail.html', r=r)


@admin_bp.route('/refunds/<int:rid>/resolve', methods=['POST'])
@manager_required
def refund_resolve(rid):
    from datetime import datetime
    r = RefundRequest.query.get_or_404(rid)
    if r.status != 'pending':
        flash('Заявка уже рассмотрена.', 'error')
        return redirect(url_for('admin.refund_detail', rid=rid))

    action = request.form.get('action')
    note   = request.form.get('admin_note', '').strip()

    if action not in ('approved', 'rejected'):
        flash('Неверное действие.', 'error')
        return redirect(url_for('admin.refund_detail', rid=rid))

    r.status      = action
    r.admin_note  = note
    r.resolved_at = datetime.utcnow()
    db.session.commit()

    # Записываем транзакцию возврата
    if action == 'approved':
        from app.models import FinanceTransaction
        db.session.add(FinanceTransaction(
            type='refund', amount=r.order.total,
            description=f'Возврат по заказу #{r.order_id} (заявка #{r.id})',
            order_id=r.order_id, user_id=r.user_id
        ))
        db.session.commit()

    # Email пользователю
    from app.email_service import _send, _base_template
    label   = 'ОДОБРЕН ✓' if action == 'approved' else 'ОТКЛОНЁН ✕'
    color   = '#27ae60'    if action == 'approved' else '#c0392b'
    bg      = 'rgba(39,174,96,.08)' if action == 'approved' else 'rgba(192,57,43,.08)'
    border  = 'rgba(39,174,96,.2)'  if action == 'approved' else 'rgba(192,57,43,.2)'
    msg     = ('Ваш возврат одобрен. Средства поступят на счёт в течение 10 рабочих дней.' if action == 'approved'
               else 'К сожалению, ваша заявка на возврат отклонена.')
    note_block = f'''
    <div style="background:#f9f8f4;border-left:3px solid #d4c5a9;padding:14px 18px;margin-top:16px;font-size:14px;color:#555;font-style:italic">
      <strong>Примечание:</strong> {note}
    </div>''' if note else ''

    body = f"""
    <div style="font-family:'Bebas Neue',sans-serif;font-size:40px;letter-spacing:3px;color:#0a0a0a;margin-bottom:6px">РЕШЕНИЕ ПО ВОЗВРАТУ</div>
    <div style="font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;color:#666;text-transform:uppercase;margin-bottom:28px">заказ #{r.order_id}</div>
    <div style="background:{bg};border:1px solid {border};padding:20px 24px;margin-bottom:24px;text-align:center">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:40px;letter-spacing:4px;color:{color}">{label}</div>
    </div>
    <p style="font-size:17px;color:#333;margin-bottom:16px;font-style:italic">{msg}</p>
    {note_block}
    <div style="font-family:'JetBrains Mono',monospace;font-size:11px;color:#666;line-height:2;margin-top:20px">
      Заказ: <strong style="color:#0a0a0a">#{r.order_id}</strong><br>
      Сумма: <strong style="color:#0a0a0a">{'{:,}'.format(r.order.total).replace(',', '\u2009')} ₽</strong>
    </div>
    """
    html = _base_template(
        title=f'Решение по возврату — заказ #{r.order_id}',
        preview=f'Заявка на возврат по заказу #{r.order_id}: {r.status_label}',
        body_html=body
    )
    _send(r.user.email, f'Возврат по заказу #{r.order_id} — {r.status_label} — LOFT DC', html)

    flash(f'Заявка {"одобрена" if action == "approved" else "отклонена"}. Email отправлен клиенту.', 'success')
    return redirect(url_for('admin.refund_detail', rid=rid))


@admin_bp.route('/refunds/<int:rid>/doc')
@manager_required
def refund_doc(rid):
    r = RefundRequest.query.get_or_404(rid)
    data, mime, fname = generate_refund(r)
    return Response(data, mimetype=mime,
                    headers={'Content-Disposition': f'inline; filename="{fname}"'})


# ─── Верификация пароля ──────────────────────────────────────────────────────

@admin_bp.route('/verify-password', methods=['POST'])
@manager_required
def verify_password():
    from flask import jsonify
    from werkzeug.security import check_password_hash
    pwd = request.form.get('password', '')
    ok  = check_password_hash(current_user.password_hash, pwd)
    return jsonify({'ok': ok})


# ─── Финансы ─────────────────────────────────────────────────────────────────

@admin_bp.route('/finance')
@manager_required
def finance():
    from app.models import FinanceTransaction
    from datetime import timedelta
    period = request.args.get('period', 'month')
    now    = datetime.utcnow()
    if period == 'day':
        since = now - timedelta(days=1)
    elif period == 'week':
        since = now - timedelta(weeks=1)
    elif period == 'quarter':
        since = now - timedelta(days=90)
    elif period == 'year':
        since = now - timedelta(days=365)
    else:  # month
        since = now - timedelta(days=30)

    txs = FinanceTransaction.query.filter(
        FinanceTransaction.created_at >= since
    ).order_by(FinanceTransaction.created_at.desc()).all()

    income  = sum(t.amount for t in txs if t.type == 'income')
    refunds = sum(t.amount for t in txs if t.type == 'refund')
    expense = sum(t.amount for t in txs if t.type == 'expense')
    net     = income - refunds - expense

    return render_template('admin/finance.html',
        txs=txs, income=income, refunds=refunds,
        expense=expense, net=net, period=period)


@admin_bp.route('/finance/add', methods=['POST'])
@admin_required
def finance_add():
    from app.models import FinanceTransaction
    t = FinanceTransaction(
        type=request.form.get('type', 'expense'),
        amount=int(request.form.get('amount', 0)),
        description=request.form.get('description', '')
    )
    db.session.add(t)
    db.session.commit()
    flash('Транзакция добавлена.', 'success')
    return redirect(url_for('admin.finance'))


# ─── Отчёты ──────────────────────────────────────────────────────────────────

@admin_bp.route('/reports')
@manager_required
def reports():
    from app.models import Report
    items = Report.query.order_by(Report.created_at.desc()).all()
    return render_template('admin/reports.html', items=items)


@admin_bp.route('/reports/generate', methods=['POST'])
@manager_required
def reports_generate():
    from app.models import Report, FinanceTransaction
    from app.doc_router import IS_EXE
    import json
    from datetime import timedelta

    rtype  = request.form.get('type', 'sales')
    period = request.form.get('period', 'month')
    now    = datetime.utcnow()

    period_map = {
        'week': timedelta(weeks=1), 'month': timedelta(days=30),
        'quarter': timedelta(days=90), 'year': timedelta(days=365),
    }
    delta  = period_map.get(period, timedelta(days=30))
    since  = now - delta

    period_labels = {'week':'Неделя','month':'Месяц','quarter':'Квартал','year':'Год'}
    type_labels   = {'sales':'Продажи','finance':'Финансы','orders':'Заказы','products':'Товары'}

    title = f'Отчёт: {type_labels.get(rtype,rtype)} за {period_labels.get(period,period)}'

    rep = Report(
        title=title, type=rtype,
        period_from=since, period_to=now,
        created_by=current_user.id,
        params=json.dumps({'period': period})
    )
    db.session.add(rep)
    db.session.commit()

    # Генерируем документ
    data, mime, fname = _build_report(rep, rtype, since, now)
    return Response(data, mimetype=mime,
                    headers={'Content-Disposition': f'inline; filename="{fname}"'})


def _build_report(rep, rtype, since, now):
    """Собирает данные и генерирует документ отчёта."""
    from app.models import FinanceTransaction, OrderItem
    from app.doc_router import IS_EXE
    from collections import defaultdict

    orders_q   = Order.query.filter(Order.created_at >= since, Order.created_at <= now)
    orders_all = orders_q.all()
    txs        = FinanceTransaction.query.filter(
        FinanceTransaction.created_at >= since,
        FinanceTransaction.created_at <= now
    ).all()

    income  = sum(t.amount for t in txs if t.type == 'income')
    refunds = sum(t.amount for t in txs if t.type == 'refund')
    expense = sum(t.amount for t in txs if t.type == 'expense')

    # --- Продажи по товарам ---
    product_sales = defaultdict(lambda: {'name':'','emoji':'','qty':0,'revenue':0,'category':''})
    for o in orders_all:
        for item in o.items:
            k = item.product_id or item.name
            product_sales[k]['name']     = item.name
            product_sales[k]['emoji']    = item.emoji
            product_sales[k]['qty']     += item.qty
            product_sales[k]['revenue'] += item.price * item.qty
    top_products = sorted(product_sales.values(), key=lambda x: x['revenue'], reverse=True)[:20]

    # --- Продажи по категориям ---
    cat_sales = defaultdict(lambda: {'qty':0,'revenue':0})
    for o in orders_all:
        for item in o.items:
            p = Product.query.get(item.product_id) if item.product_id else None
            cat = p.category if p else 'Прочее'
            cat_sales[cat]['qty']     += item.qty
            cat_sales[cat]['revenue'] += item.price * item.qty
    top_cats = sorted(cat_sales.items(), key=lambda x: x[1]['revenue'], reverse=True)

    # --- Статусы заказов ---
    status_counts = defaultdict(int)
    for o in orders_all: status_counts[o.status] += 1

    # --- Способы оплаты ---
    payment_counts = defaultdict(lambda: {'count':0,'revenue':0})
    for o in orders_all:
        payment_counts[o.payment]['count']   += 1
        payment_counts[o.payment]['revenue'] += o.total

    # --- Способы доставки ---
    delivery_counts = defaultdict(int)
    for o in orders_all: delivery_counts[o.delivery] += 1

    data_pkg = {
        'type':          rtype,
        'orders':        orders_all,
        'txs':           txs,
        'income':        income,
        'refunds':       refunds,
        'expense':       expense,
        'net':           income - refunds - expense,
        'total_orders':  len(orders_all),
        'delivered':     status_counts.get('Доставлен', 0),
        'cancelled':     status_counts.get('Отменён', 0),
        'in_progress':   status_counts.get('В обработке', 0),
        'sent':          status_counts.get('Отправлен', 0),
        'new':           status_counts.get('Новый', 0),
        'top_products':  top_products,
        'top_cats':      top_cats,
        'status_counts': dict(status_counts),
        'payment_counts':dict(payment_counts),
        'delivery_counts':dict(delivery_counts),
        'avg_order':     income // len(orders_all) if orders_all else 0,
        'all_products':  Product.query.count(),
    }

    if IS_EXE:
        from app.report_generator import generate_report_html
        content = generate_report_html(rep, data_pkg)
        return content.encode('utf-8'), 'text/html; charset=utf-8', f'Report_{rep.id}.html'
    else:
        from app.report_generator import generate_report_pdf
        content = generate_report_pdf(rep, data_pkg)
        return content, 'application/pdf', f'Report_{rep.id}.pdf'


@admin_bp.route('/reports/<int:rid>/download')
@manager_required
def report_download(rid):
    from app.models import Report
    rep = Report.query.get_or_404(rid)
    import json
    params = json.loads(rep.params or '{}')
    period = params.get('period', 'month')
    from datetime import timedelta
    now = datetime.utcnow()
    delta_map = {'week':timedelta(weeks=1),'month':timedelta(days=30),
                 'quarter':timedelta(days=90),'year':timedelta(days=365)}
    since = rep.period_from or (now - delta_map.get(period, timedelta(days=30)))
    data, mime, fname = _build_report(rep, rep.type, since, rep.period_to or now)
    return Response(data, mimetype=mime,
                    headers={'Content-Disposition': f'inline; filename="{fname}"'})
