from flask import Blueprint, render_template, request, abort
from flask_login import current_user
from app.models import Product, Review, Wishlist

catalog_bp = Blueprint('catalog', __name__)

CAT_ICONS = {
    'Столы':'🍽','Стулья':'🪑','Диваны':'🛋','Стеллажи':'📚',
    'Кресла':'🪑','Тумбы':'🗄','Кровати':'🛏','Шкафы':'🚪','Освещение':'💡'
}


@catalog_bp.route('/')
def index():
    cat  = request.args.get('cat', '')
    sort = request.args.get('sort', 'default')

    q = Product.query.filter_by(is_active=True)
    if cat:
        q = q.filter_by(category=cat)

    if sort == 'price_asc':
        q = q.order_by(Product.price.asc())
    elif sort == 'price_desc':
        q = q.order_by(Product.price.desc())
    elif sort == 'name':
        q = q.order_by(Product.name.asc())
    else:
        q = q.order_by(Product.created_at.desc())

    products = q.all()

    # Категории для фильтра
    all_cats = (Product.query
                .with_entities(Product.category)
                .filter_by(is_active=True)
                .distinct().all())
    cats = [{'name': r[0], 'icon': CAT_ICONS.get(r[0], '📦')} for r in all_cats]

    # Избранное текущего пользователя
    wish_ids = set()
    if current_user.is_authenticated:
        wish_ids = {w.product_id for w in current_user.wishlist.all()}

    return render_template('catalog/index.html', products=products,
                           cats=cats, current_cat=cat, sort=sort,
                           wish_ids=wish_ids)


@catalog_bp.route('/<int:pid>')
def product(pid):
    p = Product.query.get_or_404(pid)
    if not p.is_active:
        abort(404)
    reviews  = p.reviews.filter_by(approved=True).order_by(Review.created_at.desc()).all()
    related  = (Product.query
                .filter_by(category=p.category, is_active=True)
                .filter(Product.id != p.id).limit(4).all())

    wish_ids = set()
    if current_user.is_authenticated:
        wish_ids = {w.product_id for w in current_user.wishlist.all()}

    return render_template('catalog/product.html', p=p, reviews=reviews,
                           related=related, wish_ids=wish_ids)
