import random, string
from datetime import datetime
from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, session, jsonify, Response)
from flask_login import login_required, current_user
from app import db
from app.models import Order, OrderItem, Coupon, DeliveryConfirmCode
from app.routes.cart import get_cart, _cart_items
from app.email_service import send_order_confirmation, send_order_status_update

orders_bp = Blueprint('orders', __name__)

ONLINE_PAYMENTS = ('Карта онлайн', 'Рассрочка 0%')


def _gen_code():
    return ''.join(random.choices(string.digits, k=6))


@orders_bp.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    cart = get_cart()
    if not cart:
        flash('Корзина пуста.', 'error')
        return redirect(url_for('catalog.index'))

    items, total = _cart_items(cart)
    coupon_data = session.get('coupon')
    discount    = coupon_data['discount'] if coupon_data else 0
    final_total = round(total * (1 - discount / 100))

    if request.method == 'POST':
        name     = request.form.get('name', '').strip()
        phone    = request.form.get('phone', '').strip()
        address  = request.form.get('address', '').strip()
        payment  = request.form.get('payment', '')
        delivery = request.form.get('delivery', '')
        comment  = request.form.get('comment', '')

        if not name or not phone or not address:
            flash('Заполните имя, телефон и адрес.', 'error')
        else:
            order = Order(
                user_id=current_user.id, user_name=name, phone=phone,
                address=address, payment=payment, delivery=delivery,
                comment=comment, total=final_total,
                discount=discount, coupon_code=coupon_data['code'] if coupon_data else ''
            )
            db.session.add(order)
            db.session.flush()

            for item in items:
                db.session.add(OrderItem(
                    order_id=order.id, product_id=item['id'],
                    name=item['name'], price=item['price'],
                    qty=item['qty'], emoji=item['emoji']
                ))

            if coupon_data:
                c = Coupon.query.filter_by(code=coupon_data['code']).first()
                if c: c.uses += 1

            db.session.commit()
            session.pop('cart', None)
            session.pop('coupon', None)

            # Если онлайн-оплата — на страницу оплаты
            if payment in ONLINE_PAYMENTS:
                return redirect(url_for('orders.payment', oid=order.id))

            # Иначе — сразу подтверждение и email
            send_order_confirmation(order, current_user.email)
            flash(f'✓ Заказ #{order.id} оформлен! Менеджер свяжется с вами.', 'success')
            return redirect(url_for('orders.order_detail', oid=order.id))

    return render_template('orders/checkout.html', items=items, total=total,
                           discount=discount, final_total=final_total,
                           coupon=coupon_data, user=current_user)


@orders_bp.route('/<int:oid>')
@login_required
def order_detail(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()
    return render_template('orders/detail.html', order=order)


# ── Оплата ───────────────────────────────────────────────────────────────────

@orders_bp.route('/<int:oid>/payment')
@login_required
def payment(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()
    if order.is_paid:
        return redirect(url_for('orders.order_detail', oid=oid))
    return render_template('orders/payment.html', order=order)


@orders_bp.route('/<int:oid>/payment/success')
@login_required
def payment_success(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()
    if not order.is_paid:
        order.payment_status = 'paid'
        order.paid_at = datetime.utcnow()
        db.session.commit()
        # Записываем транзакцию
        from app.models import FinanceTransaction
        db.session.add(FinanceTransaction(
            type='income', amount=order.total,
            description=f'Оплата заказа #{order.id}',
            order_id=order.id, user_id=current_user.id
        ))
        db.session.commit()
        send_order_confirmation(order, current_user.email)
    return render_template('orders/success.html', order=order)


# ── Чек ──────────────────────────────────────────────────────────────────────

@orders_bp.route('/<int:oid>/receipt')
@login_required
def download_receipt(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()
    if not order.is_paid:
        flash('Чек доступен только для оплаченных заказов.', 'error')
        return redirect(url_for('orders.order_detail', oid=oid))
    from app.doc_router import generate_receipt
    data, mime, fname = generate_receipt(order)
    return Response(data, mimetype=mime,
                    headers={'Content-Disposition': f'attachment; filename="{fname}"'})


# ── Подтверждение доставки кодом ─────────────────────────────────────────────

@orders_bp.route('/<int:oid>/request-delivery-code', methods=['POST'])
@login_required
def request_delivery_code(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()

    if order.status != 'Отправлен':
        return jsonify({'ok': False, 'error': 'Заказ не в статусе «Отправлен»'})

    # Антиспам: не чаще 1 раза в 60 секунд
    existing = DeliveryConfirmCode.query.filter_by(
        order_id=oid, user_id=current_user.id, used=False
    ).order_by(DeliveryConfirmCode.created_at.desc()).first()

    if existing and not existing.is_expired:
        from datetime import timedelta
        wait_sec = int((existing.created_at + timedelta(seconds=60) - datetime.utcnow()).total_seconds())
        if wait_sec > 0:
            return jsonify({'ok': False, 'error': f'Подождите {wait_sec} сек. перед повторной отправкой'})

    # Удаляем старые коды
    DeliveryConfirmCode.query.filter_by(order_id=oid, user_id=current_user.id).delete()

    code = _gen_code()
    db.session.add(DeliveryConfirmCode(
        order_id=oid, user_id=current_user.id, code=code
    ))
    db.session.commit()

    # Отправляем код на почту
    from app.email_service import _send, _base_template
    body = f"""
    <div style="font-family:'Bebas Neue',sans-serif;font-size:40px;letter-spacing:3px;color:#0a0a0a;margin-bottom:6px;line-height:1">КОД ПОДТВЕРЖДЕНИЯ</div>
    <div style="font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;color:#666;text-transform:uppercase;margin-bottom:28px">доставки заказа #{order.id}</div>
    <p style="font-size:17px;color:#333;margin-bottom:28px;font-style:italic">
      Введите этот код на странице заказа для подтверждения получения.
    </p>
    <div style="text-align:center;padding:32px;background:#0a0a0a;margin:20px 0">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:72px;letter-spacing:16px;color:#d4c5a9">{code}</div>
    </div>
    <div style="background:#FFF8E1;border-left:3px solid #d4c5a9;padding:14px 18px;font-size:14px;font-style:italic;color:#555;margin:20px 0">
      Код действителен <strong>15 минут</strong>. Если вы не запрашивали код — проигнорируйте письмо.
    </div>
    """
    html = _base_template(
        title=f'Код подтверждения доставки #{order.id}',
        preview=f'Ваш код: {code}',
        body_html=body
    )
    _send(current_user.email, f'Код подтверждения доставки — LOFT DC', html)

    return jsonify({'ok': True})


@orders_bp.route('/<int:oid>/confirm-delivery', methods=['POST'])
@login_required
def confirm_delivery(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()
    data  = request.get_json()
    code  = (data or {}).get('code', '').strip()

    rec = DeliveryConfirmCode.query.filter_by(
        order_id=oid, user_id=current_user.id, used=False
    ).order_by(DeliveryConfirmCode.created_at.desc()).first()

    if not rec:
        return jsonify({'ok': False, 'error': 'Код не найден. Запросите новый.'})
    if rec.is_expired:
        db.session.delete(rec)
        db.session.commit()
        return jsonify({'ok': False, 'error': 'Код истёк. Запросите новый.'})
    if rec.is_blocked:
        return jsonify({'ok': False, 'error': 'Превышено число попыток. Запросите новый код.'})
    if rec.code != code:
        rec.attempts += 1
        db.session.commit()
        left = 5 - rec.attempts
        return jsonify({'ok': False, 'error': f'Неверный код. Осталось попыток: {left}'})

    # Код верный
    rec.used = True
    order.status = 'Доставлен'
    db.session.commit()
    send_order_status_update(order, current_user.email)
    return jsonify({'ok': True})


# ── Отмена и возврат ─────────────────────────────────────────────────────────

@orders_bp.route('/<int:oid>/cancel')
@login_required
def cancel_order(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()
    if order.status in ('Доставлен', 'Отменён'):
        flash('Этот заказ нельзя отменить.', 'error')
    else:
        order.status = 'Отменён'
        db.session.commit()
        flash(f'Заказ #{order.id} отменён.', 'info')
        send_order_status_update(order, current_user.email)
    return redirect(url_for('orders.order_detail', oid=oid))


@orders_bp.route('/<int:oid>/refund', methods=['GET', 'POST'])
@login_required
def refund_request(oid):
    order = Order.query.filter_by(id=oid, user_id=current_user.id).first_or_404()
    if order.status in ('Отменён',):
        flash('Возврат невозможен для отменённого заказа.', 'error')
        return redirect(url_for('orders.order_detail', oid=oid))

    from app.models import RefundRequest
    # Проверяем — нет ли уже заявки
    existing = RefundRequest.query.filter_by(order_id=oid, user_id=current_user.id).first()
    if existing:
        flash('Заявка на возврат по этому заказу уже подана.', 'info')
        return redirect(url_for('orders.order_detail', oid=oid))

    if request.method == 'POST':
        reason = request.form.get('reason', '').strip()
        if not reason:
            flash('Укажите причину возврата.', 'error')
            return render_template('orders/refund.html', order=order)

        ref = RefundRequest(order_id=oid, user_id=current_user.id, reason=reason)
        db.session.add(ref)
        db.session.commit()

        # Email пользователю
        from app.email_service import _send, _base_template
        body = f"""
        <div style="font-family:'Bebas Neue',sans-serif;font-size:40px;letter-spacing:3px;color:#0a0a0a;margin-bottom:6px">ЗАЯВКА НА ВОЗВРАТ</div>
        <div style="font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;color:#666;text-transform:uppercase;margin-bottom:28px">заказ #{order.id}</div>
        <p style="font-size:17px;color:#333;margin-bottom:24px;font-style:italic">
          Ваша заявка на возврат принята и передана на рассмотрение. Мы свяжемся с вами в течение 1–3 рабочих дней.
        </p>
        <div style="background:#f9f8f4;border:1px solid #e0ded8;padding:20px 24px;margin:20px 0">
          <div style="font-family:'JetBrains Mono',monospace;font-size:9px;letter-spacing:2px;color:#888;text-transform:uppercase;margin-bottom:10px">ПРИЧИНА ВОЗВРАТА</div>
          <p style="font-size:15px;color:#333;font-style:italic">«{reason}»</p>
        </div>
        <div style="font-family:'JetBrains Mono',monospace;font-size:11px;color:#666;line-height:1.9;margin-top:20px">
          Заказ: <strong style="color:#0a0a0a">#{order.id}</strong><br>
          Сумма: <strong style="color:#0a0a0a">{'{:,}'.format(order.total).replace(',', '\u2009')} ₽</strong><br>
          Дата заказа: <strong style="color:#0a0a0a">{order.created_at.strftime('%d.%m.%Y')}</strong>
        </div>
        """
        html = _base_template(
            title=f'Заявка на возврат — заказ #{order.id}',
            preview=f'Ваша заявка на возврат по заказу #{order.id} принята.',
            body_html=body
        )
        _send(current_user.email, f'Заявка на возврат — заказ #{order.id} — LOFT DC', html)

        flash('Заявка на возврат подана. Мы свяжемся с вами в течение 1–3 рабочих дней.', 'success')
        return redirect(url_for('orders.order_detail', oid=oid))

    return render_template('orders/refund.html', order=order)
