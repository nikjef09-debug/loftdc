from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required
from app import db
from app.models import Review, Message, Coupon, Product

api_bp = Blueprint('api', __name__)


@api_bp.route('/review', methods=['POST'])
@login_required
def add_review():
    data = request.get_json(silent=True) or request.form
    pid    = int(data.get('product_id', 0))
    text   = str(data.get('text', '')).strip()
    rating = int(data.get('rating', 5))
    if not pid or not text:
        return jsonify(ok=False, msg='Заполните все поля'), 400
    p = Product.query.get(pid)
    if not p:
        return jsonify(ok=False, msg='Товар не найден'), 404
    r = Review(product_id=pid, user_id=current_user.id,
               author=current_user.name.split()[0],
               rating=max(1,min(5,rating)), text=text)
    db.session.add(r)
    db.session.commit()
    return jsonify(ok=True, msg='Отзыв отправлен!')


@api_bp.route('/contact', methods=['POST'])
def contact():
    data    = request.get_json(silent=True) or request.form
    name    = str(data.get('name','')).strip()
    email   = str(data.get('email','')).strip()
    text    = str(data.get('text','')).strip()
    phone   = str(data.get('phone','')).strip()
    subject = str(data.get('subject','')).strip()
    if not name or not email or not text:
        return jsonify(ok=False, msg='Заполните обязательные поля'), 400
    db.session.add(Message(name=name, email=email, phone=phone,
                           subject=subject, text=text))
    db.session.commit()
    return jsonify(ok=True, msg='Сообщение отправлено!')


@api_bp.route('/coupon/check', methods=['POST'])
def check_coupon():
    code = str(request.get_json(silent=True, force=True).get('code','')).strip().upper()
    c = Coupon.query.filter_by(code=code, active=True).first()
    if c:
        return jsonify(ok=True, discount=c.discount, code=c.code)
    return jsonify(ok=False, msg='Промокод не найден'), 404
