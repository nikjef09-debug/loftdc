"""
LOFT DC — Report Generator
Уникальные отчёты для каждого типа: продажи, финансы, заказы, товары.
PDF в dev, HTML в exe.
"""
import io
from datetime import datetime

COMPANY = {'name':'ООО «ЛОФТ ДС»','inn':'7700000000','address':'г. Москва, ул. Лофтовая, д. 1, оф. 101'}

def _fmt(n):
    if n is None: return '0 ₽'
    return f"{int(n):,}".replace(",", "\u2009") + "\u00a0₽"

def _pct(a, b):
    return f"{a/b*100:.1f}%" if b else "—"

# ──────────────────────────────────────────────────────────────────────────────
# HTML (exe mode)
# ──────────────────────────────────────────────────────────────────────────────

_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=PT+Serif:wght@400;700&family=PT+Mono&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'PT Serif',Georgia,serif;font-size:13px;color:#111;background:#fff;padding:28px 36px;max-width:960px;margin:0 auto;line-height:1.5}
.print-btn{position:fixed;top:16px;right:16px;background:#111;color:#fff;font-family:'PT Mono',monospace;font-size:10px;letter-spacing:2px;text-transform:uppercase;padding:10px 20px;border:none;cursor:pointer;z-index:100}
.doc-header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #111;padding-bottom:14px;margin-bottom:18px}
.doc-logo{font-size:26px;font-weight:700;letter-spacing:4px}
.doc-logo span{color:#8a7a60}
.doc-meta{text-align:right;font-family:'PT Mono',monospace;font-size:10px;color:#555;line-height:1.7}
.title-bar{background:#111;color:#fff;padding:10px 16px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center}
.title-bar .t{font-size:13px;letter-spacing:1px;color:#d4c5a9;font-family:'PT Mono',monospace;font-weight:700}
.title-bar .d{font-size:11px;color:#aaa;font-family:'PT Mono',monospace}
.kpi-grid{display:grid;gap:10px;margin:14px 0}
.kpi-4{grid-template-columns:repeat(4,1fr)}
.kpi-3{grid-template-columns:repeat(3,1fr)}
.kpi-2{grid-template-columns:repeat(2,1fr)}
.kpi{background:#f9f8f4;border:1px solid #e0ded8;padding:14px 16px}
.kpi .v{font-size:22px;font-weight:700;color:#111;margin-bottom:3px}
.kpi .v.green{color:#27ae60}
.kpi .v.red{color:#c0392b}
.kpi .v.accent{color:#8a7a60}
.kpi .l{font-family:'PT Mono',monospace;font-size:9px;letter-spacing:1.5px;text-transform:uppercase;color:#888}
h2{font-size:14px;font-weight:700;margin:22px 0 10px;text-transform:uppercase;letter-spacing:.8px;border-bottom:1px solid #ddd;padding-bottom:5px;display:flex;align-items:center;gap:8px}
table{width:100%;border-collapse:collapse;margin:8px 0;font-size:12px}
th{background:#111;color:#fff;padding:8px 10px;text-align:left;font-family:'PT Mono',monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;white-space:nowrap}
td{padding:8px 10px;border-bottom:1px solid #eee;vertical-align:middle}
tr:nth-child(even){background:#fafafa}
tr:last-child td{border-bottom:none}
.bar-wrap{background:#eee;height:8px;border-radius:2px;flex:1}
.bar{background:#8a7a60;height:8px;border-radius:2px}
.notice{background:#faf8f4;border-left:3px solid #d4c5a9;padding:12px 16px;font-size:12px;font-style:italic;color:#666;margin:14px 0}
.section-divider{height:1px;background:linear-gradient(to right,#ddd,transparent);margin:20px 0}
.badge{display:inline-block;padding:2px 8px;border-radius:3px;font-family:'PT Mono',monospace;font-size:9px;font-weight:700;letter-spacing:1px}
.badge-green{background:#e8f5e9;color:#2e7d32}
.badge-red{background:#ffebee;color:#c62828}
.badge-yellow{background:#fff8e1;color:#e65100}
.badge-blue{background:#e3f2fd;color:#1565c0}
.footer{margin-top:32px;border-top:1px solid #ddd;padding-top:10px;font-family:'PT Mono',monospace;font-size:9px;color:#aaa;display:flex;justify-content:space-between}
@media print{.print-btn{display:none}@page{margin:15mm 20mm}}
</style>
"""

def _html_wrap(title, period_str, body, rep_id):
    return f"""<!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>{_CSS}</head><body>
<button class="print-btn" onclick="window.print()">🖨 Печать</button>
<div class="doc-header">
  <div><div class="doc-logo">LOFT<span>DC</span></div>
  <div style="font-family:'PT Mono',monospace;font-size:9px;color:#888;margin-top:3px">МЕБЕЛЬ И ДЕКОР</div></div>
  <div class="doc-meta">{COMPANY['name']}<br>ИНН {COMPANY['inn']}<br>{COMPANY['address']}</div>
</div>
<div class="title-bar">
  <div class="t">{title.upper()}</div>
  <div class="d">{period_str}</div>
</div>
{body}
<div class="footer">
  <span>Отчёт #{rep_id} · {datetime.now().strftime('%d.%m.%Y %H:%M')}</span>
  <span>loftdc.ru</span>
</div>
</body></html>"""


def _html_sales(d, rep, period_str):
    """Отчёт по продажам — топ товаров, категории, конверсия."""
    max_rev = d['top_products'][0]['revenue'] if d['top_products'] else 1

    prod_rows = ''
    for i, p in enumerate(d['top_products'], 1):
        pct = int(p['revenue'] / max_rev * 100) if max_rev else 0
        prod_rows += f"""<tr>
          <td style="font-family:'PT Mono',monospace;color:#888">{i}</td>
          <td style="font-size:18px">{p['emoji']}</td>
          <td>{p['name']}</td>
          <td style="text-align:center;font-family:'PT Mono',monospace">{p['qty']}</td>
          <td style="text-align:right;font-weight:700;color:#8a7a60">{_fmt(p['revenue'])}</td>
          <td style="width:80px"><div class="bar-wrap"><div class="bar" style="width:{pct}%"></div></div></td>
        </tr>"""

    cat_rows = ''
    total_rev = sum(v['revenue'] for _,v in d['top_cats']) or 1
    for cat, v in d['top_cats']:
        cat_rows += f"""<tr>
          <td>{cat}</td>
          <td style="text-align:center;font-family:'PT Mono',monospace">{v['qty']}</td>
          <td style="text-align:right;font-weight:700">{_fmt(v['revenue'])}</td>
          <td style="font-family:'PT Mono',monospace;color:#888">{_pct(v['revenue'],total_rev)}</td>
        </tr>"""

    body = f"""
    <div class="kpi-grid kpi-4">
      <div class="kpi"><div class="v green">{_fmt(d['income'])}</div><div class="l">Общая выручка</div></div>
      <div class="kpi"><div class="v">{d['total_orders']}</div><div class="l">Заказов</div></div>
      <div class="kpi"><div class="v accent">{_fmt(d['avg_order'])}</div><div class="l">Средний чек</div></div>
      <div class="kpi"><div class="v">{_pct(d['delivered'],d['total_orders'])}</div><div class="l">Конверсия</div></div>
    </div>
    <div class="kpi-grid kpi-4">
      <div class="kpi"><div class="v">{d['delivered']}</div><div class="l">Доставлено</div></div>
      <div class="kpi"><div class="v red">{d['cancelled']}</div><div class="l">Отменено</div></div>
      <div class="kpi"><div class="v">{d['in_progress']}</div><div class="l">В обработке</div></div>
      <div class="kpi"><div class="v">{d['sent']}</div><div class="l">Отправлено</div></div>
    </div>
    <h2>🏆 Топ товаров по выручке</h2>
    <table><thead><tr><th>#</th><th></th><th>Товар</th><th style="text-align:center">Кол-во</th><th style="text-align:right">Выручка</th><th>Доля</th></tr></thead>
    <tbody>{prod_rows or '<tr><td colspan="6" style="text-align:center;color:#888;padding:20px">Нет данных</td></tr>'}</tbody></table>
    <h2>📦 Продажи по категориям</h2>
    <table><thead><tr><th>Категория</th><th style="text-align:center">Кол-во</th><th style="text-align:right">Выручка</th><th>Доля</th></tr></thead>
    <tbody>{cat_rows or '<tr><td colspan="4" style="text-align:center;color:#888;padding:20px">Нет данных</td></tr>'}</tbody></table>
    """
    return _html_wrap('Отчёт по продажам', period_str, body, rep.id)


def _html_finance(d, rep, period_str):
    """Финансовый отчёт — все транзакции, баланс."""
    tx_rows = ''
    for t in d['txs']:
        colors = {'income':('badge-green','+'),'refund':('badge-red','−'),'expense':('badge-yellow','−')}
        badge, sign = colors.get(t.type, ('badge-blue',''))
        tx_rows += f"""<tr>
          <td style="font-family:'PT Mono',monospace;font-size:11px">{t.created_at.strftime('%d.%m.%Y %H:%M')}</td>
          <td><span class="badge {badge}">{t.type_label}</span></td>
          <td>{t.description}</td>
          <td style="font-family:'PT Mono',monospace;font-size:11px;color:#888">
            {'#'+str(t.order_id) if t.order_id else '—'}</td>
          <td style="text-align:right;font-weight:700;
              color:{'#27ae60' if t.type=='income' else '#c0392b'}">{sign}{_fmt(t.amount)}</td>
        </tr>"""

    body = f"""
    <div class="kpi-grid kpi-4">
      <div class="kpi"><div class="v green">{_fmt(d['income'])}</div><div class="l">Приход</div></div>
      <div class="kpi"><div class="v red">{_fmt(d['refunds'])}</div><div class="l">Возвраты</div></div>
      <div class="kpi"><div class="v red">{_fmt(d['expense'])}</div><div class="l">Расходы</div></div>
      <div class="kpi"><div class="v {'green' if d['net']>=0 else 'red'}">{_fmt(d['net'])}</div><div class="l">Чистая прибыль</div></div>
    </div>
    <div class="kpi-grid kpi-3">
      <div class="kpi"><div class="v">{len([t for t in d['txs'] if t.type=='income'])}</div><div class="l">Транзакций прихода</div></div>
      <div class="kpi"><div class="v red">{len([t for t in d['txs'] if t.type=='refund'])}</div><div class="l">Возвратов</div></div>
      <div class="kpi"><div class="v">{len(d['txs'])}</div><div class="l">Всего транзакций</div></div>
    </div>
    <h2>💳 Все транзакции</h2>
    <table><thead><tr><th>Дата</th><th>Тип</th><th>Описание</th><th>Заказ</th><th style="text-align:right">Сумма</th></tr></thead>
    <tbody>{tx_rows or '<tr><td colspan="5" style="text-align:center;color:#888;padding:20px">Нет транзакций</td></tr>'}</tbody></table>
    """
    return _html_wrap('Финансовый отчёт', period_str, body, rep.id)


def _html_orders(d, rep, period_str):
    """Отчёт по заказам — статусы, оплата, доставка."""
    status_colors = {'Новый':'badge-blue','В обработке':'badge-yellow','Отправлен':'badge-yellow',
                     'Доставлен':'badge-green','Отменён':'badge-red'}
    orders_rows = ''
    for o in d['orders']:
        badge = status_colors.get(o.status,'badge-blue')
        orders_rows += f"""<tr>
          <td style="font-family:'PT Mono',monospace">#{o.id}</td>
          <td>{o.user_name}</td>
          <td><span class="badge {badge}">{o.status}</span></td>
          <td>{o.payment}</td>
          <td>{o.delivery}</td>
          <td style="text-align:right;font-family:'PT Mono',monospace;font-weight:700">{_fmt(o.total)}</td>
          <td style="font-family:'PT Mono',monospace;font-size:11px;color:#888">{o.created_at.strftime('%d.%m.%Y')}</td>
        </tr>"""

    pay_rows = ''
    for pay, v in sorted(d['payment_counts'].items(), key=lambda x: x[1]['revenue'], reverse=True):
        pay_rows += f"<tr><td>{pay or '—'}</td><td style='text-align:center'>{v['count']}</td><td style='text-align:right;font-weight:700'>{_fmt(v['revenue'])}</td></tr>"

    del_rows = ''
    for deliv, cnt in sorted(d['delivery_counts'].items(), key=lambda x: x[1], reverse=True):
        del_rows += f"<tr><td>{deliv or '—'}</td><td style='text-align:center'>{cnt}</td><td style='text-align:right'>{_pct(cnt, d['total_orders'])}</td></tr>"

    status_rows = ''
    for status, cnt in sorted(d['status_counts'].items(), key=lambda x: x[1], reverse=True):
        badge = status_colors.get(status,'badge-blue')
        status_rows += f"<tr><td><span class='badge {badge}'>{status}</span></td><td style='text-align:center;font-weight:700'>{cnt}</td><td style='text-align:right'>{_pct(cnt,d['total_orders'])}</td></tr>"

    body = f"""
    <div class="kpi-grid kpi-4">
      <div class="kpi"><div class="v">{d['total_orders']}</div><div class="l">Всего заказов</div></div>
      <div class="kpi"><div class="v green">{d['delivered']}</div><div class="l">Доставлено</div></div>
      <div class="kpi"><div class="v red">{d['cancelled']}</div><div class="l">Отменено</div></div>
      <div class="kpi"><div class="v accent">{_fmt(d['avg_order'])}</div><div class="l">Средний чек</div></div>
    </div>
    <div class="kpi-grid kpi-3" style="margin-bottom:16px">
      <div class="kpi"><div class="v">{d['new']}</div><div class="l">Новых</div></div>
      <div class="kpi"><div class="v">{d['in_progress']}</div><div class="l">В обработке</div></div>
      <div class="kpi"><div class="v">{d['sent']}</div><div class="l">Отправлено</div></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div>
        <h2>📊 По статусам</h2>
        <table><thead><tr><th>Статус</th><th style="text-align:center">Кол-во</th><th style="text-align:right">Доля</th></tr></thead>
        <tbody>{status_rows}</tbody></table>
      </div>
      <div>
        <h2>💳 По способам оплаты</h2>
        <table><thead><tr><th>Оплата</th><th style="text-align:center">Кол-во</th><th style="text-align:right">Выручка</th></tr></thead>
        <tbody>{pay_rows}</tbody></table>
      </div>
    </div>
    <h2>🚚 По способам доставки</h2>
    <table><thead><tr><th>Доставка</th><th style="text-align:center">Кол-во</th><th style="text-align:right">Доля</th></tr></thead>
    <tbody>{del_rows}</tbody></table>
    <h2>📋 Все заказы за период</h2>
    <table><thead><tr><th>#</th><th>Клиент</th><th>Статус</th><th>Оплата</th><th>Доставка</th><th style="text-align:right">Сумма</th><th>Дата</th></tr></thead>
    <tbody>{orders_rows or '<tr><td colspan="7" style="text-align:center;color:#888;padding:20px">Нет заказов</td></tr>'}</tbody></table>
    """
    return _html_wrap('Отчёт по заказам', period_str, body, rep.id)


def _html_products(d, rep, period_str):
    """Отчёт по товарам — топ, категории, остатки."""
    from app.models import Product as ProductModel
    products_all = ProductModel.query.order_by(ProductModel.price.desc()).all()

    max_rev = d['top_products'][0]['revenue'] if d['top_products'] else 1
    prod_rows = ''
    for i, p in enumerate(d['top_products'], 1):
        pct = int(p['revenue'] / max_rev * 100) if max_rev else 0
        prod_rows += f"""<tr>
          <td style="font-family:'PT Mono',monospace;color:#888">{i}</td>
          <td style="font-size:18px">{p['emoji']}</td>
          <td>{p['name']}</td>
          <td style="text-align:center;font-family:'PT Mono',monospace">{p['qty']}</td>
          <td style="text-align:right;font-weight:700;color:#8a7a60">{_fmt(p['revenue'])}</td>
          <td style="width:70px"><div class="bar-wrap"><div class="bar" style="width:{pct}%"></div></div></td>
        </tr>"""

    cat_rows = ''
    total_rev = sum(v['revenue'] for _,v in d['top_cats']) or 1
    for cat, v in d['top_cats']:
        cat_rows += f"""<tr>
          <td>{cat}</td>
          <td style="text-align:center">{v['qty']}</td>
          <td style="text-align:right;font-weight:700">{_fmt(v['revenue'])}</td>
          <td>{_pct(v['revenue'],total_rev)}</td>
        </tr>"""

    all_rows = ''
    for p in products_all[:40]:
        stock_badge = '<span class="badge badge-green">В наличии</span>' if p.stock > 0 else '<span class="badge badge-red">Нет</span>'
        all_rows += f"""<tr>
          <td style="font-size:18px">{p.emoji}</td>
          <td>{p.name}</td>
          <td>{p.category}</td>
          <td style="text-align:right;font-family:'PT Mono',monospace">{_fmt(p.price)}</td>
          <td style="text-align:center">{p.stock}</td>
          <td>{stock_badge}</td>
        </tr>"""

    total_stock_value = sum(p.price * p.stock for p in products_all)
    in_stock = sum(1 for p in products_all if p.stock > 0)
    out_stock = sum(1 for p in products_all if p.stock == 0)

    body = f"""
    <div class="kpi-grid kpi-4">
      <div class="kpi"><div class="v">{d['all_products']}</div><div class="l">Всего товаров</div></div>
      <div class="kpi"><div class="v green">{in_stock}</div><div class="l">В наличии</div></div>
      <div class="kpi"><div class="v red">{out_stock}</div><div class="l">Нет в наличии</div></div>
      <div class="kpi"><div class="v accent">{_fmt(total_stock_value)}</div><div class="l">Стоимость склада</div></div>
    </div>
    <h2>🏆 Топ продаваемых товаров</h2>
    <table><thead><tr><th>#</th><th></th><th>Товар</th><th style="text-align:center">Продано</th><th style="text-align:right">Выручка</th><th>Доля</th></tr></thead>
    <tbody>{prod_rows or '<tr><td colspan="6" style="text-align:center;color:#888;padding:20px">Нет данных о продажах</td></tr>'}</tbody></table>
    <h2>📦 Продажи по категориям</h2>
    <table><thead><tr><th>Категория</th><th style="text-align:center">Продано</th><th style="text-align:right">Выручка</th><th>Доля</th></tr></thead>
    <tbody>{cat_rows or '<tr><td colspan="4" style="text-align:center;color:#888;padding:20px">Нет данных</td></tr>'}</tbody></table>
    <h2>📋 Весь каталог</h2>
    <table><thead><tr><th></th><th>Название</th><th>Категория</th><th style="text-align:right">Цена</th><th style="text-align:center">Остаток</th><th>Статус</th></tr></thead>
    <tbody>{all_rows}</tbody></table>
    """
    return _html_wrap('Отчёт по товарам', period_str, body, rep.id)


def generate_report_html(rep, d) -> str:
    period_str = f"{rep.period_from.strftime('%d.%m.%Y')} — {rep.period_to.strftime('%d.%m.%Y')}" if rep.period_from else ''
    generators = {
        'sales':    _html_sales,
        'finance':  _html_finance,
        'orders':   _html_orders,
        'products': _html_products,
    }
    fn = generators.get(rep.type, _html_sales)
    return fn(d, rep, period_str)


# ──────────────────────────────────────────────────────────────────────────────
# PDF (dev mode)
# ──────────────────────────────────────────────────────────────────────────────

def _get_fonts():
    import os, sys
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    if getattr(sys, 'frozen', False):
        bd = sys._MEIPASS
    else:
        bd = os.path.dirname(os.path.abspath(__file__))
    for r, b in [
        (os.path.join(bd,'fonts','arial.ttf'), os.path.join(bd,'fonts','arialbd.ttf')),
        ('C:/Windows/Fonts/arial.ttf','C:/Windows/Fonts/arialbd.ttf'),
        ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
    ]:
        if os.path.exists(r):
            try:
                pdfmetrics.registerFont(TTFont('RF', r))
                pdfmetrics.registerFont(TTFont('RF-B', b if os.path.exists(b) else r))
                return 'RF','RF-B'
            except: pass
    return 'Helvetica','Helvetica-Bold'


def generate_report_pdf(rep, d) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle,
                                     Paragraph, Spacer, HRFlowable)
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT

    F, FB = _get_fonts()
    BLACK  = colors.HexColor('#0a0a0a')
    ACCENT = colors.HexColor('#8a7a60')
    LIGHT  = colors.HexColor('#F4F3EF')
    WHITE  = colors.white
    GREEN  = colors.HexColor('#27ae60')
    RED    = colors.HexColor('#c0392b')
    YELLOW = colors.HexColor('#e67e22')
    GRAY   = colors.HexColor('#666660')
    BORDER = colors.HexColor('#E0DED8')

    def S(name, size=10, bold=False, color=None, align=TA_LEFT, leading=None):
        return ParagraphStyle(name, fontName=FB if bold else F, fontSize=size,
                              leading=leading or size+4, textColor=color or BLACK,
                              alignment=align)

    buf = io.BytesIO()
    W = 174*mm
    doc = SimpleDocTemplate(buf, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm, topMargin=18*mm, bottomMargin=18*mm,
        title=rep.title, author='LOFT DC')

    period_str = f"{rep.period_from.strftime('%d.%m.%Y')} — {rep.period_to.strftime('%d.%m.%Y')}" if rep.period_from else ''
    type_labels = {'sales':'Отчёт по продажам','finance':'Финансовый отчёт',
                   'orders':'Отчёт по заказам','products':'Отчёт по товарам'}
    title = type_labels.get(rep.type, rep.title)

    story = []

    # Шапка
    hdr = Table([[
        Paragraph('<b>LOFT</b>DC', ParagraphStyle('logo',fontName=FB,fontSize=22,textColor=BLACK)),
        Paragraph(f'{COMPANY["name"]}<br/>ИНН {COMPANY["inn"]}<br/>{COMPANY["address"]}',
                  ParagraphStyle('meta',fontName=F,fontSize=8,leading=12,textColor=GRAY,alignment=TA_RIGHT))
    ]], colWidths=[W*0.4, W*0.6])
    hdr.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),1.5,BLACK),('BOTTOMPADDING',(0,0),(-1,-1),8)]))
    story += [hdr, Spacer(1,4*mm)]

    # Полоса заголовка
    tb = Table([[
        Paragraph(title.upper(), ParagraphStyle('t',fontName=FB,fontSize=11,textColor=WHITE,leading=14)),
        Paragraph(f'№{rep.id} · {period_str}', ParagraphStyle('d',fontName=F,fontSize=9,textColor=ACCENT,leading=14,alignment=TA_RIGHT))
    ]], colWidths=[W*0.6, W*0.4])
    tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),BLACK),('TOPPADDING',(0,0),(-1,-1),8),
        ('BOTTOMPADDING',(0,0),(-1,-1),8),('LEFTPADDING',(0,0),(0,-1),10),('RIGHTPADDING',(-1,0),(-1,-1),10),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
    story += [tb, Spacer(1,4*mm)]

    def _kpi_table(items):
        """items = [(label, value, color), ...]"""
        n = len(items)
        cw = W / n
        data = []
        for label, val, clr in items:
            data.append([
                Paragraph(label, ParagraphStyle('kl',fontName=F,fontSize=8,textColor=GRAY,leading=10)),
                Paragraph(str(val), ParagraphStyle('kv',fontName=FB,fontSize=16,textColor=clr,leading=20))
            ])
        t = Table(data, colWidths=[cw]*n)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),0.5,BORDER),
            ('INNERGRID',(0,0),(-1,-1),0.5,BORDER),('TOPPADDING',(0,0),(-1,-1),10),
            ('BOTTOMPADDING',(0,0),(-1,-1),10),('LEFTPADDING',(0,0),(-1,-1),12),('VALIGN',(0,0),(-1,-1),'TOP')]))
        return t

    def _section(title_text):
        return [Spacer(1,4*mm),
                Paragraph(title_text, ParagraphStyle('h2',fontName=FB,fontSize=11,textColor=BLACK,leading=14,spaceBefore=2)),
                HRFlowable(width=W,thickness=0.5,color=BORDER,spaceAfter=3)]

    def _data_table(headers, rows, col_widths, alignments=None):
        data = [headers] + rows
        t = Table(data, colWidths=col_widths, repeatRows=1)
        style = [
            ('BACKGROUND',(0,0),(-1,0),BLACK),('TEXTCOLOR',(0,0),(-1,0),WHITE),
            ('FONTNAME',(0,0),(-1,0),FB),('FONTSIZE',(0,0),(-1,0),8),
            ('TOPPADDING',(0,0),(-1,0),7),('BOTTOMPADDING',(0,0),(-1,0),7),
            ('FONTNAME',(0,1),(-1,-1),F),('FONTSIZE',(0,1),(-1,-1),9),
            ('ROWBACKGROUNDS',(0,1),(-1,-1),[WHITE,LIGHT]),
            ('GRID',(0,0),(-1,-1),0.5,BORDER),
            ('TOPPADDING',(0,1),(-1,-1),5),('BOTTOMPADDING',(0,1),(-1,-1),5),
            ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ]
        if alignments:
            for col, align in alignments:
                style.append(('ALIGN',(col,0),(col,-1),align))
        t.setStyle(TableStyle(style))
        return t

    # ── Содержимое по типу ────────────────────────────────────────────────────

    if rep.type == 'sales':
        story.append(_kpi_table([
            ('ВЫРУЧКА', _fmt(d['income']), GREEN),
            ('ЗАКАЗОВ', str(d['total_orders']), BLACK),
            ('СРЕДНИЙ ЧЕК', _fmt(d['avg_order']), ACCENT),
            ('КОНВЕРСИЯ', _pct(d['delivered'],d['total_orders']), BLACK),
        ]))
        story.append(Spacer(1,3*mm))
        story.append(_kpi_table([
            ('ДОСТАВЛЕНО', str(d['delivered']), GREEN),
            ('ОТМЕНЕНО', str(d['cancelled']), RED),
            ('В ОБРАБОТКЕ', str(d['in_progress']), YELLOW),
            ('ОТПРАВЛЕНО', str(d['sent']), BLACK),
        ]))
        story += _section('🏆 Топ товаров по выручке')
        rows = []
        for i,p in enumerate(d['top_products'],1):
            rows.append([str(i), p['emoji'], Paragraph(p['name'],S('pn',9)),
                         str(p['qty']), _fmt(p['revenue'])])
        story.append(_data_table(['#','','Товар','Кол-во','Выручка'],
                                  rows or [['—','','Нет данных','','']],
                                  [10*mm,10*mm,90*mm,20*mm,44*mm],[(3,'CENTER'),(4,'RIGHT')]))
        story += _section('📦 По категориям')
        rows = []
        total_rev = sum(v['revenue'] for _,v in d['top_cats']) or 1
        for cat,v in d['top_cats']:
            rows.append([Paragraph(cat,S('cn',9)), str(v['qty']), _fmt(v['revenue']), _pct(v['revenue'],total_rev)])
        story.append(_data_table(['Категория','Кол-во','Выручка','Доля'],
                                  rows or [['Нет данных','','','']],
                                  [60*mm,30*mm,50*mm,34*mm],[(1,'CENTER'),(2,'RIGHT'),(3,'RIGHT')]))

    elif rep.type == 'finance':
        story.append(_kpi_table([
            ('ПРИХОД', _fmt(d['income']), GREEN),
            ('ВОЗВРАТЫ', _fmt(d['refunds']), RED),
            ('РАСХОДЫ', _fmt(d['expense']), YELLOW),
            ('ЧИСТАЯ ПРИБЫЛЬ', _fmt(d['net']), GREEN if d['net']>=0 else RED),
        ]))
        story.append(Spacer(1,3*mm))
        story.append(_kpi_table([
            ('ТРАНЗАКЦИЙ ПРИХОДА', str(len([t for t in d['txs'] if t.type=='income'])), GREEN),
            ('ВОЗВРАТОВ', str(len([t for t in d['txs'] if t.type=='refund'])), RED),
            ('ВСЕГО ТРАНЗАКЦИЙ', str(len(d['txs'])), BLACK),
        ]))
        story += _section('💳 Все транзакции')
        type_colors = {'income':GREEN,'refund':RED,'expense':YELLOW}
        rows = []
        for t in d['txs'][:50]:
            sign = '+' if t.type=='income' else '−'
            clr  = type_colors.get(t.type, BLACK)
            rows.append([
                t.created_at.strftime('%d.%m.%Y'),
                Paragraph(t.type_label, ParagraphStyle('tl',fontName=FB,fontSize=9,textColor=clr,leading=11)),
                Paragraph(t.description[:45],S('td',9)),
                f'#{t.order_id}' if t.order_id else '—',
                Paragraph(f'{sign}{_fmt(t.amount)}', ParagraphStyle('ta',fontName=FB,fontSize=9,textColor=clr,leading=11,alignment=TA_RIGHT))
            ])
        story.append(_data_table(['Дата','Тип','Описание','Заказ','Сумма'],
                                  rows or [['—','—','Нет транзакций','','']],
                                  [24*mm,22*mm,76*mm,16*mm,36*mm],[(4,'RIGHT')]))

    elif rep.type == 'orders':
        story.append(_kpi_table([
            ('ВСЕГО ЗАКАЗОВ', str(d['total_orders']), BLACK),
            ('ДОСТАВЛЕНО', str(d['delivered']), GREEN),
            ('ОТМЕНЕНО', str(d['cancelled']), RED),
            ('СРЕДНИЙ ЧЕК', _fmt(d['avg_order']), ACCENT),
        ]))
        story.append(Spacer(1,3*mm))
        story.append(_kpi_table([
            ('НОВЫХ', str(d['new']), BLACK),
            ('В ОБРАБОТКЕ', str(d['in_progress']), YELLOW),
            ('ОТПРАВЛЕНО', str(d['sent']), BLACK),
        ]))
        story += _section('📊 По статусам')
        rows = [[Paragraph(s,S('ss',9)), str(c), _pct(c,d['total_orders'])]
                for s,c in sorted(d['status_counts'].items(),key=lambda x:x[1],reverse=True)]
        story.append(_data_table(['Статус','Кол-во','Доля'],rows or [['Нет','','']],
                                  [70*mm,52*mm,52*mm],[(1,'CENTER'),(2,'RIGHT')]))
        story += _section('💳 По способам оплаты')
        rows = [[Paragraph(p or '—',S('pp',9)), str(v['count']), _fmt(v['revenue'])]
                for p,v in sorted(d['payment_counts'].items(),key=lambda x:x[1]['revenue'],reverse=True)]
        story.append(_data_table(['Оплата','Кол-во','Выручка'],rows or [['—','','']],
                                  [80*mm,40*mm,54*mm],[(1,'CENTER'),(2,'RIGHT')]))
        story += _section('🚚 По способам доставки')
        rows = [[Paragraph(dv or '—',S('dp',9)), str(cnt), _pct(cnt,d['total_orders'])]
                for dv,cnt in sorted(d['delivery_counts'].items(),key=lambda x:x[1],reverse=True)]
        story.append(_data_table(['Доставка','Кол-во','Доля'],rows or [['—','','']],
                                  [80*mm,40*mm,54*mm],[(1,'CENTER'),(2,'RIGHT')]))
        story += _section('📋 Все заказы')
        rows = [[f'#{o.id}',Paragraph(o.user_name,S('un',9)),o.status,
                 Paragraph(o.payment,S('op',9)),_fmt(o.total),o.created_at.strftime('%d.%m.%Y')]
                for o in d['orders'][:40]]
        story.append(_data_table(['#','Клиент','Статус','Оплата','Сумма','Дата'],
                                  rows or [['—','—','—','—','—','—']],
                                  [14*mm,42*mm,26*mm,36*mm,30*mm,22*mm],[(4,'RIGHT')]))

    elif rep.type == 'products':
        from app.models import Product as PM
        products_all = PM.query.order_by(PM.price.desc()).all()
        in_stock = sum(1 for p in products_all if p.stock > 0)
        out_stock = sum(1 for p in products_all if p.stock == 0)
        total_stock_val = sum(p.price * p.stock for p in products_all)
        story.append(_kpi_table([
            ('ВСЕГО ТОВАРОВ', str(d['all_products']), BLACK),
            ('В НАЛИЧИИ', str(in_stock), GREEN),
            ('НЕТ В НАЛИЧИИ', str(out_stock), RED),
            ('СТОИМОСТЬ СКЛАДА', _fmt(total_stock_val), ACCENT),
        ]))
        story += _section('🏆 Топ продаваемых товаров')
        rows = [[str(i),p['emoji'],Paragraph(p['name'],S('pn',9)),str(p['qty']),_fmt(p['revenue'])]
                for i,p in enumerate(d['top_products'],1)]
        story.append(_data_table(['#','','Товар','Кол-во','Выручка'],
                                  rows or [['—','','Нет данных о продажах','','']],
                                  [10*mm,10*mm,90*mm,20*mm,44*mm],[(3,'CENTER'),(4,'RIGHT')]))
        story += _section('📦 По категориям')
        total_rev = sum(v['revenue'] for _,v in d['top_cats']) or 1
        rows = [[Paragraph(cat,S('cn',9)),str(v['qty']),_fmt(v['revenue']),_pct(v['revenue'],total_rev)]
                for cat,v in d['top_cats']]
        story.append(_data_table(['Категория','Кол-во','Выручка','Доля'],
                                  rows or [['Нет данных','','','']],
                                  [60*mm,30*mm,50*mm,34*mm],[(1,'CENTER'),(2,'RIGHT'),(3,'RIGHT')]))
        story += _section('📋 Весь каталог')
        rows = [[p.emoji,Paragraph(p.name,S('pn',9)),p.category,_fmt(p.price),str(p.stock),
                 'Есть' if p.stock>0 else 'Нет']
                for p in products_all[:40]]
        story.append(_data_table(['','Название','Категория','Цена','Остаток','Статус'],
                                  rows or [['','Нет товаров','','','','']],
                                  [8*mm,60*mm,32*mm,28*mm,18*mm,28*mm],[(3,'RIGHT'),(4,'CENTER')]))

    # Подписи
    story.append(Spacer(1,8*mm))
    sign_t = Table([[
        [Paragraph('Руководитель',S('sr',8,color=GRAY)),
         HRFlowable(width=W*0.45,thickness=0.5,color=GRAY,spaceAfter=3),
         Paragraph('_______________________',S('sl'))],
        [Paragraph('Ответственный',S('sr',8,color=GRAY)),
         HRFlowable(width=W*0.45,thickness=0.5,color=GRAY,spaceAfter=3),
         Paragraph('_______________________',S('sl'))],
    ]], colWidths=[W*0.5,W*0.5])
    sign_t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),16)]))
    story.append(sign_t)
    story.append(Spacer(1,4*mm))
    story.append(HRFlowable(width=W,thickness=0.5,color=LIGHT))
    story.append(Paragraph(
        f'Отчёт #{rep.id} · {datetime.now().strftime("%d.%m.%Y %H:%M")} · loftdc.ru',
        ParagraphStyle('ft',fontName=F,fontSize=7,textColor=GRAY,leading=10,alignment=TA_CENTER,spaceBefore=4)
    ))

    doc.build(story)
    return buf.getvalue()
