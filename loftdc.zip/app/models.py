from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager


# ─── USER ───────────────────────────────────────────────────────────────────

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id            = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String(120), nullable=False)
    email         = db.Column(db.String(120), unique=True, nullable=False)
    phone         = db.Column(db.String(30), default='')
    address       = db.Column(db.String(250), default='')
    password_hash = db.Column(db.String(256), nullable=False)
    role          = db.Column(db.String(20), default='user')   # admin | manager | user
    is_active     = db.Column(db.Boolean, default=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    last_login    = db.Column(db.DateTime, nullable=True)

    orders    = db.relationship('Order',    backref='customer', lazy='dynamic')
    reviews   = db.relationship('Review',   backref='author_user', lazy='dynamic')
    wishlist  = db.relationship('Wishlist', backref='user', lazy='dynamic', cascade='all,delete-orphan')

    def set_password(self, pw):   self.password_hash = generate_password_hash(pw)
    def check_password(self, pw): return check_password_hash(self.password_hash, pw)

    @property
    def is_admin(self):   return self.role == 'admin'
    @property
    def is_manager(self): return self.role in ('admin', 'manager')

    def to_dict(self):
        return dict(id=self.id, name=self.name, email=self.email,
                    phone=self.phone, role=self.role, address=self.address,
                    created_at=self.created_at.strftime('%d.%m.%Y'))


@login_manager.user_loader
def load_user(uid):
    return User.query.get(int(uid))


# ─── PRODUCT ────────────────────────────────────────────────────────────────

class Product(db.Model):
    __tablename__ = 'products'
    id          = db.Column(db.Integer, primary_key=True)
    name        = db.Column(db.String(200), nullable=False)
    category    = db.Column(db.String(50),  nullable=False)
    price       = db.Column(db.Integer,     nullable=False)
    old_price   = db.Column(db.Integer,     nullable=True)
    description = db.Column(db.Text,        default='')
    emoji       = db.Column(db.String(10),  default='📦')
    material    = db.Column(db.String(100), default='')
    size        = db.Column(db.String(100), default='')
    badge       = db.Column(db.String(20),  default='')  # new | sale | hit | ''
    badge_class = db.Column(db.String(20),  default='')
    stock       = db.Column(db.Integer,     default=0)
    is_active   = db.Column(db.Boolean,     default=True)
    created_at  = db.Column(db.DateTime,    default=datetime.utcnow)

    reviews   = db.relationship('Review',   backref='product', lazy='dynamic', cascade='all,delete-orphan')
    wishlist  = db.relationship('Wishlist', backref='product', lazy='dynamic', cascade='all,delete-orphan')

    @property
    def avg_rating(self):
        revs = self.reviews.filter_by(approved=True).all()
        return round(sum(r.rating for r in revs) / len(revs), 1) if revs else None

    @property
    def review_count(self):
        return self.reviews.filter_by(approved=True).count()

    def to_dict(self):
        return dict(id=self.id, name=self.name, cat=self.category,
                    price=self.price, oldPrice=self.old_price,
                    desc=self.description, emoji=self.emoji,
                    material=self.material, size=self.size,
                    badge=self.badge, badgeClass=self.badge_class,
                    stock=self.stock, rating=self.avg_rating,
                    reviews=self.review_count)


# ─── ORDER ──────────────────────────────────────────────────────────────────

class Order(db.Model):
    __tablename__ = 'orders'
    id          = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    user_name   = db.Column(db.String(120), default='')
    phone       = db.Column(db.String(30),  default='')
    address     = db.Column(db.String(250), default='')
    payment     = db.Column(db.String(50),  default='')
    delivery    = db.Column(db.String(50),  default='')
    comment     = db.Column(db.Text,        default='')
    total       = db.Column(db.Integer,     default=0)
    discount    = db.Column(db.Integer,     default=0)
    coupon_code = db.Column(db.String(30),  default='')
    status      = db.Column(db.String(30),  default='Новый')
    # Онлайн-оплата
    payment_status = db.Column(db.String(20), default='pending')  # pending/paid/failed
    paid_at        = db.Column(db.DateTime,   nullable=True)
    created_at  = db.Column(db.DateTime,    default=datetime.utcnow)

    items = db.relationship('OrderItem', backref='order', lazy='dynamic', cascade='all,delete-orphan')

    STATUS_COLORS = {'Новый':'blue','В обработке':'yellow','Отправлен':'yellow',
                     'Доставлен':'green','Отменён':'red'}

    # Порядок статусов — только вперёд
    STATUS_ORDER = ['Новый', 'В обработке', 'Отправлен', 'Доставлен', 'Отменён']

    @property
    def status_color(self):
        return self.STATUS_COLORS.get(self.status, 'blue')

    @property
    def is_paid(self):
        return self.payment_status == 'paid'

    @property
    def is_online_payment(self):
        return self.payment in ('Карта онлайн', 'Рассрочка 0%')

    @property
    def available_next_statuses(self):
        """Статусы доступные для установки в админке (только вперёд).
        «Доставлен» убран — его ставит только пользователь через код."""
        try:
            idx = self.STATUS_ORDER.index(self.status)
        except ValueError:
            return [s for s in self.STATUS_ORDER if s != 'Доставлен']
        result = self.STATUS_ORDER[idx:]
        # Убираем "Доставлен" из списка — только пользователь может его поставить
        result = [s for s in result if s != 'Доставлен']
        if 'Отменён' not in result:
            result = result + ['Отменён']
        return result

    def to_dict(self):
        return dict(
            id=self.id, userName=self.user_name, phone=self.phone,
            address=self.address, payment=self.payment, delivery=self.delivery,
            comment=self.comment, total=self.total, status=self.status,
            couponCode=self.coupon_code, discount=self.discount,
            date=self.created_at.strftime('%d.%m.%Y'),
            items=[i.to_dict() for i in self.items]
        )


class OrderItem(db.Model):
    __tablename__ = 'order_items'
    id         = db.Column(db.Integer, primary_key=True)
    order_id   = db.Column(db.Integer, db.ForeignKey('orders.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=True)
    name       = db.Column(db.String(200))
    price      = db.Column(db.Integer)
    qty        = db.Column(db.Integer, default=1)
    emoji      = db.Column(db.String(10), default='📦')

    def to_dict(self):
        return dict(id=self.product_id, name=self.name,
                    price=self.price, qty=self.qty, emoji=self.emoji)


# ─── REVIEW ─────────────────────────────────────────────────────────────────

class Review(db.Model):
    __tablename__ = 'reviews'
    id         = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'))
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    author     = db.Column(db.String(80),  default='Аноним')
    rating     = db.Column(db.Integer,     default=5)
    text       = db.Column(db.Text,        nullable=False)
    approved   = db.Column(db.Boolean,     default=True)
    created_at = db.Column(db.DateTime,    default=datetime.utcnow)

    def to_dict(self):
        return dict(id=self.id, productId=self.product_id,
                    productName=self.product.name if self.product else '',
                    author=self.author, rating=self.rating, text=self.text,
                    date=self.created_at.strftime('%d.%m.%Y'))


# ─── ARTICLE ────────────────────────────────────────────────────────────────

class Article(db.Model):
    __tablename__ = 'articles'
    id          = db.Column(db.Integer, primary_key=True)
    title       = db.Column(db.String(300), nullable=False)
    category    = db.Column(db.String(80),  default='')
    emoji       = db.Column(db.String(10),  default='📄')
    description = db.Column(db.Text,        default='')
    body        = db.Column(db.Text,        default='')
    published   = db.Column(db.Boolean,     default=True)
    created_at  = db.Column(db.DateTime,    default=datetime.utcnow)

    def to_dict(self):
        return dict(id=self.id, title=self.title, cat=self.category,
                    emoji=self.emoji, desc=self.description, body=self.body,
                    date=self.created_at.strftime('%d %B %Y'))


# ─── COUPON ─────────────────────────────────────────────────────────────────

class Coupon(db.Model):
    __tablename__ = 'coupons'
    id       = db.Column(db.Integer, primary_key=True)
    code     = db.Column(db.String(30), unique=True, nullable=False)
    discount = db.Column(db.Integer, default=10)   # %
    uses     = db.Column(db.Integer, default=0)
    active   = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return dict(code=self.code, discount=self.discount,
                    uses=self.uses, active=self.active)


# ─── WISHLIST ───────────────────────────────────────────────────────────────

class Wishlist(db.Model):
    __tablename__ = 'wishlists'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'))
    added_at   = db.Column(db.DateTime, default=datetime.utcnow)


# ─── MESSAGE ────────────────────────────────────────────────────────────────

class Message(db.Model):
    __tablename__ = 'messages'
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(120))
    email      = db.Column(db.String(120))
    phone      = db.Column(db.String(30), default='')
    subject    = db.Column(db.String(120), default='')
    text       = db.Column(db.Text)
    read       = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return dict(id=self.id, name=self.name, contact=self.email,
                    phone=self.phone, subject=self.subject, msg=self.text,
                    read=self.read, date=self.created_at.strftime('%d.%m.%Y'))


# ─── PASSWORD RESET TOKEN ────────────────────────────────────────────────────

class PasswordResetToken(db.Model):
    __tablename__ = 'password_reset_tokens'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    token      = db.Column(db.String(100), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    used       = db.Column(db.Boolean, default=False)

    user = db.relationship('User', backref='reset_tokens')

    @property
    def is_expired(self):
        from datetime import timedelta
        return datetime.utcnow() > self.created_at + timedelta(minutes=30)


# ─── DELIVERY CONFIRM CODE ───────────────────────────────────────────────────

class DeliveryConfirmCode(db.Model):
    __tablename__ = 'delivery_confirm_codes'
    id         = db.Column(db.Integer, primary_key=True)
    order_id   = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'),  nullable=False)
    code       = db.Column(db.String(6), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    used       = db.Column(db.Boolean,  default=False)
    attempts   = db.Column(db.Integer,  default=0)

    @property
    def is_expired(self):
        from datetime import timedelta
        return datetime.utcnow() > self.created_at + timedelta(minutes=15)

    @property
    def is_blocked(self):
        return self.attempts >= 5


# ─── REFUND REQUEST ──────────────────────────────────────────────────────────

class RefundRequest(db.Model):
    __tablename__ = 'refund_requests'
    id         = db.Column(db.Integer, primary_key=True)
    order_id   = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'),  nullable=False)
    reason     = db.Column(db.Text,    default='')
    status     = db.Column(db.String(20), default='pending')  # pending/approved/rejected
    admin_note = db.Column(db.Text,    default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at= db.Column(db.DateTime, nullable=True)

    order = db.relationship('Order', backref='refund_requests')
    user  = db.relationship('User',  backref='refund_requests')

    STATUS_LABELS = {'pending': 'На рассмотрении', 'approved': 'Одобрен', 'rejected': 'Отклонён'}
    STATUS_COLORS = {'pending': 'yellow', 'approved': 'green', 'rejected': 'red'}

    @property
    def status_label(self):
        return self.STATUS_LABELS.get(self.status, self.status)

    @property
    def status_color(self):
        return self.STATUS_COLORS.get(self.status, 'blue')


# ─── LOGIN ATTEMPTS (rate limiting) ──────────────────────────────────────────

class LoginAttempt(db.Model):
    __tablename__ = 'login_attempts'
    id         = db.Column(db.Integer, primary_key=True)
    ip         = db.Column(db.String(45), nullable=False)
    email      = db.Column(db.String(120), default='')
    success    = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ─── PRODUCT IMAGES ──────────────────────────────────────────────────────────

class ProductImage(db.Model):
    __tablename__ = 'product_images'
    id         = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    filename   = db.Column(db.String(200), nullable=False)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    product = db.relationship('Product', backref=db.backref('images', lazy='dynamic',
                              order_by='ProductImage.sort_order', cascade='all,delete-orphan'))


# ─── FINANCE TRANSACTION ─────────────────────────────────────────────────────

class FinanceTransaction(db.Model):
    __tablename__ = 'finance_transactions'
    id          = db.Column(db.Integer, primary_key=True)
    type        = db.Column(db.String(20), nullable=False)  # income / refund / expense
    amount      = db.Column(db.Integer,  nullable=False)
    description = db.Column(db.String(255), default='')
    order_id    = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'),  nullable=True)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    order = db.relationship('Order', backref='transactions')
    user  = db.relationship('User',  backref='transactions')

    TYPE_LABELS = {'income': 'Приход', 'refund': 'Возврат', 'expense': 'Расход'}
    TYPE_COLORS = {'income': 'green',  'refund': 'red',     'expense': 'yellow'}

    @property
    def type_label(self): return self.TYPE_LABELS.get(self.type, self.type)
    @property
    def type_color(self): return self.TYPE_COLORS.get(self.type, 'blue')


# ─── REPORT ──────────────────────────────────────────────────────────────────

class Report(db.Model):
    __tablename__ = 'reports'
    id          = db.Column(db.Integer, primary_key=True)
    title       = db.Column(db.String(200), nullable=False)
    type        = db.Column(db.String(50),  nullable=False)  # sales / finance / orders / products
    period_from = db.Column(db.DateTime, nullable=True)
    period_to   = db.Column(db.DateTime, nullable=True)
    created_by  = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    params      = db.Column(db.Text, default='{}')  # JSON параметры

    author = db.relationship('User', backref='reports')
