"""
LOFT DC — PDF Generator
Генерация документов в PDF через reportlab (встроенный Python, без внешних зависимостей).
"""

import io
from datetime import datetime, timedelta
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                  Spacer, HRFlowable)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER

# ─── Цвета ───────────────────────────────────────────────────────────────────

import os as _os

def _register_fonts():
    candidates = [
        ('C:/Windows/Fonts/arial.ttf',   'C:/Windows/Fonts/arialbd.ttf'),
        ('C:/Windows/Fonts/Arial.ttf',   'C:/Windows/Fonts/Arialbd.ttf'),
        ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
         '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
    ]
    for reg, bld in candidates:
        if _os.path.exists(reg):
            try:
                pdfmetrics.registerFont(TTFont('CyrFont', reg))
                pdfmetrics.registerFont(TTFont('CyrFont-Bold', bld if _os.path.exists(bld) else reg))
                return 'CyrFont', 'CyrFont-Bold'
            except Exception:
                continue
    return _FONT, _FONT_BOLD

_FONT, _FONT_BOLD = _register_fonts()

BLACK   = colors.HexColor('#0a0a0a')
WHITE   = colors.HexColor('#f5f5f0')
ACCENT  = colors.HexColor('#8a7a60')
ACCENT_L= colors.HexColor('#d4c5a9')
GRAY    = colors.HexColor('#666660')
LIGHT   = colors.HexColor('#F4F3EF')
RED     = colors.HexColor('#c0392b')
GREEN   = colors.HexColor('#27ae60')

# ─── Реквизиты ───────────────────────────────────────────────────────────────
COMPANY = {
    'name':     'ООО «ЛОФТ ДС»',
    'inn':      '7700000000',
    'kpp':      '770001001',
    'ogrn':     '1027700000000',
    'address':  'г. Москва, ул. Лофтовая, д. 1, оф. 101',
    'phone':    '+7 (800) 000-00-00',
    'email':    'info@loftdc.ru',
    'bank':     'АО «АЛЬФА-БАНК»',
    'bik':      '044525593',
    'rs':       '40702810000000000000',
    'ks':       '30101810200000000593',
    'director': 'Иванов Иван Иванович',
}


def _fmt(amount: int) -> str:
    """1234567 → 1 234 567 ₽"""
    return f"{amount:,}".replace(",", "\u2009") + "\u00a0₽"


def _words(n: int) -> str:
    """Сумма прописью — корректно для любых сумм."""
    if n == 0: return 'Ноль'
    ones_m = ['','Один','Два','Три','Четыре','Пять','Шесть','Семь','Восемь','Девять']
    ones_f = ['','Одна','Две','Три','Четыре','Пять','Шесть','Семь','Восемь','Девять']
    teen   = ['Десять','Одиннадцать','Двенадцать','Тринадцать','Четырнадцать',
              'Пятнадцать','Шестнадцать','Семнадцать','Восемнадцать','Девятнадцать']
    tens_  = ['','','Двадцать','Тридцать','Сорок','Пятьдесят',
              'Шестьдесят','Семьдесят','Восемьдесят','Девяносто']
    hunds  = ['','Сто','Двести','Триста','Четыреста','Пятьсот',
              'Шестьсот','Семьсот','Восемьсот','Девятьсот']
    def chunk(x, fem=False):
        r = []
        if x >= 100: r.append(hunds[x // 100]); x %= 100
        if 10 <= x <= 19: r.append(teen[x - 10]); return ' '.join(filter(None, r))
        if x >= 20: r.append(tens_[x // 10]); x %= 10
        if x > 0: r.append(ones_f[x] if fem else ones_m[x])
        return ' '.join(filter(None, r))
    def suf_t(t):
        r = t % 100; r = t % 10 if not (11 <= r <= 19) else 20
        return 'тысяч' if r in (0,5,6,7,8,9,20) else ('тысяча' if r == 1 else 'тысячи')
    def suf_m(m):
        r = m % 100; r = m % 10 if not (11 <= r <= 19) else 20
        return 'миллионов' if r in (0,5,6,7,8,9,20) else ('миллион' if r == 1 else 'миллиона')
    parts = []
    if n >= 1000000: m = n // 1000000; parts.append(f'{chunk(m)} {suf_m(m)}'); n %= 1000000
    if n >= 1000: t = n // 1000; parts.append(f'{chunk(t, True)} {suf_t(t)}'); n %= 1000
    if n > 0: parts.append(chunk(n))
    return ' '.join(filter(None, parts)).capitalize()



def _base_styles():
    """Базовые стили параграфов."""
    styles = getSampleStyleSheet()
    normal = ParagraphStyle('loft_normal', fontName=_FONT, fontSize=9,
                            leading=13, textColor=BLACK)
    bold   = ParagraphStyle('loft_bold',   fontName=_FONT_BOLD, fontSize=9,
                            leading=13, textColor=BLACK)
    small  = ParagraphStyle('loft_small',  fontName=_FONT, fontSize=8,
                            leading=11, textColor=GRAY)
    title  = ParagraphStyle('loft_title',  fontName=_FONT_BOLD, fontSize=16,
                            leading=20, textColor=BLACK, spaceAfter=2)
    label  = ParagraphStyle('loft_label',  fontName=_FONT_BOLD, fontSize=7,
                            leading=10, textColor=GRAY, spaceBefore=8)
    right  = ParagraphStyle('loft_right',  fontName=_FONT, fontSize=9,
                            leading=13, textColor=BLACK, alignment=TA_RIGHT)
    center = ParagraphStyle('loft_center', fontName=_FONT_BOLD, fontSize=32,
                            leading=36, textColor=BLACK, alignment=TA_CENTER)
    return {'n': normal, 'b': bold, 's': small, 't': title, 'l': label, 'r': right, 'c': center}


def _doc(buffer, title: str):
    return SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=20*mm, rightMargin=20*mm,
        topMargin=20*mm, bottomMargin=20*mm,
        title=title, author='LOFT DC'
    )


def _header_table(doc_type: str, doc_num: str, doc_date: str, s: dict):
    """Шапка документа с логотипом и реквизитами."""
    logo = Paragraph('<b>LOFT</b>DC', ParagraphStyle('logo', fontName=_FONT_BOLD,
                     fontSize=22, leading=24, textColor=BLACK))
    logo_sub = Paragraph('МЕБЕЛЬ И ДЕКОР', ParagraphStyle('logo_sub', fontName=_FONT,
                          fontSize=7, leading=9, textColor=GRAY, spaceBefore=2))
    left = [logo, logo_sub]

    right_text = (f'<b>{COMPANY["name"]}</b><br/>'
                  f'ИНН {COMPANY["inn"]} / КПП {COMPANY["kpp"]}<br/>'
                  f'{COMPANY["address"]}<br/>{COMPANY["phone"]}')
    right = Paragraph(right_text, ParagraphStyle('hdr_r', fontName=_FONT, fontSize=8,
                       leading=12, textColor=GRAY, alignment=TA_RIGHT))

    t = Table([[left, right]], colWidths=[90*mm, 90*mm])
    t.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LINEBELOW', (0,0), (-1,-1), 1.5, BLACK),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
    ]))
    return t


def _doc_title_bar(doc_type: str, doc_num: str, doc_date: str):
    """Тёмная полоса с названием документа."""
    data = [[
        Paragraph(f'<b>{doc_type}</b>',
                  ParagraphStyle('dt', fontName=_FONT_BOLD, fontSize=11,
                                 textColor=WHITE, leading=14)),
        Paragraph(f'№ {doc_num}',
                  ParagraphStyle('dn', fontName=_FONT, fontSize=10,
                                 textColor=ACCENT_L, leading=14)),
        Paragraph(f'от {doc_date}',
                  ParagraphStyle('dd', fontName=_FONT, fontSize=9,
                                 textColor=GRAY, leading=14, alignment=TA_RIGHT)),
    ]]
    t = Table([data[0]], colWidths=[90*mm, 50*mm, 40*mm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), BLACK),
        ('TOPPADDING',    (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING',   (0,0), (0,-1), 10),
        ('RIGHTPADDING',  (-1,0), (-1,-1), 10),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    return t


def _parties_table(seller: dict, buyer_name: str, buyer_phone: str, buyer_address: str, s: dict):
    """Таблица Продавец | Покупатель."""
    seller_text = (f'<b>{seller["name"]}</b><br/>'
                   f'ИНН: {seller["inn"]}<br/>'
                   f'КПП: {seller["kpp"]}<br/>'
                   f'{seller["address"]}<br/>'
                   f'Тел: {seller["phone"]}')
    buyer_text = (f'<b>{buyer_name}</b><br/>'
                  f'Тел: {buyer_phone}<br/>'
                  f'Адрес: {buyer_address}')
    data = [[
        [Paragraph('ПРОДАВЕЦ', s['l']), Paragraph(seller_text, s['n'])],
        [Paragraph('ПОКУПАТЕЛЬ', s['l']), Paragraph(buyer_text, s['n'])],
    ]]
    t = Table(data, colWidths=[90*mm, 90*mm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), LIGHT),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#E0DED8')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E0DED8')),
        ('TOPPADDING',    (0,0), (-1,-1), 10),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
        ('LEFTPADDING',   (0,0), (-1,-1), 10),
        ('RIGHTPADDING',  (0,0), (-1,-1), 10),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    return t


def _items_table(order, s: dict):
    """Таблица с товарами заказа."""
    header = ['№', 'Наименование', 'Кол-во', 'Цена', 'Сумма']
    rows = [header]
    for i, item in enumerate(order.items, 1):
        rows.append([
            str(i),
            item.name,
            f'{item.qty} шт.',
            _fmt(item.price),
            _fmt(item.price * item.qty),
        ])
    rows.append(['', 'ИТОГО:', '', '', _fmt(order.total)])

    col_w = [10*mm, 80*mm, 20*mm, 30*mm, 40*mm]
    t = Table(rows, colWidths=col_w, repeatRows=1)
    n = len(rows)
    t.setStyle(TableStyle([
        # Шапка
        ('BACKGROUND',  (0,0), (-1,0), BLACK),
        ('TEXTCOLOR',   (0,0), (-1,0), WHITE),
        ('FONTNAME',    (0,0), (-1,0), _FONT_BOLD),
        ('FONTSIZE',    (0,0), (-1,0), 8),
        ('TOPPADDING',  (0,0), (-1,0), 7),
        ('BOTTOMPADDING',(0,0),(-1,0), 7),
        # Строки
        ('FONTNAME',    (0,1), (-1,-2), _FONT),
        ('FONTSIZE',    (0,1), (-1,-2), 9),
        ('ROWBACKGROUNDS', (0,1), (-1,-2), [WHITE, LIGHT]),
        ('GRID',        (0,0), (-1,-2), 0.5, colors.HexColor('#E0DED8')),
        ('TOPPADDING',  (0,1), (-1,-2), 6),
        ('BOTTOMPADDING',(0,1),(-1,-2), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING',(0,0), (-1,-1), 8),
        # Итого
        ('BACKGROUND',  (0,-1), (-1,-1), LIGHT),
        ('FONTNAME',    (0,-1), (-1,-1), _FONT_BOLD),
        ('FONTSIZE',    (0,-1), (-1,-1), 10),
        ('LINEABOVE',   (0,-1), (-1,-1), 1.5, BLACK),
        ('TOPPADDING',  (0,-1), (-1,-1), 8),
        ('BOTTOMPADDING',(0,-1),(-1,-1), 8),
        # Выравнивание чисел
        ('ALIGN', (2,0), (-1,-1), 'RIGHT'),
        ('ALIGN', (0,0), (0,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    return t


def _sign_table(left_role: str, left_name: str, right_role: str, right_name: str, s: dict):
    """Строка с подписями."""
    def _sign_cell(role, name):
        return [
            Paragraph(role, s['l']),
            HRFlowable(width='100%', thickness=0.5, color=GRAY, spaceAfter=4),
            Paragraph(name, s['n']),
        ]
    t = Table([[_sign_cell(left_role, left_name), _sign_cell(right_role, right_name)]],
              colWidths=[90*mm, 90*mm])
    t.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING',  (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING',   (0,0), (-1,-1), 0),
    ]))
    return t


def _footer_para(doc_num: str, order_id: int, s: dict):
    return Paragraph(
        f'Документ сформирован автоматически · {datetime.now().strftime("%d.%m.%Y %H:%M")} · '
        f'{doc_num} · Заказ #{order_id} · loftdc.ru',
        ParagraphStyle('footer', fontName=_FONT, fontSize=7, textColor=GRAY,
                       leading=10, alignment=TA_CENTER, spaceBefore=4)
    )


# ─── 1. СЧЁТ НА ОПЛАТУ ──────────────────────────────────────────────────────

def generate_invoice_pdf(order) -> bytes:
    buf = io.BytesIO()
    s   = _base_styles()
    doc_num  = f'{order.id:05d}'
    doc_date = order.created_at.strftime('%d.%m.%Y')
    due_date = (order.created_at + timedelta(days=5)).strftime('%d.%m.%Y')

    story = [
        _header_table('', doc_num, doc_date, s),
        Spacer(1, 4*mm),
        _doc_title_bar('СЧЁТ НА ОПЛАТУ', doc_num, doc_date),
        Spacer(1, 4*mm),
        _parties_table(COMPANY, order.user_name, order.phone, order.address, s),
        Spacer(1, 3*mm),
    ]

    # Банковские реквизиты
    bank_data = [
        [Paragraph('Банк:', s['s']), Paragraph(COMPANY['bank'], s['n']),
         Paragraph('БИК:', s['s']), Paragraph(COMPANY['bik'], s['n'])],
        [Paragraph('р/с:', s['s']), Paragraph(COMPANY['rs'], s['n']),
         Paragraph('к/с:', s['s']), Paragraph(COMPANY['ks'], s['n'])],
    ]
    bank_t = Table(bank_data, colWidths=[15*mm, 75*mm, 15*mm, 75*mm])
    bank_t.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#E0DED8')),
        ('BACKGROUND', (0,0), (-1,-1), LIGHT),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(bank_t)
    story.append(Spacer(1, 3*mm))
    story.append(_items_table(order, s))
    story.append(Spacer(1, 3*mm))

    words_text = f'{_words(order.total)} рублей 00 копеек. НДС не облагается (УСН).'
    notice = Table([[Paragraph(f'<b>Сумма прописью:</b> {words_text}', s['n'])]],
                   colWidths=[180*mm])
    notice.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), LIGHT),
        ('LEFTBORDERPADDING', (0,0), (0,-1), 3),
        ('LINEBEFORE', (0,0), (0,-1), 3, ACCENT),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(notice)
    story.append(Spacer(1, 3*mm))
    story.append(Paragraph(f'Оплатить до: <b>{due_date}</b> · Оплата: <b>{order.payment}</b>', s['s']))
    story.append(Spacer(1, 8*mm))
    story.append(_sign_table('Руководитель', COMPANY['director'], 'Бухгалтер', '________________', s))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width='100%', thickness=0.5, color=LIGHT))
    story.append(_footer_para(f'Счёт №{doc_num}', order.id, s))

    _doc(buf, f'Счёт №{doc_num}').build(story)
    return buf.getvalue()


# ─── 2. ТОВАРНАЯ НАКЛАДНАЯ ───────────────────────────────────────────────────

def generate_waybill_pdf(order) -> bytes:
    buf = io.BytesIO()
    s   = _base_styles()
    doc_num  = f'Н-{order.id:05d}'
    doc_date = order.created_at.strftime('%d.%m.%Y')

    story = [
        _header_table('', doc_num, doc_date, s),
        Spacer(1, 4*mm),
        _doc_title_bar('ТОВАРНАЯ НАКЛАДНАЯ (ТОРГ-12 упрощённая)', doc_num, doc_date),
        Spacer(1, 4*mm),
        _parties_table(COMPANY, order.user_name, order.phone, order.address, s),
        Spacer(1, 3*mm),
    ]

    # Основание
    basis_data = [[
        Paragraph(f'Основание: <b>Заказ №{order.id} от {doc_date}</b>', s['n']),
        Paragraph(f'Доставка: <b>{order.delivery or "Самовывоз"}</b>', s['n']),
        Paragraph(f'Оплата: <b>{order.payment}</b>', s['n']),
    ]]
    basis_t = Table(basis_data, colWidths=[70*mm, 60*mm, 50*mm])
    basis_t.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#E0DED8')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E0DED8')),
        ('BACKGROUND', (0,0), (-1,-1), LIGHT),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(basis_t)
    story.append(Spacer(1, 3*mm))
    story.append(_items_table(order, s))
    story.append(Spacer(1, 3*mm))

    total_qty = sum(item.qty for item in order.items)
    story.append(Paragraph(
        f'Всего наименований: <b>{order.items.count()}</b>, '
        f'количество: <b>{total_qty} шт.</b>, '
        f'на сумму: <b>{_fmt(order.total)}</b><br/>'
        f'Сумма прописью: <b>{_words(order.total)} рублей 00 копеек.</b> НДС не облагается.',
        s['n']
    ))
    story.append(Spacer(1, 8*mm))
    story.append(_sign_table('Отпустил (продавец)', COMPANY['director'],
                              f'Груз принял (покупатель)', order.user_name, s))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width='100%', thickness=0.5, color=LIGHT))
    story.append(_footer_para(doc_num, order.id, s))

    _doc(buf, f'Накладная {doc_num}').build(story)
    return buf.getvalue()


# ─── 3. ДОВЕРЕННОСТЬ КУРЬЕРА ─────────────────────────────────────────────────

def generate_courier_proxy_pdf(order, courier_name: str = '', courier_passport: str = '') -> bytes:
    buf = io.BytesIO()
    s   = _base_styles()
    doc_num    = f'Д-{order.id:05d}'
    doc_date   = order.created_at.strftime('%d.%m.%Y')
    valid_until = (order.created_at + timedelta(days=30)).strftime('%d.%m.%Y')
    cn = courier_name    or '___________________________________'
    cp = courier_passport or '_________________________'

    story = [
        _header_table('', doc_num, doc_date, s),
        Spacer(1, 6*mm),
        Paragraph('ДОВЕРЕННОСТЬ', ParagraphStyle('prx_t', fontName=_FONT_BOLD,
                   fontSize=18, leading=22, textColor=BLACK, alignment=TA_CENTER)),
        Paragraph(f'№ {doc_num} от {doc_date} г. &nbsp;·&nbsp; г. Москва',
                  ParagraphStyle('prx_s', fontName=_FONT, fontSize=9,
                                 textColor=GRAY, alignment=TA_CENTER, spaceBefore=4)),
        Spacer(1, 6*mm),
        Paragraph(
            f'<b>{COMPANY["name"]}</b> (ИНН: {COMPANY["inn"]}, ОГРН: {COMPANY["ogrn"]}, '
            f'адрес: {COMPANY["address"]}), в лице Генерального директора '
            f'<b>{COMPANY["director"]}</b>, действующего на основании Устава, '
            f'настоящей доверенностью уполномочивает:', s['n']
        ),
        Spacer(1, 4*mm),
    ]

    # Данные курьера
    courier_data = [
        [Paragraph('ФИО:', s['l']), Paragraph(f'<b>{cn}</b>', s['b'])],
        [Paragraph('Паспорт:', s['l']), Paragraph(cp, s['n'])],
    ]
    courier_t = Table(courier_data, colWidths=[30*mm, 150*mm])
    courier_t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), LIGHT),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#E0DED8')),
        ('TOPPADDING', (0,0), (-1,-1), 7),
        ('BOTTOMPADDING', (0,0), (-1,-1), 7),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(courier_t)
    story.append(Spacer(1, 4*mm))
    story.append(Paragraph(
        f'осуществить доставку и передачу товаров покупателю по заказу '
        f'<b>№{order.id} от {doc_date} г.</b>', s['n']
    ))
    story.append(Spacer(1, 3*mm))

    # Покупатель
    buyer_data = [[
        Paragraph('ПОКУПАТЕЛЬ', s['l']),
        Paragraph(f'<b>{order.user_name}</b> · Тел: {order.phone} · Адрес: {order.address}', s['n']),
    ]]
    buyer_t = Table(buyer_data, colWidths=[35*mm, 145*mm])
    buyer_t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), LIGHT),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#E0DED8')),
        ('TOPPADDING', (0,0), (-1,-1), 7),
        ('BOTTOMPADDING', (0,0), (-1,-1), 7),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(buyer_t)
    story.append(Spacer(1, 3*mm))
    story.append(_items_table(order, s))
    story.append(Spacer(1, 3*mm))
    story.append(Paragraph(
        f'Доверенность выдана <b>без права передоверия</b>. '
        f'Срок действия: по <b>{valid_until}</b> включительно.', s['n']
    ))
    story.append(Spacer(1, 8*mm))
    story.append(_sign_table('Доверитель — Генеральный директор', COMPANY['director'],
                              'Доверенное лицо (курьер)', cn, s))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width='100%', thickness=0.5, color=LIGHT))
    story.append(_footer_para(doc_num, order.id, s))

    _doc(buf, f'Доверенность {doc_num}').build(story)
    return buf.getvalue()


# ─── 4. АКТ ВОЗВРАТА ─────────────────────────────────────────────────────────

def generate_refund_act_pdf(refund) -> bytes:
    buf   = io.BytesIO()
    s     = _base_styles()
    order = refund.order
    doc_num  = f'В-{refund.id:05d}'
    doc_date = refund.created_at.strftime('%d.%m.%Y')
    resolved = refund.resolved_at.strftime('%d.%m.%Y') if refund.resolved_at else '—'
    status_label = {'pending': 'На рассмотрении', 'approved': 'Одобрен', 'rejected': 'Отклонён'}.get(refund.status, refund.status)

    story = [
        _header_table('', doc_num, doc_date, s),
        Spacer(1, 4*mm),
        _doc_title_bar('АКТ ВОЗВРАТА ТОВАРА', doc_num, doc_date),
        Spacer(1, 4*mm),
        _parties_table(COMPANY, refund.user.name, order.phone, order.address, s),
        Spacer(1, 3*mm),
        Paragraph(f'Статус: <b>{status_label}</b> · Дата решения: <b>{resolved}</b> · Заказ №<b>{order.id}</b>', s['s']),
        Spacer(1, 3*mm),
    ]

    # Причина
    reason_t = Table([[Paragraph(f'<b>Причина возврата:</b> {refund.reason}', s['n'])]],
                     colWidths=[180*mm])
    reason_t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), LIGHT),
        ('LINEBEFORE', (0,0), (0,-1), 3, ACCENT),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(reason_t)

    if refund.admin_note:
        story.append(Spacer(1, 2*mm))
        note_t = Table([[Paragraph(f'<b>Примечание:</b> {refund.admin_note}', s['n'])]],
                       colWidths=[180*mm])
        note_t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), LIGHT),
            ('LINEBEFORE', (0,0), (0,-1), 3, RED),
            ('TOPPADDING', (0,0), (-1,-1), 8),
            ('BOTTOMPADDING', (0,0), (-1,-1), 8),
            ('LEFTPADDING', (0,0), (-1,-1), 10),
        ]))
        story.append(note_t)

    story.append(Spacer(1, 3*mm))
    story.append(_items_table(order, s))
    story.append(Spacer(1, 3*mm))
    story.append(Paragraph(
        f'Итого к возврату: <b>{_fmt(order.total)}</b> '
        f'({_words(order.total)} рублей 00 копеек)', s['n']
    ))
    story.append(Spacer(1, 8*mm))
    story.append(_sign_table('Представитель продавца', COMPANY['director'],
                              'Покупатель', refund.user.name, s))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width='100%', thickness=0.5, color=LIGHT))
    story.append(_footer_para(doc_num, order.id, s))

    _doc(buf, f'Акт возврата {doc_num}').build(story)
    return buf.getvalue()
