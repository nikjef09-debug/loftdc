/* LOFT DC — Main JS */

// Header scroll shadow
window.addEventListener('scroll', () => {
  document.getElementById('siteHeader')?.classList.toggle('scrolled', window.scrollY > 50);
});

// Mobile nav toggle
function toggleNav() {
  const nav = document.getElementById('mainNav');
  const btn = document.getElementById('burgerBtn');
  if (!nav) return;
  const isOpen = nav.classList.toggle('open');
  btn?.classList.toggle('open', isOpen);
  btn?.setAttribute('aria-expanded', isOpen);
  // Блокируем скролл страницы когда меню открыто
  document.body.style.overflow = isOpen ? 'hidden' : '';
}
// Закрыть меню при клике вне
document.addEventListener('click', e => {
  const nav = document.getElementById('mainNav');
  const btn = document.getElementById('burgerBtn');
  if (nav?.classList.contains('open') && !nav.contains(e.target) && !btn?.contains(e.target)) {
    nav.classList.remove('open');
    btn?.classList.remove('open');
    btn?.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }
});
// Закрыть меню при клике на ссылку внутри
document.getElementById('mainNav')?.querySelectorAll('a').forEach(a => {
  a.addEventListener('click', () => {
    document.getElementById('mainNav')?.classList.remove('open');
    document.getElementById('burgerBtn')?.classList.remove('open');
    document.body.style.overflow = '';
  });
});

// FAQ accordion
document.querySelectorAll('.faq-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.closest('.faq-item');
    const wasOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
    if (!wasOpen) item.classList.add('open');
  });
});

// Product detail tabs
function switchTab(tabId, btn) {
  document.querySelectorAll('.pd-tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.pd-tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(tabId)?.classList.add('active');
  btn?.classList.add('active');
}

// Profile tabs
function switchProfileTab(tabId) {
  document.querySelectorAll('.profile-tab-panel').forEach(p => p.style.display = 'none');
  document.querySelectorAll('.profile-tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('pt-' + tabId).style.display = 'block';
  event.currentTarget.classList.add('active');
}

// Qty controls on product page
function changeQty(delta) {
  const el = document.getElementById('qty-input');
  if (!el) return;
  const val = Math.max(1, parseInt(el.value) + delta);
  el.value = val;
  document.getElementById('qty-display').textContent = val;
}

// Cart qty forms - submit on change
document.querySelectorAll('.cart-qty-form select, .cart-qty-form input').forEach(el => {
  el.addEventListener('change', () => el.closest('form').submit());
});

// Flash auto-dismiss
setTimeout(() => {
  document.querySelectorAll('.flash').forEach(f => {
    f.style.transition = 'opacity .5s';
    f.style.opacity = '0';
    setTimeout(() => f.remove(), 500);
  });
}, 5000);

// Scroll reveal
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.08 });
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// Leaflet Map (called from page if #map exists)
function initMap(lat, lng, label) {
  if (!document.getElementById('map')) return;
  if (typeof L === 'undefined') return;
  const map = L.map('map').setView([lat, lng], 15);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap', maxZoom: 19
  }).addTo(map);
  const icon = L.divIcon({
    html: '<div style="background:#d4c5a9;width:20px;height:20px;border-radius:50%;border:3px solid #0a0a0a;box-shadow:0 0 12px rgba(212,197,169,.6)"></div>',
    iconSize: [20, 20], iconAnchor: [10, 10]
  });
  L.marker([lat, lng], { icon }).addTo(map)
    .bindPopup(`<b style="font-family:monospace">${label}</b>`).openPopup();
}

// Admin: confirm before delete
document.querySelectorAll('form[data-confirm]').forEach(form => {
  form.addEventListener('submit', e => {
    if (!confirm(form.dataset.confirm)) e.preventDefault();
  });
});

// Admin table search
window.liveSearch = function(inputId, tableBodyId) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener('input', () => {
    const val = input.value.toLowerCase();
    document.querySelectorAll('#' + tableBodyId + ' tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(val) ? '' : 'none';
    });
  });
};


// ═══════════════════════════════════════════════════════════════
// МАСКИ И ВАЛИДАЦИЯ ПОЛЕЙ
// ═══════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', function () {

  // ── Маска телефона +7 (999) 999-99-99 ──────────────────────
  function applyPhoneMask(input) {
    input.addEventListener('input', function (e) {
      let digits = e.target.value.replace(/\D/g, '');
      // Если начинается с 8 — меняем на 7
      if (digits.startsWith('8')) digits = '7' + digits.slice(1);
      // Если начинается не с 7 — добавляем 7
      if (digits.length > 0 && digits[0] !== '7') digits = '7' + digits;
      digits = digits.slice(0, 11);

      let result = '';
      if (digits.length > 0)  result = '+7';
      if (digits.length > 1)  result += ' (' + digits.slice(1, 4);
      if (digits.length >= 4) result += ')';
      if (digits.length > 4)  result += ' ' + digits.slice(4, 7);
      if (digits.length > 7)  result += '-' + digits.slice(7, 9);
      if (digits.length > 9)  result += '-' + digits.slice(9, 11);
      e.target.value = result;
    });

    input.addEventListener('keydown', function (e) {
      // Разрешаем: backspace, delete, tab, escape, стрелки
      if ([8, 9, 27, 46, 37, 38, 39, 40].includes(e.keyCode)) return;
      // Блокируем не-цифры
      if (!/^\d$/.test(e.key) && !e.ctrlKey && !e.metaKey) e.preventDefault();
    });

    input.placeholder = '+7 (999) 999-99-99';
  }

  // ── Только цифры ───────────────────────────────────────────
  function applyNumberOnly(input) {
    input.addEventListener('input', function (e) {
      e.target.value = e.target.value.replace(/[^\d]/g, '');
    });
    input.addEventListener('keydown', function (e) {
      if ([8, 9, 27, 46, 37, 38, 39, 40].includes(e.keyCode)) return;
      if (e.ctrlKey || e.metaKey) return;
      if (!/^\d$/.test(e.key)) e.preventDefault();
    });
  }

  // ── Маска email — базовая ──────────────────────────────────
  function applyEmailValidation(input) {
    input.addEventListener('blur', function (e) {
      const val = e.target.value.trim();
      if (val && !/.+@.+\..+/.test(val)) {
        e.target.style.borderColor = 'var(--red, #c0392b)';
        e.target.title = 'Введите корректный email';
      } else {
        e.target.style.borderColor = '';
        e.target.title = '';
      }
    });
  }

  // ── Применяем ко всем подходящим полям ────────────────────
  document.querySelectorAll('input[type="tel"], input[name="phone"]').forEach(applyPhoneMask);
  document.querySelectorAll('input[type="email"]').forEach(applyEmailValidation);

  // Числовые поля — только цифры (количество, цена и т.п.)
  document.querySelectorAll(
    'input[type="number"], input[name="price"], input[name="qty"], input[name="stock"], input[name="discount"]'
  ).forEach(function(input) {
    applyNumberOnly(input);
    // Убираем спиннер у number-полей
    input.style.MozAppearance = 'textfield';
  });

  // Поля с числовыми данными по data-атрибуту
  document.querySelectorAll('input[data-type="number"]').forEach(applyNumberOnly);

});
