"""
LOFT DC — Email Service
Отправка писем через Mail.ru SMTP.

Настройка в .env или переменных окружения:
  MAIL_USER     = ваш@mail.ru
  MAIL_PASSWORD = пароль приложения (не основной пароль!)
                  Создать: mail.ru → Настройки → Безопасность → Пароли для внешних приложений
  MAIL_FROM     = LOFT DC <ваш@mail.ru>   (опционально)
  SITE_URL      = https://loftdc.ru
"""

import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from datetime import datetime


# ─── Конфигурация ────────────────────────────────────────────────────────────

SMTP_HOST = 'smtp.mail.ru'
SMTP_PORT = 465          # SSL
MAIL_USER = os.environ.get('MAIL_USER', '')
MAIL_PASS = os.environ.get('MAIL_PASSWORD', '')
MAIL_FROM = os.environ.get('MAIL_FROM', f'LOFT DC <{MAIL_USER}>')
SITE_URL  = os.environ.get('SITE_URL', 'http://localhost:5001')

# Цвета писем — светлая тема (совместима со всеми почтовыми клиентами)
C_BG      = '#F4F3EF'   # фон письма
C_CARD    = '#FFFFFF'   # фон карточки
C_HEADER  = '#0a0a0a'   # шапка (тёмная)
C_TEXT    = '#1a1a1a'   # основной текст
C_MUTED   = '#666660'   # второстепенный текст
C_ACCENT  = '#8a7a60'   # акцент (тёмный вариант, виден на белом)
C_ACCENT_L= '#d4c5a9'   # акцент светлый (только для тёмных блоков)
C_RED     = '#c0392b'
C_GREEN   = '#27ae60'
C_BLACK   = '#0a0a0a'
C_BORDER  = '#E0DED8'


# ─── Базовый шаблон письма ───────────────────────────────────────────────────

def _base_template(title: str, preview: str, body_html: str) -> str:
    year = datetime.now().year
    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>{title}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@400;500&display=swap');
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{background:{C_BG};font-family:'Cormorant Garamond',Georgia,serif;
          color:{C_TEXT};-webkit-font-smoothing:antialiased}}
    a{{color:{C_ACCENT};text-decoration:none}}
    .wrapper{{max-width:620px;margin:0 auto;padding:32px 16px}}
    /* Header — тёмный, как сайт */
    .hd{{background:{C_HEADER};padding:28px 48px;text-align:center}}
    .logo{{font-family:'Bebas Neue',sans-serif;font-size:36px;letter-spacing:8px;
           color:#f5f5f0;display:inline-block}}
    .logo span{{color:{C_ACCENT_L}}}
    .logo-sub{{font-family:'JetBrains Mono',monospace;font-size:8px;letter-spacing:3px;
               color:#888;text-transform:uppercase;margin-top:4px}}
    /* Card — белая */
    .card{{background:{C_CARD};border:1px solid {C_BORDER}}}
    .card-body{{padding:40px 48px}}
    /* Title */
    .title{{font-family:'Bebas Neue',sans-serif;font-size:40px;letter-spacing:3px;
            color:{C_BLACK};margin-bottom:6px;line-height:1}}
    .title-accent{{color:{C_ACCENT}}}
    .subtitle{{font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;
               color:{C_MUTED};text-transform:uppercase;margin-bottom:28px}}
    /* Divider */
    .div{{height:1px;background:{C_BORDER};margin:28px 0}}
    /* Info table */
    .info-table{{width:100%;border-collapse:collapse;margin:20px 0}}
    .info-table td{{padding:11px 0;border-bottom:1px solid {C_BORDER};
                    font-size:16px;vertical-align:top;color:{C_TEXT}}}
    .info-table td:first-child{{font-family:'JetBrains Mono',monospace;font-size:10px;
                                letter-spacing:1.5px;color:{C_MUTED};text-transform:uppercase;
                                width:38%;padding-top:14px}}
    /* Order items */
    .items-table{{width:100%;border-collapse:collapse;margin:20px 0}}
    .items-table th{{background:{C_BLACK};font-family:'JetBrains Mono',monospace;
                     font-size:9px;letter-spacing:2px;text-transform:uppercase;
                     color:{C_MUTED};padding:12px 14px;text-align:left}}
    .items-table td{{padding:13px 14px;font-size:16px;color:{C_TEXT};
                     border-bottom:1px solid {C_BORDER}}}
    .items-table .emoji{{font-size:22px;width:40px}}
    .items-table .price{{font-family:'JetBrains Mono',monospace;font-size:13px;
                         color:{C_ACCENT};white-space:nowrap}}
    .items-total{{background:#F9F8F4}}
    .items-total td{{padding:16px 14px;border-top:2px solid {C_BLACK}}}
    .items-total .label{{font-family:'JetBrains Mono',monospace;font-size:10px;
                         letter-spacing:2px;color:{C_MUTED};text-transform:uppercase}}
    .items-total .amount{{font-family:'Bebas Neue',sans-serif;font-size:32px;
                          color:{C_BLACK};letter-spacing:2px}}
    /* Button */
    .btn-wrap{{text-align:center;margin:32px 0}}
    .btn{{display:inline-block;background:{C_BLACK};color:#f5f5f0 !important;
          font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:3px;
          text-transform:uppercase;padding:16px 42px;font-weight:500}}
    /* Status badge */
    .status{{display:inline-block;font-family:'JetBrains Mono',monospace;font-size:10px;
             letter-spacing:2px;text-transform:uppercase;padding:6px 16px;
             border:1px solid {C_ACCENT};color:{C_ACCENT};margin-bottom:24px}}
    /* Notice */
    .notice{{background:#F9F8F4;border-left:3px solid {C_ACCENT};
             padding:16px 20px;font-size:15px;font-style:italic;color:{C_MUTED};margin:20px 0}}
    .notice-red{{border-left-color:{C_RED};background:#FDF5F5;color:#8a2020}}
    /* Footer */
    .ft{{background:#F9F8F4;padding:24px 48px;text-align:center;
         border-top:1px solid {C_BORDER}}}
    .ft p{{font-family:'JetBrains Mono',monospace;font-size:10px;color:{C_MUTED};
           letter-spacing:.8px;line-height:1.9}}
    .ft a{{color:{C_MUTED}}}
    @media(max-width:480px){{
      .card-body,.hd,.ft{{padding:24px 20px}}
      .title{{font-size:30px}}
    }}
  </style>
</head>
<body>
<div style="display:none;max-height:0;overflow:hidden;opacity:0">{preview}</div>
<div class="wrapper">
  <div class="hd">
    <div class="logo">LOFT<span>DC</span></div>
    <div class="logo-sub">мебель и декор</div>
  </div>
  <div class="card">
    <div class="card-body">
      {body_html}
    </div>
    <div class="ft">
      <p>
        <a href="{SITE_URL}">loftdc.ru</a> &nbsp;·&nbsp;
        <a href="{SITE_URL}/contacts">Контакты</a> &nbsp;·&nbsp;
        <a href="{SITE_URL}/catalog/">Каталог</a>
      </p>
      <p style="margin-top:8px">© {year} LOFT DC. Все права защищены.</p>
      <p style="margin-top:4px;font-size:9px;color:#aaa">
        Вы получили это письмо, так как совершили действие на сайте loftdc.ru
      </p>
    </div>
  </div>
</div>
</body>
</html>"""


# ─── Шаблон: Подтверждение заказа ───────────────────────────────────────────

def _order_confirmation_html(order) -> str:
    """order — объект модели Order с .items"""
    rows = ''
    for item in order.items:
        subtotal = item.price * item.qty
        rows += f"""
        <tr>
          <td class="emoji">{item.emoji}</td>
          <td>{item.name}</td>
          <td class="price">{item.qty} шт.</td>
          <td class="price" style="text-align:right">{subtotal:,} ₽</td>
        </tr>""".replace(',', ' ')

    discount_row = ''
    if order.discount:
        discount_row = f"""
        <tr style="border-bottom:none">
          <td colspan="3" class="label">Скидка ({order.coupon_code}) {order.discount}%</td>
          <td class="price" style="text-align:right;color:{C_RED}">−{int(order.total / (1 - order.discount/100) * order.discount/100):,} ₽</td>
        </tr>""".replace(',', ' ')

    body = f"""
    <div class="status">✓ Заказ оформлен</div>
    <div class="title">ЗАКАЗ <span class="title-accent">#{order.id}</span></div>
    <div class="subtitle">подтверждение</div>

    <p style="font-size:18px;color:{C_MUTED};margin-bottom:24px;font-style:italic">
      Здравствуйте, <strong style="color:{C_TEXT}">{order.user_name.split()[0]}</strong>!
      Ваш заказ успешно принят. Наш менеджер свяжется с вами в ближайшее время
      для подтверждения деталей.
    </p>

    <div class="div"></div>

    <table class="info-table">
      <tr><td>Получатель</td><td>{order.user_name}</td></tr>
      <tr><td>Телефон</td><td>{order.phone}</td></tr>
      <tr><td>Адрес</td><td>{order.address}</td></tr>
      <tr><td>Доставка</td><td>{order.delivery or '—'}</td></tr>
      <tr><td>Оплата</td><td>{order.payment or '—'}</td></tr>
      <tr><td>Дата</td><td>{order.created_at.strftime('%d.%m.%Y %H:%M')}</td></tr>
    </table>

    <div class="div"></div>

    <table class="items-table">
      <thead>
        <tr>
          <th style="width:40px"></th>
          <th>Товар</th>
          <th>Кол-во</th>
          <th style="text-align:right">Сумма</th>
        </tr>
      </thead>
      <tbody>
        {rows}
        {discount_row}
      </tbody>
      <tfoot>
        <tr class="items-total">
          <td colspan="3" class="label">Итого к оплате</td>
          <td class="amount" style="text-align:right">{order.total:,} ₽</td>
        </tr>
      </tfoot>
    </table>

    <div class="btn-wrap">
      <a href="{SITE_URL}/auth/profile" class="btn">Мои заказы</a>
    </div>

    <div class="notice">
      Если у вас возникли вопросы — позвоните нам или напишите в чат на сайте.
      Мы работаем Пн–Пт 9:00–20:00, Сб 10:00–18:00.
    </div>
    """.replace(',', ' ')

    return _base_template(
        title=f'Заказ #{order.id} — LOFT DC',
        preview=f'Ваш заказ #{order.id} на сумму {order.total:,} ₽ успешно оформлен'.replace(',', ' '),
        body_html=body
    )


# ─── Шаблон: Смена/сброс пароля ─────────────────────────────────────────────

def _reset_password_html(user_name: str, reset_url: str) -> str:
    body = f"""
    <div class="title">СБРОС <span class="title-accent">ПАРОЛЯ</span></div>
    <div class="subtitle">безопасность аккаунта</div>

    <p style="font-size:18px;color:{C_MUTED};margin-bottom:24px;font-style:italic">
      Здравствуйте, <strong style="color:{C_TEXT}">{user_name.split()[0]}</strong>!
      Мы получили запрос на сброс пароля для вашего аккаунта.
    </p>

    <div class="notice">
      Ссылка для сброса пароля действительна <strong>30 минут</strong>.
      Если вы не запрашивали сброс — просто проигнорируйте это письмо.
    </div>

    <div class="btn-wrap">
      <a href="{reset_url}" class="btn">Сбросить пароль</a>
    </div>

    <div class="div"></div>

    <p style="font-family:'JetBrains Mono',monospace;font-size:11px;color:{C_MUTED};
       letter-spacing:.5px;margin-bottom:8px">Или скопируйте ссылку в браузер:</p>
    <p style="font-family:'JetBrains Mono',monospace;font-size:11px;
       background:{C_BLACK};padding:14px 16px;word-break:break-all;
       border:1px solid rgba(255,255,255,.08);color:{C_ACCENT}">
      {reset_url}
    </p>

    <div class="div"></div>

    <div class="notice notice-red" style="font-size:14px">
      Если вы не запрашивали сброс пароля — немедленно смените пароль
      и обратитесь в поддержку. Возможно, кто-то пытается получить доступ к вашему аккаунту.
    </div>
    """

    return _base_template(
        title='Сброс пароля — LOFT DC',
        preview='Запрос на сброс пароля. Ссылка действительна 30 минут.',
        body_html=body
    )


# ─── Шаблон: Смена статуса заказа ───────────────────────────────────────────

def _order_status_html(order) -> str:
    status_icons = {
        'В обработке': '⚙️',
        'Отправлен':   '🚚',
        'Доставлен':   '✅',
        'Отменён':     '❌',
    }
    status_colors = {
        'В обработке': C_ACCENT,
        'Отправлен':   '#2980b9',
        'Доставлен':   C_GREEN,
        'Отменён':     C_RED,
    }
    icon  = status_icons.get(order.status, '📋')
    color = status_colors.get(order.status, C_ACCENT)

    body = f"""
    <div class="title">ЗАКАЗ <span class="title-accent">#{order.id}</span></div>
    <div class="subtitle">обновление статуса</div>

    <p style="font-size:18px;color:{C_MUTED};margin-bottom:28px;font-style:italic">
      Здравствуйте, <strong style="color:{C_TEXT}">{order.user_name.split()[0]}</strong>!
      Статус вашего заказа изменился.
    </p>

    <div style="text-align:center;padding:32px;background:{C_BLACK};
         border:1px solid {color};margin:20px 0">
      <div style="font-size:48px;margin-bottom:12px">{icon}</div>
      <div style="font-family:'Bebas Neue',sans-serif;font-size:36px;
           letter-spacing:4px;color:{color}">{order.status}</div>
    </div>

    <table class="info-table">
      <tr><td>Номер заказа</td><td>#{order.id}</td></tr>
      <tr><td>Сумма</td><td style="font-family:'JetBrains Mono',monospace;color:{C_ACCENT}">
        {str(order.total).replace(',', ' ')} ₽</td></tr>
      <tr><td>Адрес</td><td>{order.address}</td></tr>
    </table>

    <div class="btn-wrap">
      <a href="{SITE_URL}/auth/profile" class="btn">Детали заказа</a>
    </div>
    """

    return _base_template(
        title=f'Заказ #{order.id}: {order.status} — LOFT DC',
        preview=f'Статус заказа #{order.id} изменён на «{order.status}»',
        body_html=body
    )


# ─── Отправка ────────────────────────────────────────────────────────────────

def _send(to_email: str, subject: str, html: str,
          attachments: list = None) -> bool:
    if not MAIL_USER or not MAIL_PASS:
        print(f'[EMAIL] MAIL_USER/MAIL_PASSWORD не настроены. Письмо {subject!r} не отправлено.')
        return False
    try:
        from email.mime.base import MIMEBase
        from email import encoders as email_encoders

        msg = MIMEMultipart('mixed')
        msg['Subject'] = subject
        msg['From']    = MAIL_FROM
        msg['To']      = to_email

        body_part = MIMEMultipart('alternative')
        body_part.attach(MIMEText(html, 'html', 'utf-8'))
        msg.attach(body_part)

        if attachments:
            for att in attachments:
                mime = att.get('mime', 'application/octet-stream')
                data = att['data']
                if isinstance(data, str):
                    data = data.encode('utf-8')

                maintype, subtype = mime.split('/', 1)
                part = MIMEBase(maintype, subtype)
                part.set_payload(data)
                email_encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment',
                                filename=att['filename'])
                msg.attach(part)

        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=15) as srv:
            srv.login(MAIL_USER, MAIL_PASS)
            srv.sendmail(MAIL_USER, to_email, msg.as_bytes())
        print(f'[EMAIL] ✓ Отправлено на {to_email}: {subject}, вложений: {len(attachments) if attachments else 0}')
        return True
    except Exception as e:
        import traceback
        print(f'[EMAIL] ✗ Ошибка при отправке на {to_email}: {e}')
        print(traceback.format_exc())
        return False


# ─── Публичные функции ───────────────────────────────────────────────────────

def send_order_confirmation(order, user_email: str) -> bool:
    """Отправляет подтверждение заказа с PDF вложениями: счёт и накладная."""
    try:
        from app.doc_router import generate_invoice, generate_waybill
    except Exception as e:
        print(f'[EMAIL] Ошибка импорта doc_router: {e}')
        return _send(user_email, f'✓ Заказ #{order.id} оформлен — LOFT DC', html, [])

    html = _order_confirmation_html(order)
    attachments = []
    try:
        print(f'[EMAIL] Генерация документов для заказа #{order.id}...')
        inv_data, inv_mime, inv_fname = generate_invoice(order)
        wb_data,  wb_mime,  wb_fname  = generate_waybill(order)
        attachments = [
            {'filename': inv_fname, 'data': inv_data, 'mime': inv_mime},
            {'filename': wb_fname,  'data': wb_data,  'mime': wb_mime},
        ]
        print(f'[EMAIL] Документов: {len(attachments)}')
    except Exception as e:
        import traceback
        print(f'[EMAIL] Ошибка генерации документов: {e}')
        print(traceback.format_exc())
    return _send(user_email, f'✓ Заказ #{order.id} оформлен — LOFT DC', html, attachments)


def send_order_status_update(order, user_email: str) -> bool:
    """Отправляет уведомление об изменении статуса заказа."""
    html = _order_status_html(order)
    return _send(user_email, f'Заказ #{order.id}: {order.status} — LOFT DC', html)


def send_password_reset(user_name: str, user_email: str, reset_url: str) -> bool:
    """Отправляет ссылку для сброса пароля."""
    html = _reset_password_html(user_name, reset_url)
    return _send(user_email, 'Сброс пароля — LOFT DC', html)
