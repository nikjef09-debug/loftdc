"""
LOFT DC — Document Router
В режиме разработки (python run.py) генерирует PDF через reportlab.
В режиме exe (PyInstaller) генерирует HTML для просмотра в браузере.
"""

import sys

# True если запущено как .exe
IS_EXE = getattr(sys, 'frozen', False)


def _use_pdf():
    """Пробуем импортировать pdf_generator. Если не получается — используем HTML."""
    if IS_EXE:
        return False
    try:
        import reportlab
        return True
    except ImportError:
        return False


USE_PDF = _use_pdf()


# ─── Публичные функции ───────────────────────────────────────────────────────

def generate_invoice(order):
    if USE_PDF:
        from app.pdf_generator import generate_invoice_pdf
        return generate_invoice_pdf(order), 'application/pdf', f'Schet_{order.id:05d}.pdf'
    else:
        from app.documents import generate_invoice as gen
        return gen(order).encode('utf-8'), 'text/html; charset=utf-8', f'Schet_{order.id:05d}.html'


def generate_waybill(order):
    if USE_PDF:
        from app.pdf_generator import generate_waybill_pdf
        return generate_waybill_pdf(order), 'application/pdf', f'Nakladnaya_{order.id:05d}.pdf'
    else:
        from app.documents import generate_waybill as gen
        return gen(order).encode('utf-8'), 'text/html; charset=utf-8', f'Nakladnaya_{order.id:05d}.html'


def generate_proxy(order, courier_name='', courier_passport=''):
    if USE_PDF:
        from app.pdf_generator import generate_courier_proxy_pdf
        return generate_courier_proxy_pdf(order, courier_name, courier_passport), 'application/pdf', f'Doverennost_{order.id:05d}.pdf'
    else:
        from app.documents import generate_courier_proxy as gen
        return gen(order, courier_name, courier_passport).encode('utf-8'), 'text/html; charset=utf-8', f'Doverennost_{order.id:05d}.html'


def generate_refund(refund):
    if USE_PDF:
        from app.pdf_generator import generate_refund_act_pdf
        return generate_refund_act_pdf(refund), 'application/pdf', f'Vozvrat_{refund.id:05d}.pdf'
    else:
        from app.documents import generate_refund_act as gen
        return gen(refund).encode('utf-8'), 'text/html; charset=utf-8', f'Vozvrat_{refund.id:05d}.html'


def generate_receipt(order):
    """Чек для скачивания пользователем."""
    return generate_invoice(order)
