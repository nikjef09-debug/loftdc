from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import Config
import os

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Войдите, чтобы продолжить.'
login_manager.login_message_category = 'info'


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'instance'), exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    from app.routes.main    import main_bp
    from app.routes.auth    import auth_bp
    from app.routes.catalog import catalog_bp
    from app.routes.cart    import cart_bp
    from app.routes.orders  import orders_bp
    from app.routes.blog    import blog_bp
    from app.routes.admin   import admin_bp
    from app.routes.api     import api_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp,    url_prefix='/auth')
    app.register_blueprint(catalog_bp, url_prefix='/catalog')
    app.register_blueprint(cart_bp,    url_prefix='/cart')
    app.register_blueprint(orders_bp,  url_prefix='/orders')
    app.register_blueprint(blog_bp,    url_prefix='/blog')
    app.register_blueprint(admin_bp,   url_prefix='/admin')
    app.register_blueprint(api_bp,     url_prefix='/api')

    # CSRF токен доступен во всех шаблонах
    from app.security import generate_csrf_token
    app.jinja_env.globals['csrf_token'] = generate_csrf_token

    # Security headers
    @app.after_request
    def set_security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        return response

    with app.app_context():
        db.create_all()
        _seed()

    # Патч _words в pdf_generator — исправление суммы прописью
    try:
        import app.pdf_generator as _pg
        def _fixed_words(n):
            if n == 0: return 'Ноль'
            ones_m = ['','Один','Два','Три','Четыре','Пять','Шесть','Семь','Восемь','Девять']
            ones_f = ['','Одна','Две','Три','Четыре','Пять','Шесть','Семь','Восемь','Девять']
            teen   = ['Десять','Одиннадцать','Двенадцать','Тринадцать','Четырнадцать','Пятнадцать','Шестнадцать','Семнадцать','Восемнадцать','Девятнадцать']
            tens_  = ['','','Двадцать','Тридцать','Сорок','Пятьдесят','Шестьдесят','Семьдесят','Восемьдесят','Девяносто']
            hunds  = ['','Сто','Двести','Триста','Четыреста','Пятьсот','Шестьсот','Семьсот','Восемьсот','Девятьсот']
            def chunk(x, fem=False):
                r = []
                if x >= 100: r.append(hunds[x // 100]); x %= 100
                if 10 <= x <= 19: r.append(teen[x - 10]); return ' '.join(filter(None, r))
                if x >= 20: r.append(tens_[x // 10]); x %= 10
                if x > 0: r.append(ones_f[x] if fem else ones_m[x])
                return ' '.join(filter(None, r))
            def suf_t(t):
                r = t % 100; r = t % 10 if not (11 <= r <= 19) else 20
                return 'тысяч' if r in (0,5,6,7,8,9,20) else ('тысяча' if r == 1 else 'тысячи')
            def suf_m(m):
                r = m % 100; r = m % 10 if not (11 <= r <= 19) else 20
                return 'миллионов' if r in (0,5,6,7,8,9,20) else ('миллион' if r == 1 else 'миллиона')
            parts = []
            if n >= 1000000: m = n // 1000000; parts.append(f'{chunk(m)} {suf_m(m)}'); n %= 1000000
            if n >= 1000: t = n // 1000; parts.append(f'{chunk(t, True)} {suf_t(t)}'); n %= 1000
            if n > 0: parts.append(chunk(n))
            return ' '.join(filter(None, parts)).capitalize()
        _pg._words = _fixed_words
    except Exception:
        pass

    return app


def _seed():
    from app.models import User, Product, Order, OrderItem, Review, Article, Coupon, Message
    from werkzeug.security import generate_password_hash

    if User.query.count() == 0:
        for name, email, phone, role, pw in [
            ('Александр Смирнов', 'admin@loftdc.ru',   '+7 (996) 441-98-78', 'admin',   'admin123'),
            ('Мария Козлова',     'manager@loftdc.ru', '+7 (999) 222-33-44', 'manager', 'manager123'),
            ('Иван Петров',       'user@loftdc.ru',    '+7 (999) 555-66-77', 'user',    'user123'),
        ]:
            u = User(name=name, email=email, phone=phone, role=role,
                     password_hash=generate_password_hash(pw))
            db.session.add(u)
        db.session.commit()

    if Product.query.count() == 0:
        products = [
            ('Стол Birman Industrial','Столы',42000,52000,'Лаконичный обеденный стол с металлокаркасом из профильной трубы 40×40 мм и столешницей из массива дуба 40 мм.','🍽','Металл, дуб','160×80×75 см','sale','sale',5),
            ('Кресло Loft Baron','Кресла',28000,None,'Кресло с каркасом из стальной трубы и обивкой из натуральной кожи. Подлокотники из массива ясеня.','🪑','Сталь, кожа, ясень','65×70×85 см','hit','',8),
            ('Диван Graf Lounge','Диваны',89000,None,'Угловой диван в стиле лофт. Каркас — сварная конструкция из профильной трубы. Обивка — премиальный велюр.','🛋','Металл, велюр','220×150×85 см','new','new',3),
            ('Стеллаж Pipe Library','Стеллажи',35000,None,'Открытый стеллаж в индустриальном стиле. Трубы ½" из чёрной стали. Полки из состаренной сосны.','📚','Труба, сосна','120×30×200 см','','',10),
            ('Тумба Birman Side','Тумбы',18500,22000,'Прикроватная тумба с металлическим каркасом и выдвижным ящиком из дуба. Фурнитура — матовый никель.','🗄','Металл, дуб','45×40×55 см','sale','sale',12),
            ('Кровать Frame Loft','Кровати',68000,None,'Двуспальная кровать с металлическим изголовьем и деревянным основанием. Ортопедические ламели в комплекте.','🛏','Металл, дуб','170×210×95 см','','',4),
            ('Стул Iron Classic','Стулья',12000,15000,'Классический стул в стиле лофт. Сиденье из фанеры 18 мм, покрытой шпоном дуба. Металлические ножки.','🪑','Металл, дуб','45×45×85 см','sale','sale',20),
            ('Шкаф Industrial Wardrobe','Шкафы',95000,None,'Распашной шкаф. Корпус из фанеры 18 мм с фасадом из металла. Внутренняя отделка из сосны.','🚪','Металл, фанера, сосна','180×60×220 см','new','new',2),
            ('Светильник Edison Pendant','Освещение',8500,None,'Подвесной светильник в стиле лофт. Патрон E27 с ретро-лампой Эдисона 40W в комплекте.','💡','Металл, текстиль','Ø15 см, провод 1,5–3 м','','',15),
            ('Стол Coffee Industrial','Столы',24500,29000,'Журнальный столик с рамой из чёрного металла и столешницей из закалённого стекла 10 мм.','☕','Металл, стекло, дуб','110×60×45 см','sale','sale',6),
            ('Барный стул High Loft','Стулья',16500,None,'Барный стул с регулируемой высотой (65–85 см). Мягкое сиденье в обивке из искусственной кожи.','🍸','Металл, экокожа','Ø40 см, h: 65–85 см','hit','',18),
            ('Вешалка Pipe Stand','Тумбы',9800,None,'Напольная вешалка из водопроводных труб ½". Три горизонтальных плеча. Полка для обуви из сосны.','🧥','Труба, сосна','60×30×180 см','new','new',25),
        ]
        for name, cat, price, old_price, desc, emoji, material, size, badge, badge_cls, stock in products:
            db.session.add(Product(name=name, category=cat, price=price, old_price=old_price,
                                   description=desc, emoji=emoji, material=material,
                                   size=size, badge=badge, badge_class=badge_cls, stock=stock))
        db.session.commit()

    if Review.query.count() == 0:
        revs = [
            (1,'Дмитрий К.',5,'Заказывал для своего кабинета — качество превосходное! Металл ровный, дерево без сучков.'),
            (2,'Анна М.',5,'Шикарное кресло! Кожа мягкая, сидеть удобно часами. Рекомендую!'),
            (6,'Сергей В.',5,'Брали кровать в новую квартиру. Ламели прочные, каркас не скрипит.'),
            (9,'Елена Р.',4,'Очень стильный светильник. Лампа Эдисона создаёт уютную атмосферу.'),
            (3,'Михаил Д.',5,'Долго выбирал диван, остановился на этом. Не пожалел! Велюр приятный.'),
            (7,'Ольга С.',4,'Взяли 6 штук под обеденный стол. Смотрятся отлично.'),
        ]
        for pid, author, rating, text in revs:
            p = Product.query.get(pid)
            if p:
                db.session.add(Review(product_id=pid, author=author, rating=rating, text=text))
        db.session.commit()

    if Article.query.count() == 0:
        arts = [
            ('10 идей для лофт-интерьера в малогабаритной квартире','Интерьер','🏠',
             'Стиль лофт принято считать уделом просторных помещений. Но это не так — рассказываем, как создать лофт-атмосферу даже в 30 м².',
             'Стиль лофт зародился в Нью-Йорке 1950-х в бывших промышленных помещениях. Его главные черты — открытое пространство, необработанные поверхности, металл и дерево.\n\n1. Используйте высокие стеллажи вместо шкафов\n2. Оставьте кирпич или имитируйте его обоями\n3. Выбирайте мебель с металлическими ногами\n4. Откажитесь от натяжных потолков\n5. Добавьте открытые трубы как декор\n6. Используйте лампы Эдисона\n7. Выбирайте тёмные акценты в текстиле\n8. Минимум декора — максимум функциональности\n9. Бетонный пол или ламинат под бетон\n10. Стеклянные перегородки вместо стен'),
            ('Как выбрать стол в стиле лофт: полное руководство','Выбор мебели','🍽',
             'Стол — центр любого интерьера. Рассказываем, на что обратить внимание при выборе лофт-стола.',
             'Материал каркаса: профильная труба 40×40 мм — оптимальный выбор.\n\nМатериал столешницы: массив дерева 40+ мм обеспечивает долговечность.\n\nПокрытие металла: порошковая краска долговечнее обычной. Фосфатирование перед покраской — признак качественного производства.\n\nРазмеры: стандартная высота — 75 см, для барного стола — 90–105 см.'),
            ('История стиля лофт: от заводов до пентхаусов','История','🏭',
             'Откуда взялся лофт и почему стал одним из самых популярных интерьерных стилей мира.',
             'История стиля лофт начинается в послевоенном Нью-Йорке. После Второй мировой войны производство начало уходить из центра города, оставляя пустые фабрики в Сохо и Трайбеке.\n\nСначала художники, потом молодёжь начали заселять эти пространства нелегально. Огромные окна, кирпичные стены, деревянные перекрытия стали частью нового эстетического языка.\n\nВ 1970-х лофт стал статусным. К 2000-м — это уже глобальный тренд.'),
            ('Уход за мебелью из металла и дерева','Уход','🔧',
             'Правильный уход продлевает жизнь мебели в разы. Делимся профессиональными секретами.',
             'Металлические части:\n• Раз в полгода протирайте металл льняным маслом\n• Для очистки используйте мягкую влажную тряпку без абразивов\n• Царапины закрашивайте аэрозольной краской в тон\n\nДеревянные части:\n• Масло-восковое покрытие обновляйте раз в год\n• Избегайте прямых солнечных лучей\n• Влажность в помещении держите 40–60%'),
            ('Лофт в ресторане: кейс «Гараж» в Москве','Проекты','🍽',
             'Кейс: 400 м² ресторанного пространства, 3 недели производства, 200 предметов мебели.',
             'Ресторан «Гараж» — один из наших любимых проектов 2023 года.\n\nЧто сделали:\n• 40 обеденных столов Birman Industrial\n• 160 стульев Iron Classic\n• 6 барных стоек длиной от 2 до 4 метров\n• 20 барных стульев High Loft\n• Стеллажи под алкоголь вдоль всей стены\n• 80 светильников Edison Pendant\n\nРезультат: ресторан открылся в срок, интерьер получил 5 публикаций.'),
            ('Тренды лофт-мебели 2024','Тренды','✨',
             'Какие материалы, цвета и формы будут в моде в 2024 году.',
             'Тренд 1: Тёплый металл — матовая медь и брашированная латунь.\n\nТренд 2: Живые края — столешницы из цельных слабов дерева.\n\nТренд 3: Смешение стилей — лофт + японский минимализм.\n\nТренд 4: Устойчивость — возрождённый металл и переработанное дерево.\n\nТренд 5: Модульность — системы мебели, которые можно перекомпоновывать.'),
        ]
        for title, cat, emoji, desc, body in arts:
            db.session.add(Article(title=title, category=cat, emoji=emoji, description=desc, body=body))
        db.session.commit()

    if Coupon.query.count() == 0:
        for code, disc in [('LOFT10',10),('SALE15',15),('FIRST20',20)]:
            db.session.add(Coupon(code=code, discount=disc, active=True, uses=0))
        db.session.commit()
