"""
LOFT DC — Генератор документов заказа
Создаёт HTML-документы (счёт, накладная, доверенность) для печати/скачивания.

Использование:
    from app.documents import generate_invoice, generate_waybill, generate_proxy
    html = generate_invoice(order)
    return Response(html, mimetype='text/html')
"""

from datetime import datetime, timedelta


# ─── Реквизиты компании ──────────────────────────────────────────────────────

COMPANY = {
    'name':     'ООО «ЛОФТ ДС»',
    'inn':      '7700000000',
    'kpp':      '770001001',
    'ogrn':     '1027700000000',
    'address':  'г. Москва, ул. Лофтовая, д. 1, оф. 101',
    'phone':    '+7 (800) 000-00-00',
    'email':    'info@loftdc.ru',
    'bank':     'АО «АЛЬФА-БАНК»',
    'bik':      '044525593',
    'rs':       '40702810000000000000',
    'ks':       '30101810200000000593',
    'director': 'Иванов Иван Иванович',
}

# Стили (общие для всех документов)
_DOC_CSS = """
  @import url('https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@0,400;0,700;1,400&family=PT+Mono&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'PT Serif', Georgia, serif; font-size: 13px;
         color: #111; background: #fff; padding: 28px 36px; max-width: 820px;
         margin: 0 auto; line-height: 1.5; }
  h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px; }
  h2 { font-size: 14px; font-weight: 700; margin: 20px 0 10px; text-transform: uppercase;
       letter-spacing: .8px; border-bottom: 1px solid #ccc; padding-bottom: 6px; }
  .doc-header { display: flex; justify-content: space-between; align-items: flex-start;
                border-bottom: 2px solid #111; padding-bottom: 16px; margin-bottom: 20px; }
  .doc-logo { font-size: 28px; font-weight: 700; letter-spacing: 4px; }
  .doc-logo span { color: #8a7a60; }
  .doc-meta { text-align: right; font-family: 'PT Mono', monospace; font-size: 11px; color: #555; }
  .doc-title { margin: 16px 0 20px; }
  .doc-title h1 { display: inline; }
  .doc-title .doc-num { display: inline; font-family: 'PT Mono', monospace; color: #8a7a60; }
  table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 13px; }
  table th { background: #111; color: #fff; padding: 8px 10px; text-align: left;
              font-family: 'PT Mono', monospace; font-size: 10px; letter-spacing: 1px;
              text-transform: uppercase; }
  table td { padding: 8px 10px; border-bottom: 1px solid #eee; vertical-align: top; }
  table tr:last-child td { border-bottom: none; }
  table tr:nth-child(even) { background: #fafafa; }
  .total-row td { font-weight: 700; background: #f5f5f0 !important;
                  border-top: 2px solid #111; font-size: 15px; }
  .total-amount { font-family: 'PT Mono', monospace; font-size: 17px; }
  .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin: 16px 0; }
  .info-block { background: #f9f9f7; border: 1px solid #e0e0d8; padding: 14px 16px; }
  .info-block .label { font-family: 'PT Mono', monospace; font-size: 9px; letter-spacing: 1.5px;
                        text-transform: uppercase; color: #888; margin-bottom: 6px; }
  .info-block p { font-size: 13px; line-height: 1.7; }
  .sign-row { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-top: 36px; }
  .sign-block { border-top: 1px solid #aaa; padding-top: 8px; }
  .sign-block .role { font-family: 'PT Mono', monospace; font-size: 10px; letter-spacing: 1px;
                       text-transform: uppercase; color: #888; }
  .sign-block .name { font-size: 13px; margin-top: 28px; }
  .sign-block .line { border-bottom: 1px solid #ccc; margin: 24px 0 6px; }
  .stamp-area { border: 2px dashed #ccc; border-radius: 50%; width: 90px; height: 90px;
                display: flex; align-items: center; justify-content: center; margin-top: 8px;
                font-family: 'PT Mono', monospace; font-size: 9px; color: #ccc;
                text-align: center; letter-spacing: 1px; }
  .footer { margin-top: 40px; border-top: 1px solid #ddd; padding-top: 12px;
             font-family: 'PT Mono', monospace; font-size: 10px; color: #aaa;
             display: flex; justify-content: space-between; }
  .notice-box { border-left: 3px solid #d4c5a9; background: #faf8f4;
                 padding: 12px 16px; margin: 16px 0; font-size: 13px;
                 font-style: italic; color: #555; }
  .badge-important { display: inline-block; background: #111; color: #fff;
                      font-family: 'PT Mono', monospace; font-size: 9px; letter-spacing: 2px;
                      text-transform: uppercase; padding: 4px 12px; }
  @media print {
    body { padding: 0; }
    .no-print { display: none !important; }
    @page { margin: 15mm 20mm; }
  }
  .print-btn { position: fixed; top: 20px; right: 20px; background: #111; color: #fff;
                font-family: 'PT Mono', monospace; font-size: 11px; letter-spacing: 2px;
                text-transform: uppercase; padding: 10px 20px; border: none; cursor: pointer;
                z-index: 100; }
  .print-btn:hover { background: #8a7a60; }
"""

def _wrap(title: str, body: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>{title}</title>
  <style>{_DOC_CSS}</style>
</head>
<body>
<button class="print-btn no-print" onclick="window.print()">🖨 Печать</button>
{body}
</body>
</html>"""


def _format_money(amount: int) -> str:
    """1234567 → 1 234 567 ₽"""
    return f"{amount:,}".replace(",", "\u2009") + "\u00a0₽"


def _number_to_words_short(n: int) -> str:
    """Упрощённое: 15000 → 'Пятнадцать тысяч'"""
    # Базовая реализация для типичных сумм
    ones = ['', 'Один', 'Два', 'Три', 'Четыре', 'Пять', 'Шесть', 'Семь', 'Восемь', 'Девять',
            'Десять', 'Одиннадцать', 'Двенадцать', 'Тринадцать', 'Четырнадцать', 'Пятнадцать',
            'Шестнадцать', 'Семнадцать', 'Восемнадцать', 'Девятнадцать']
    tens = ['', '', 'Двадцать', 'Тридцать', 'Сорок', 'Пятьдесят',
            'Шестьдесят', 'Семьдесят', 'Восемьдесят', 'Девяносто']
    hundreds = ['', 'Сто', 'Двести', 'Триста', 'Четыреста', 'Пятьсот',
                'Шестьсот', 'Семьсот', 'Восемьсот', 'Девятьсот']
    if n == 0:
        return 'Ноль'
    parts = []
    if n >= 1_000_000:
        m = n // 1_000_000
        parts.append(f'{ones[m] if m < 20 else tens[m//10]} миллион{"ов" if 5<=m<=20 else ("" if m==1 else "а")}')
        n %= 1_000_000
    if n >= 1000:
        t = n // 1000
        ones_f = ['', 'Одна', 'Две', 'Три', 'Четыре', 'Пять', 'Шесть', 'Семь', 'Восемь', 'Девять']
        t_word = ones_f[t] if t < 10 else (ones[t] if t < 20 else f'{tens[t//10]} {ones_f[t%10]}'.strip())
        suf = 'тысяч' if 5 <= (t % 100 if 11 <= t % 100 <= 19 else t % 10) <= 20 or t % 10 == 0 else \
              'тысяча' if t % 10 == 1 else 'тысячи'
        parts.append(f'{t_word} {suf}')
        n %= 1000
    if n >= 100:
        parts.append(hundreds[n // 100])
        n %= 100
    if n >= 20:
        parts.append(tens[n // 10])
        n %= 10
    if n > 0:
        parts.append(ones[n])
    return ' '.join(p for p in parts if p)


# ─── 1. СЧЁТ НА ОПЛАТУ ──────────────────────────────────────────────────────

def generate_invoice(order) -> str:
    """Счёт на оплату — документ для перевода денег."""
    doc_num  = f'{order.id:05d}'
    doc_date = order.created_at.strftime('%d.%m.%Y')
    due_date = (order.created_at + timedelta(days=5)).strftime('%d.%m.%Y')

    rows = ''
    for i, item in enumerate(order.items, 1):
        rows += f"""
        <tr>
          <td style="width:30px;font-family:'PT Mono',monospace;color:#888">{i}</td>
          <td>{item.emoji} {item.name}</td>
          <td style="text-align:center;font-family:'PT Mono',monospace">{item.qty}</td>
          <td style="text-align:right;font-family:'PT Mono',monospace">{_format_money(item.price)}</td>
          <td style="text-align:right;font-family:'PT Mono',monospace;font-weight:700">
            {_format_money(item.price * item.qty)}</td>
        </tr>"""

    discount_row = ''
    if order.discount:
        disc_amt = int(order.total / (1 - order.discount/100) * order.discount/100)
        discount_row = f"""
        <tr style="background:#faf8f4 !important">
          <td colspan="4" style="font-style:italic;color:#888">
            Скидка по промокоду {order.coupon_code} ({order.discount}%)</td>
          <td style="text-align:right;font-family:'PT Mono',monospace;color:#c0392b">
            −{_format_money(disc_amt)}</td>
        </tr>"""

    amount_words = _number_to_words_short(order.total)
    kopecks = '00'

    body = f"""
<div class="doc-header">
  <div>
    <div class="doc-logo">LOFT<span>DC</span></div>
    <div style="font-family:'PT Mono',monospace;font-size:10px;color:#888;margin-top:4px;letter-spacing:1px">
      МЕБЕЛЬ И ДЕКОР</div>
  </div>
  <div class="doc-meta">
    <div>{COMPANY['name']}</div>
    <div>ИНН {COMPANY['inn']} / КПП {COMPANY['kpp']}</div>
    <div>{COMPANY['address']}</div>
    <div>{COMPANY['phone']}</div>
  </div>
</div>

<div style="background:#111;color:#fff;padding:10px 16px;margin-bottom:16px;
     display:flex;justify-content:space-between;align-items:center">
  <div>
    <span style="font-family:'PT Mono',monospace;font-size:10px;letter-spacing:2px;color:#d4c5a9">СЧЁТ НА ОПЛАТУ</span>
    <span style="font-family:'PT Mono',monospace;font-size:10px;color:#888;margin-left:12px">№ {doc_num}</span>
  </div>
  <div style="font-family:'PT Mono',monospace;font-size:11px;color:#aaa">от {doc_date}</div>
</div>

<div class="two-col">
  <div class="info-block">
    <div class="label">Поставщик</div>
    <p><strong>{COMPANY['name']}</strong><br>
    ИНН: {COMPANY['inn']}<br>
    КПП: {COMPANY['kpp']}<br>
    {COMPANY['address']}<br>
    Тел: {COMPANY['phone']}</p>
  </div>
  <div class="info-block">
    <div class="label">Покупатель</div>
    <p><strong>{order.user_name}</strong><br>
    Тел: {order.phone}<br>
    Адрес доставки:<br>{order.address}</p>
  </div>
</div>

<div class="info-block" style="margin:12px 0">
  <div class="label">Банковские реквизиты</div>
  <p style="display:grid;grid-template-columns:1fr 1fr;gap:4px 24px;font-family:'PT Mono',monospace;font-size:11px">
    <span>Банк: {COMPANY['bank']}</span>
    <span>БИК: {COMPANY['bik']}</span>
    <span>р/с: {COMPANY['rs']}</span>
    <span>к/с: {COMPANY['ks']}</span>
  </p>
</div>

<table>
  <thead>
    <tr>
      <th style="width:30px">№</th>
      <th>Наименование</th>
      <th style="width:60px;text-align:center">Кол-во</th>
      <th style="width:120px;text-align:right">Цена</th>
      <th style="width:130px;text-align:right">Сумма</th>
    </tr>
  </thead>
  <tbody>
    {rows}
    {discount_row}
  </tbody>
  <tfoot>
    <tr class="total-row">
      <td colspan="4">Итого к оплате:</td>
      <td class="total-amount" style="text-align:right">{_format_money(order.total)}</td>
    </tr>
  </tfoot>
</table>

<div class="notice-box">
  <strong>Сумма прописью:</strong> {amount_words} рублей {kopecks} копеек. НДС не облагается (УСН).
</div>

<div style="font-family:'PT Mono',monospace;font-size:10px;color:#888;
     display:flex;justify-content:space-between;margin:12px 0">
  <span>Способ оплаты: <strong style="color:#111">{order.payment or 'По договорённости'}</strong></span>
  <span>Оплатить до: <strong style="color:#111">{due_date}</strong></span>
  {'<span>Промокод: <strong style="color:#8a7a60">' + order.coupon_code + ' (−' + str(order.discount) + '%)</strong></span>' if order.coupon_code else ''}
</div>

<div class="sign-row">
  <div class="sign-block">
    <div class="role">Руководитель</div>
    <div class="line"></div>
    <div class="name">{COMPANY['director']}</div>
    <div style="margin-top:6px">
      <div class="stamp-area">М.П.</div>
    </div>
  </div>
  <div class="sign-block">
    <div class="role">Бухгалтер</div>
    <div class="line"></div>
    <div class="name">________________</div>
  </div>
</div>

<div class="footer">
  <span>Документ сформирован автоматически · {datetime.now().strftime('%d.%m.%Y %H:%M')}</span>
  <span>Заказ #{order.id} · loftdc.ru</span>
</div>"""

    return _wrap(f'Счёт №{doc_num} от {doc_date} — LOFT DC', body)


# ─── 2. ТОВАРНАЯ НАКЛАДНАЯ ───────────────────────────────────────────────────

def generate_waybill(order) -> str:
    """Товарная накладная ТОРГ-12 (упрощённая)."""
    doc_num  = f'Н-{order.id:05d}'
    doc_date = order.created_at.strftime('%d.%m.%Y')

    rows = ''
    total_qty = 0
    for i, item in enumerate(order.items, 1):
        subtotal = item.price * item.qty
        total_qty += item.qty
        rows += f"""
        <tr>
          <td style="width:30px;font-family:'PT Mono',monospace;color:#888">{i}</td>
          <td>{item.emoji} {item.name}</td>
          <td style="width:40px;text-align:center">шт.</td>
          <td style="width:60px;text-align:center;font-family:'PT Mono',monospace">{item.qty}</td>
          <td style="width:120px;text-align:right;font-family:'PT Mono',monospace">{_format_money(item.price)}</td>
          <td style="width:130px;text-align:right;font-family:'PT Mono',monospace;font-weight:700">
            {_format_money(subtotal)}</td>
        </tr>"""

    body = f"""
<div class="doc-header">
  <div>
    <div class="doc-logo">LOFT<span>DC</span></div>
  </div>
  <div class="doc-meta">
    <div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px">
      Форма ТОРГ-12 (упрощённая)</div>
    <div>{COMPANY['name']}</div>
    <div>ИНН {COMPANY['inn']}</div>
  </div>
</div>

<div style="background:#111;color:#fff;padding:10px 16px;margin-bottom:16px;
     display:flex;justify-content:space-between;align-items:center">
  <div>
    <span style="font-family:'PT Mono',monospace;font-size:10px;letter-spacing:2px;color:#d4c5a9">ТОВАРНАЯ НАКЛАДНАЯ</span>
    <span style="font-family:'PT Mono',monospace;font-size:10px;color:#888;margin-left:12px">№ {doc_num}</span>
  </div>
  <div style="font-family:'PT Mono',monospace;font-size:11px;color:#aaa">от {doc_date}</div>
</div>

<div class="two-col">
  <div class="info-block">
    <div class="label">Грузоотправитель / Продавец</div>
    <p><strong>{COMPANY['name']}</strong><br>
    ИНН: {COMPANY['inn']} / ОГРН: {COMPANY['ogrn']}<br>
    {COMPANY['address']}<br>
    Тел: {COMPANY['phone']}</p>
  </div>
  <div class="info-block">
    <div class="label">Грузополучатель / Покупатель</div>
    <p><strong>{order.user_name}</strong><br>
    Тел: {order.phone}<br>
    Адрес доставки:<br>{order.address}</p>
  </div>
</div>

<div style="font-family:'PT Mono',monospace;font-size:10px;color:#888;
     border:1px solid #e0e0d8;padding:10px 14px;margin:8px 0;
     display:flex;gap:32px">
  <span>Основание: <strong style="color:#111">Заказ №{order.id}</strong></span>
  <span>Доставка: <strong style="color:#111">{order.delivery or 'Самовывоз'}</strong></span>
  <span>Оплата: <strong style="color:#111">{order.payment or '—'}</strong></span>
</div>

<table>
  <thead>
    <tr>
      <th style="width:30px">№</th>
      <th>Наименование товара</th>
      <th style="width:40px">Ед.</th>
      <th style="width:60px;text-align:center">Кол-во</th>
      <th style="width:120px;text-align:right">Цена</th>
      <th style="width:130px;text-align:right">Сумма</th>
    </tr>
  </thead>
  <tbody>{rows}</tbody>
  <tfoot>
    <tr class="total-row">
      <td colspan="3">Итого:</td>
      <td style="text-align:center;font-family:'PT Mono',monospace">{total_qty}</td>
      <td></td>
      <td class="total-amount" style="text-align:right">{_format_money(order.total)}</td>
    </tr>
  </tfoot>
</table>

<div class="notice-box">
  Всего наименований: {sum(1 for _ in order.items)}, на сумму: <strong>{_format_money(order.total)}</strong><br>
  Сумма прописью: {_number_to_words_short(order.total)} рублей 00 копеек. НДС не облагается.
</div>

<div class="sign-row" style="grid-template-columns:1fr 1fr 1fr">
  <div class="sign-block">
    <div class="role">Отпустил (продавец)</div>
    <div class="line"></div>
    <div class="name">{COMPANY['director']}</div>
    <div style="margin-top:6px"><div class="stamp-area">М.П.</div></div>
  </div>
  <div class="sign-block">
    <div class="role">Груз принял</div>
    <div class="line"></div>
    <div class="name" style="font-family:'PT Mono',monospace;font-size:11px">
      {order.user_name}</div>
    <div style="margin-top:28px;font-family:'PT Mono',monospace;font-size:10px;color:#888">
      Подпись ________________</div>
  </div>
  <div class="sign-block">
    <div class="role">Дата получения</div>
    <div class="line"></div>
    <div style="font-family:'PT Mono',monospace;font-size:24px;color:#ccc;margin-top:8px">
      &nbsp;&nbsp;.&nbsp;&nbsp;&nbsp;.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
  </div>
</div>

<div class="footer">
  <span>Документ сформирован автоматически · {datetime.now().strftime('%d.%m.%Y %H:%M')}</span>
  <span>Заказ #{order.id} · loftdc.ru</span>
</div>"""

    return _wrap(f'Накладная {doc_num} от {doc_date} — LOFT DC', body)


# ─── 3. ДОВЕРЕННОСТЬ КУРЬЕРА ─────────────────────────────────────────────────

def generate_courier_proxy(order, courier_name: str = '', courier_passport: str = '') -> str:
    """Доверенность на получение/доставку заказа курьером."""
    doc_num  = f'Д-{order.id:05d}'
    doc_date = order.created_at.strftime('%d.%m.%Y')
    valid_until = (order.created_at + timedelta(days=30)).strftime('%d.%m.%Y')

    cn = courier_name    or '___________________________________'
    cp = courier_passport or '_________________________'

    items_list = '<br>'.join(
        f'— {item.emoji} {item.name}, {item.qty} шт., {_format_money(item.price * item.qty)}'
        for item in order.items
    )

    body = f"""
<div class="doc-header">
  <div>
    <div class="doc-logo">LOFT<span>DC</span></div>
  </div>
  <div class="doc-meta">
    <div>{COMPANY['name']}</div>
    <div>ИНН {COMPANY['inn']}</div>
  </div>
</div>

<div style="text-align:center;margin:24px 0 20px">
  <div style="font-family:'PT Mono',monospace;font-size:10px;letter-spacing:3px;
       text-transform:uppercase;color:#888;margin-bottom:8px">Документ</div>
  <h1>ДОВЕРЕННОСТЬ № {doc_num}</h1>
  <div style="font-family:'PT Mono',monospace;font-size:11px;color:#888;margin-top:6px">
    от {doc_date} г. &nbsp;·&nbsp; г. Москва</div>
</div>

<div class="notice-box" style="border-left-color:#111">
  <strong>{COMPANY['name']}</strong> (ИНН: {COMPANY['inn']}, ОГРН: {COMPANY['ogrn']},
  адрес: {COMPANY['address']}), в лице Генерального директора
  <strong>{COMPANY['director']}</strong>, действующего на основании Устава,
  настоящей доверенностью уполномочивает:
</div>

<div class="info-block" style="margin:16px 0">
  <div class="label">Уполномоченное лицо (курьер)</div>
  <table style="border:none;margin:0">
    <tr>
      <td style="border:none;width:40%;padding:6px 0;font-family:'PT Mono',monospace;
          font-size:10px;letter-spacing:1px;color:#888;text-transform:uppercase">ФИО</td>
      <td style="border:none;padding:6px 0;font-size:15px;font-weight:700">{cn}</td>
    </tr>
    <tr>
      <td style="border:none;padding:6px 0;font-family:'PT Mono',monospace;
          font-size:10px;letter-spacing:1px;color:#888;text-transform:uppercase">Паспорт</td>
      <td style="border:none;padding:6px 0;font-family:'PT Mono',monospace">{cp}</td>
    </tr>
  </table>
</div>

<p style="margin:16px 0;line-height:1.9;font-size:14px">
  <strong>совершить следующие действия</strong> от имени {COMPANY['name']}:
  осуществить доставку и передачу товаров покупателю по заказу
  <strong>№{order.id} от {doc_date} г.</strong>
</p>

<div class="info-block" style="margin:16px 0">
  <div class="label">Данные покупателя</div>
  <p><strong>{order.user_name}</strong><br>
  Телефон: {order.phone}<br>
  Адрес доставки: <strong>{order.address}</strong></p>
</div>

<div class="info-block" style="margin:16px 0">
  <div class="label">Перечень передаваемых товаров</div>
  <p style="line-height:2.2">{items_list}</p>
  <p style="margin-top:10px;font-family:'PT Mono',monospace;font-size:11px">
    <strong>Итого: {_format_money(order.total)}</strong>
    ({_number_to_words_short(order.total)} рублей 00 копеек)</p>
</div>

<p style="margin:16px 0;font-size:14px;line-height:1.9">
  Доверенность выдана <strong>без права передоверия</strong>.
  Срок действия: по <strong>{valid_until}</strong> включительно.
</p>

<div class="notice-box">
  При передаче товара курьер обязан предъявить настоящую доверенность и документ,
  удостоверяющий личность. Покупатель вправе проверить соответствие личности курьера
  данным, указанным в доверенности.
</div>

<div class="sign-row">
  <div class="sign-block">
    <div class="role">Доверитель — Генеральный директор</div>
    <div class="line"></div>
    <div class="name">{COMPANY['director']}</div>
    <div style="margin-top:6px"><div class="stamp-area">М.П.</div></div>
  </div>
  <div class="sign-block">
    <div class="role">Доверенное лицо (курьер)</div>
    <div class="line"></div>
    <div class="name" style="font-family:'PT Mono',monospace;font-size:12px">{cn}</div>
    <div style="margin-top:28px;font-family:'PT Mono',monospace;font-size:10px;color:#888">
      Подпись ________________</div>
  </div>
</div>

<div class="footer">
  <span>Документ сформирован автоматически · {datetime.now().strftime('%d.%m.%Y %H:%M')}</span>
  <span>Заказ #{order.id} · loftdc.ru</span>
</div>"""

    return _wrap(f'Доверенность {doc_num} от {doc_date} — LOFT DC', body)


# ─── 4. АКТ ВОЗВРАТА ─────────────────────────────────────────────────────────

def generate_refund_act(refund) -> str:
    """Акт возврата товара."""
    order    = refund.order
    doc_num  = f'В-{refund.id:05d}'
    doc_date = refund.created_at.strftime('%d.%m.%Y')

    status_label = {'pending': 'На рассмотрении', 'approved': 'Одобрен', 'rejected': 'Отклонён'}.get(refund.status, refund.status)
    status_color = {'pending': '#e67e22', 'approved': '#27ae60', 'rejected': '#c0392b'}.get(refund.status, '#111')

    rows = ''
    for i, item in enumerate(order.items, 1):
        rows += f"""
        <tr>
          <td style="width:30px;font-family:'PT Mono',monospace;color:#888">{i}</td>
          <td>{item.emoji} {item.name}</td>
          <td style="text-align:center;font-family:'PT Mono',monospace">{item.qty}</td>
          <td style="text-align:right;font-family:'PT Mono',monospace">{_format_money(item.price)}</td>
          <td style="text-align:right;font-family:'PT Mono',monospace;font-weight:700">{_format_money(item.price * item.qty)}</td>
        </tr>"""

    note_block = f'''
    <div style="margin:16px 0;padding:14px 18px;border-left:3px solid #c0392b;background:#fdf5f5">
      <div style="font-family:'PT Mono',monospace;font-size:9px;letter-spacing:1.5px;text-transform:uppercase;color:#888;margin-bottom:6px">Примечание администратора</div>
      <p style="font-size:13px;color:#333;font-style:italic">{refund.admin_note}</p>
    </div>''' if refund.admin_note else ''

    resolved = refund.resolved_at.strftime('%d.%m.%Y') if refund.resolved_at else '—'

    body = f"""
<div class="doc-header">
  <div>
    <div class="doc-logo">LOFT<span>DC</span></div>
  </div>
  <div class="doc-meta">
    <div>{COMPANY['name']}</div>
    <div>ИНН {COMPANY['inn']}</div>
    <div style="margin-top:6px;font-size:12px;color:{status_color};font-weight:700">{status_label}</div>
  </div>
</div>

<div style="background:#111;color:#fff;padding:10px 16px;margin-bottom:16px;
     display:flex;justify-content:space-between;align-items:center">
  <div>
    <span style="font-family:'PT Mono',monospace;font-size:10px;letter-spacing:2px;color:#e74c3c">АКТ ВОЗВРАТА ТОВАРА</span>
    <span style="font-family:'PT Mono',monospace;font-size:10px;color:#888;margin-left:12px">№ {doc_num}</span>
  </div>
  <div style="font-family:'PT Mono',monospace;font-size:11px;color:#aaa">от {doc_date}</div>
</div>

<div class="two-col">
  <div class="info-block">
    <div class="label">Продавец</div>
    <p><strong>{COMPANY['name']}</strong><br>
    ИНН: {COMPANY['inn']}<br>
    {COMPANY['address']}<br>
    Тел: {COMPANY['phone']}</p>
  </div>
  <div class="info-block">
    <div class="label">Покупатель</div>
    <p><strong>{refund.user.name}</strong><br>
    Тел: {order.phone}<br>
    Email: {refund.user.email}</p>
  </div>
</div>

<div style="font-family:'PT Mono',monospace;font-size:10px;color:#888;
     border:1px solid #e0e0d8;padding:10px 14px;margin:8px 0;
     display:flex;gap:32px;flex-wrap:wrap">
  <span>Заказ: <strong style="color:#111">№{order.id} от {order.created_at.strftime('%d.%m.%Y')}</strong></span>
  <span>Оплата: <strong style="color:#111">{order.payment}</strong></span>
  <span>Дата заявки: <strong style="color:#111">{doc_date}</strong></span>
  <span>Дата решения: <strong style="color:#111">{resolved}</strong></span>
</div>

<div class="notice-box" style="margin:16px 0">
  <strong>Причина возврата:</strong> {refund.reason}
</div>

{note_block}

<h2>Перечень возвращаемых товаров</h2>
<table>
  <thead>
    <tr>
      <th style="width:30px">№</th>
      <th>Наименование</th>
      <th style="width:60px;text-align:center">Кол-во</th>
      <th style="width:120px;text-align:right">Цена</th>
      <th style="width:130px;text-align:right">Сумма</th>
    </tr>
  </thead>
  <tbody>{rows}</tbody>
  <tfoot>
    <tr class="total-row">
      <td colspan="4">Итого к возврату:</td>
      <td class="total-amount" style="text-align:right;color:#c0392b">{_format_money(order.total)}</td>
    </tr>
  </tfoot>
</table>

<div class="notice-box">
  Сумма возврата прописью: {_number_to_words_short(order.total)} рублей 00 копеек.
</div>

<div class="sign-row">
  <div class="sign-block">
    <div class="role">Представитель продавца</div>
    <div class="line"></div>
    <div class="name">{COMPANY['director']}</div>
    <div style="margin-top:6px"><div class="stamp-area">М.П.</div></div>
  </div>
  <div class="sign-block">
    <div class="role">Покупатель</div>
    <div class="line"></div>
    <div class="name">{refund.user.name}</div>
    <div style="margin-top:28px;font-family:'PT Mono',monospace;font-size:10px;color:#888">
      Подпись ________________</div>
  </div>
</div>

<div class="footer">
  <span>Документ сформирован автоматически · {datetime.now().strftime('%d.%m.%Y %H:%M')}</span>
  <span>Заявка #{refund.id} · Заказ #{order.id} · loftdc.ru</span>
</div>"""

    return _wrap(f'Акт возврата {doc_num} от {doc_date} — LOFT DC', body)
