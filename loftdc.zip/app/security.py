"""
LOFT DC — Security
CSRF защита и rate limiting без сторонних зависимостей.
"""

import secrets
import hashlib
from datetime import datetime, timedelta
from functools import wraps
from flask import request, session, abort, g
from app import db


# ─── CSRF ────────────────────────────────────────────────────────────────────

def generate_csrf_token() -> str:
    """Генерирует или возвращает существующий CSRF токен из сессии."""
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']


def validate_csrf(token: str) -> bool:
    """Проверяет CSRF токен."""
    session_token = session.get('_csrf_token')
    if not session_token or not token:
        return False
    return secrets.compare_digest(session_token, token)


def csrf_protect(f):
    """Декоратор: проверяет CSRF токен для POST/PUT/DELETE запросов."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if request.method in ('POST', 'PUT', 'DELETE', 'PATCH'):
            token = (request.form.get('_csrf_token') or
                     request.headers.get('X-CSRF-Token') or
                     request.json.get('_csrf_token') if request.is_json else None)
            if not validate_csrf(token):
                abort(403)
        return f(*args, **kwargs)
    return decorated


# ─── RATE LIMITING ───────────────────────────────────────────────────────────

MAX_ATTEMPTS     = 5    # максимум попыток
BLOCK_MINUTES    = 15   # блокировка на N минут
WINDOW_MINUTES   = 10   # окно подсчёта попыток


def get_client_ip() -> str:
    """Получает реальный IP клиента."""
    if request.headers.get('X-Forwarded-For'):
        return request.headers['X-Forwarded-For'].split(',')[0].strip()
    return request.remote_addr or '0.0.0.0'


def check_login_rate_limit(email: str = '') -> tuple[bool, int]:
    """
    Проверяет не заблокирован ли IP/email.
    Возвращает (allowed: bool, wait_seconds: int).
    """
    from app.models import LoginAttempt
    ip       = get_client_ip()
    since    = datetime.utcnow() - timedelta(minutes=WINDOW_MINUTES)
    blocked_since = datetime.utcnow() - timedelta(minutes=BLOCK_MINUTES)

    # Считаем неудачные попытки за окно
    fail_count = LoginAttempt.query.filter(
        LoginAttempt.ip == ip,
        LoginAttempt.success == False,
        LoginAttempt.created_at >= since
    ).count()

    if fail_count >= MAX_ATTEMPTS:
        # Последняя неудачная попытка
        last = LoginAttempt.query.filter(
            LoginAttempt.ip == ip,
            LoginAttempt.success == False,
        ).order_by(LoginAttempt.created_at.desc()).first()

        if last and last.created_at >= blocked_since:
            wait = int((last.created_at + timedelta(minutes=BLOCK_MINUTES)
                        - datetime.utcnow()).total_seconds())
            return False, max(wait, 0)

    return True, 0


def record_login_attempt(email: str, success: bool):
    """Записывает попытку входа."""
    from app.models import LoginAttempt
    ip = get_client_ip()
    db.session.add(LoginAttempt(ip=ip, email=email, success=success))
    db.session.commit()

    # Чистим старые записи (старше 24 часов) периодически
    if secrets.randbelow(20) == 0:  # ~5% запросов
        cutoff = datetime.utcnow() - timedelta(hours=24)
        LoginAttempt.query.filter(LoginAttempt.created_at < cutoff).delete()
        db.session.commit()
