import os
os.environ['DATABASE_URL'] = 'sqlite:///' + os.path.join(os.path.dirname(os.path.abspath(__file__)), 'loftdc.db')

from app import create_app, db
from sqlalchemy import text

app = create_app()

with app.app_context():
    with db.engine.connect() as conn:
        migrations = [
            ("ALTER TABLE orders ADD COLUMN payment_status VARCHAR(20) DEFAULT 'pending'", "payment_status"),
            ("ALTER TABLE orders ADD COLUMN paid_at DATETIME", "paid_at"),
            ("CREATE TABLE IF NOT EXISTS delivery_confirm_codes (id INTEGER PRIMARY KEY, order_id INTEGER, user_id INTEGER, code VARCHAR(6), created_at DATETIME, used BOOLEAN DEFAULT 0, attempts INTEGER DEFAULT 0)", "delivery_confirm_codes"),
            ("CREATE TABLE IF NOT EXISTS password_reset_tokens (id INTEGER PRIMARY KEY, user_id INTEGER, token VARCHAR(100) UNIQUE, created_at DATETIME, used BOOLEAN DEFAULT 0)", "password_reset_tokens"),
            ("CREATE TABLE IF NOT EXISTS refund_requests (id INTEGER PRIMARY KEY, order_id INTEGER, user_id INTEGER, reason TEXT DEFAULT '', status VARCHAR(20) DEFAULT 'pending', admin_note TEXT DEFAULT '', created_at DATETIME, resolved_at DATETIME)", "refund_requests"),
            ("CREATE TABLE IF NOT EXISTS login_attempts (id INTEGER PRIMARY KEY, ip VARCHAR(45), email VARCHAR(120) DEFAULT '', success BOOLEAN DEFAULT 0, created_at DATETIME)", "login_attempts"),
            ("CREATE TABLE IF NOT EXISTS product_images (id INTEGER PRIMARY KEY, product_id INTEGER REFERENCES products(id), filename VARCHAR(200), sort_order INTEGER DEFAULT 0, created_at DATETIME)", "product_images"),
            ("CREATE TABLE IF NOT EXISTS finance_transactions (id INTEGER PRIMARY KEY, type VARCHAR(20) NOT NULL, amount INTEGER NOT NULL, description VARCHAR(255) DEFAULT '', order_id INTEGER, user_id INTEGER, created_at DATETIME)", "finance_transactions"),
            ("CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY, title VARCHAR(200) NOT NULL, type VARCHAR(50) NOT NULL, period_from DATETIME, period_to DATETIME, created_by INTEGER, created_at DATETIME, params TEXT DEFAULT '{}')", "reports"),
        ]
        for sql, name in migrations:
            try:
                conn.execute(text(sql))
                print(f"+ {name}")
            except Exception as e:
                print(f"  {name}: {e}")
        conn.commit()
        print("Готово! Перезапусти run.py")
