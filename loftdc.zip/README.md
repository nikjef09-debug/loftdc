# LOFT DC — Flask + SQLite Backend

## Структура проекта

```
loftdc/
├── run.py                          # Точка входа
├── config.py                       # Конфигурация (SECRET_KEY, БД, uploads)
├── requirements.txt                # Зависимости Python
├── instance/
│   └── loftdc.db                   # SQLite БД (создаётся автоматически)
└── app/
    ├── __init__.py                 # Фабрика + автозаполнение БД
    ├── models.py                   # 8 таблиц БД
    ├── routes/
    │   ├── main.py                 # /, /about, /delivery, /faq, /contacts
    │   ├── auth.py                 # /auth/login, /register, /logout, /profile
    │   ├── catalog.py              # /catalog/, /catalog/<id>
    │   ├── cart.py                 # /cart/, /cart/add, /wish
    │   ├── orders.py               # /orders/checkout
    │   ├── blog.py                 # /blog/, /blog/<id>
    │   ├── admin.py                # /admin/* (панель управления)
    │   └── api.py                  # /api/review, /api/contact, /api/coupon
    ├── templates/                  # Jinja2-шаблоны
    └── static/
        ├── css/main.css            # Полный CSS (черно-белый лофт-дизайн)
        └── js/main.js              # JS: меню, анимации, карта, FAQ
```

## База данных (8 таблиц)

| Таблица      | Описание                              |
|--------------|---------------------------------------|
| users        | Пользователи с ролями                 |
| products     | Товары каталога (12 позиций)          |
| orders       | Заказы                                |
| order_items  | Позиции заказов                       |
| reviews      | Отзывы к товарам                      |
| articles     | Статьи журнала (6 штук)              |
| coupons      | Промокоды                             |
| wishlists    | Избранное пользователей               |
| messages     | Сообщения с формы контактов           |

## Роли пользователей

| Роль    | Доступ                                                              |
|---------|---------------------------------------------------------------------|
| admin   | Полный доступ: товары, заказы, пользователи, промокоды, статьи      |
| manager | Товары, заказы, статьи, отзывы, сообщения (без пользователей/купонов)|
| user    | Просмотр сайта, корзина, заказы, избранное, отзывы                  |

## Быстрый старт

### 1. Установить зависимости
```bash
pip install -r requirements.txt
```

### 2. Запустить
```bash
python run.py
```

Откройте: **http://localhost:5000**

БД и тестовые данные создаются **автоматически** при первом запуске.

## Тестовые аккаунты

| Email                | Пароль      | Роль      |
|----------------------|-------------|-----------|
| admin@loftdc.ru      | admin123    | admin     |
| manager@loftdc.ru    | manager123  | manager   |
| user@loftdc.ru       | user123     | user      |

## URL-адреса

| Адрес                    | Описание                        |
|--------------------------|---------------------------------|
| /                        | Главная страница                |
| /catalog/                | Каталог товаров                 |
| /catalog/<id>            | Карточка товара                 |
| /cart/                   | Корзина                         |
| /orders/checkout         | Оформление заказа               |
| /blog/                   | Журнал                          |
| /blog/<id>               | Статья журнала                  |
| /about                   | О компании                      |
| /delivery                | Доставка и оплата               |
| /faq                     | Частые вопросы                  |
| /contacts                | Контакты                        |
| /auth/login              | Вход                            |
| /auth/register           | Регистрация                     |
| /auth/profile            | Личный кабинет                  |
| /admin/                  | Панель управления               |
| /admin/products          | Управление товарами             |
| /admin/orders            | Управление заказами             |
| /admin/users             | Пользователи (admin only)       |
| /admin/reviews           | Отзывы                          |
| /admin/articles          | Статьи журнала                  |
| /admin/messages          | Сообщения                       |
| /admin/coupons           | Промокоды (admin only)          |
| /admin/orders/export     | Экспорт заказов в CSV           |

## Промокоды (встроенные)

- `LOFT10` — скидка 10%
- `SALE15` — скидка 15%
- `FIRST20` — скидка 20%
