"""
Запусти один раз: python backfill_finance.py
Заполняет таблицу finance_transactions данными из существующих заказов.
"""
import os
os.environ['DATABASE_URL'] = 'sqlite:///' + os.path.join(os.path.dirname(os.path.abspath(__file__)), 'loftdc.db')

from app import create_app, db
from app.models import Order, RefundRequest, FinanceTransaction
from sqlalchemy import text

app = create_app()

with app.app_context():
    added = 0
    skipped = 0

    # Все заказы у которых нет транзакции
    orders = Order.query.filter(Order.status != 'Отменён').all()
    for o in orders:
        # Проверяем — есть ли уже транзакция для этого заказа
        exists = FinanceTransaction.query.filter_by(order_id=o.id, type='income').first()
        if exists:
            skipped += 1
            continue

        # Добавляем транзакцию прихода
        t = FinanceTransaction(
            type='income',
            amount=o.total,
            description=f'Оплата заказа #{o.id} (восстановлено)',
            order_id=o.id,
            user_id=o.user_id,
        )
        # Дата = дата заказа
        t.created_at = o.created_at
        db.session.add(t)
        added += 1
        print(f'  + Заказ #{o.id}: {o.total} ₽ ({o.created_at.strftime("%d.%m.%Y")})')

    # Одобренные возвраты
    refunds = RefundRequest.query.filter_by(status='approved').all()
    for r in refunds:
        exists = FinanceTransaction.query.filter_by(order_id=r.order_id, type='refund').first()
        if exists:
            skipped += 1
            continue
        t = FinanceTransaction(
            type='refund',
            amount=r.order.total,
            description=f'Возврат по заказу #{r.order_id} (восстановлено)',
            order_id=r.order_id,
            user_id=r.user_id,
        )
        t.created_at = r.resolved_at or r.created_at
        db.session.add(t)
        added += 1
        print(f'  + Возврат #{r.id}: {r.order.total} ₽')

    db.session.commit()
    print(f'\nГотово! Добавлено: {added}, пропущено (уже есть): {skipped}')
    print('Перезапусти run.py')
