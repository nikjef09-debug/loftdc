"""
Запусти этот файл один раз: python patch_pdf.py
Он исправит pdf_generator.py прямо на диске.
"""
import os
import re

path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app', 'pdf_generator.py')

if not os.path.exists(path):
    print(f'ОШИБКА: файл не найден: {path}')
    exit(1)

content = open(path, encoding='utf-8').read()

# Проверяем — уже исправлен?
if 'ones_m =' in content and 'def _register_fonts' in content:
    print('pdf_generator.py уже содержит исправления.')
    exit(0)

# ── Новая функция _words ──────────────────────────────────────────────────────
NEW_WORDS = '''def _words(n: int) -> str:
    """Сумма прописью — корректно для любых сумм."""
    if n == 0: return 'Ноль'
    ones_m = ['','Один','Два','Три','Четыре','Пять','Шесть','Семь','Восемь','Девять']
    ones_f = ['','Одна','Две','Три','Четыре','Пять','Шесть','Семь','Восемь','Девять']
    teen   = ['Десять','Одиннадцать','Двенадцать','Тринадцать','Четырнадцать',
              'Пятнадцать','Шестнадцать','Семнадцать','Восемнадцать','Девятнадцать']
    tens_  = ['','','Двадцать','Тридцать','Сорок','Пятьдесят',
              'Шестьдесят','Семьдесят','Восемьдесят','Девяносто']
    hunds  = ['','Сто','Двести','Триста','Четыреста','Пятьсот',
              'Шестьсот','Семьсот','Восемьсот','Девятьсот']
    def chunk(x, fem=False):
        r = []
        if x >= 100: r.append(hunds[x // 100]); x %= 100
        if 10 <= x <= 19: r.append(teen[x - 10]); return ' '.join(filter(None, r))
        if x >= 20: r.append(tens_[x // 10]); x %= 10
        if x > 0: r.append(ones_f[x] if fem else ones_m[x])
        return ' '.join(filter(None, r))
    def suf_t(t):
        r = t % 100; r = t % 10 if not (11 <= r <= 19) else 20
        return 'тысяч' if r in (0,5,6,7,8,9,20) else ('тысяча' if r == 1 else 'тысячи')
    def suf_m(m):
        r = m % 100; r = m % 10 if not (11 <= r <= 19) else 20
        return 'миллионов' if r in (0,5,6,7,8,9,20) else ('миллион' if r == 1 else 'миллиона')
    parts = []
    if n >= 1000000: m = n // 1000000; parts.append(f'{chunk(m)} {suf_m(m)}'); n %= 1000000
    if n >= 1000: t = n // 1000; parts.append(f'{chunk(t, True)} {suf_t(t)}'); n %= 1000
    if n > 0: parts.append(chunk(n))
    return ' '.join(filter(None, parts)).capitalize()

'''

# ── Регистрация кириллического шрифта ────────────────────────────────────────
FONT_REGISTRATION = '''
import os as _os

def _register_fonts():
    candidates = [
        ('C:/Windows/Fonts/arial.ttf',   'C:/Windows/Fonts/arialbd.ttf'),
        ('C:/Windows/Fonts/Arial.ttf',   'C:/Windows/Fonts/Arialbd.ttf'),
        ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
         '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
    ]
    for reg, bld in candidates:
        if _os.path.exists(reg):
            try:
                pdfmetrics.registerFont(TTFont('CyrFont', reg))
                pdfmetrics.registerFont(TTFont('CyrFont-Bold', bld if _os.path.exists(bld) else reg))
                return 'CyrFont', 'CyrFont-Bold'
            except Exception:
                continue
    return 'Helvetica', 'Helvetica-Bold'

_FONT, _FONT_BOLD = _register_fonts()

'''

# ── Применяем патчи ───────────────────────────────────────────────────────────
backup = path + '.bak'
open(backup, 'w', encoding='utf-8').write(content)
print(f'Резервная копия: {backup}')

# 1. Заменяем _words
old_words_pattern = re.compile(
    r'def _words\(n: int\).*?return \S.*?\n(?=\n)',
    re.DOTALL
)
if old_words_pattern.search(content):
    content = old_words_pattern.sub(NEW_WORDS, content, count=1)
    print('+ _words заменена')
else:
    # Вставляем перед def _base_styles
    content = content.replace('def _base_styles()', NEW_WORDS + 'def _base_styles()', 1)
    print('+ _words вставлена перед _base_styles')

# 2. Добавляем регистрацию шрифта после импортов (перед переменными цветов)
if '_FONT, _FONT_BOLD' not in content:
    # Вставляем после строки с BLACK =
    content = content.replace(
        'BLACK   = colors.HexColor',
        FONT_REGISTRATION + 'BLACK   = colors.HexColor',
        1
    )
    print('+ регистрация шрифта добавлена')

# 3. Заменяем Helvetica на _FONT
replacements = [
    ("'Helvetica-Bold'", '_FONT_BOLD'),
    ('"Helvetica-Bold"', '_FONT_BOLD'),
    ("'Helvetica'",      '_FONT'),
    ('"Helvetica"',      '_FONT'),
]
for old, new in replacements:
    count = content.count(old)
    if count:
        content = content.replace(old, new)
        print(f'+ {old} → {new} ({count} замен)')

# Пишем результат
open(path, 'w', encoding='utf-8').write(content)
print(f'\nГотово! Файл обновлён: {path}')
print('Перезапусти run.py')
