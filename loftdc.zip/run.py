import os
import sys
import webbrowser
from threading import Timer

# ── Определяем базовую директорию ────────────────────────────────────────────
# При запуске из .exe (PyInstaller) — папка рядом с exe-файлом
# При обычном запуске python run.py — папка проекта
if getattr(sys, 'frozen', False):
    # Запущено как .exe
    BASE_DIR = os.path.dirname(sys.executable)
else:
    # Обычный запуск
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Кладём БД рядом с exe (или рядом с run.py при разработке)
DB_PATH = os.path.join(BASE_DIR, 'loftdc.db')
os.environ['DATABASE_URL'] = f'sqlite:///{DB_PATH}'

# Загружаем .env если есть (ищем рядом с exe/run.py)
try:
    from dotenv import load_dotenv
    env_path = os.path.join(BASE_DIR, '.env')
    if os.path.exists(env_path):
        load_dotenv(env_path)
except ImportError:
    pass

from app import create_app

app = create_app()

def open_browser():
    webbrowser.open('http://127.0.0.1:5001')

if __name__ == '__main__':
    print(f'[LOFT DC] БД: {DB_PATH}')
    print(f'[LOFT DC] Сервер: http://127.0.0.1:5001')
    Timer(1.5, open_browser).start()
    app.run(
        host='127.0.0.1',
        port=5001,
        debug=False,
        use_reloader=False,
    )
