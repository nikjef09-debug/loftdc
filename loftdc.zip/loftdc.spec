# -*- mode: python ; coding: utf-8 -*-
import os

block_cipher = None

arial_fonts = []
for fname in ['arial.ttf', 'arialbd.ttf', 'Arial.ttf', 'Arialbd.ttf']:
    fpath = f'C:/Windows/Fonts/{fname}'
    if os.path.exists(fpath):
        arial_fonts.append((fpath, 'fonts'))

a = Analysis(
    ['run.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('app/static',    'app/static'),
        ('app/templates', 'app/templates'),
    ] + arial_fonts,
    hiddenimports=[
        'flask', 'flask_sqlalchemy', 'flask_login',
        'werkzeug', 'werkzeug.security', 'werkzeug.utils',
        'sqlalchemy', 'sqlalchemy.dialects.sqlite',
        'sqlalchemy.ext.declarative', 'sqlalchemy.orm', 'sqlalchemy.pool',
        'jinja2', 'jinja2.ext', 'markupsafe',
        'smtplib', 'email', 'email.mime', 'email.mime.multipart',
        'email.mime.text', 'email.mime.base', 'email.encoders', 'email.utils',
        'dotenv',
        'secrets', 'csv', 'io', 'random', 'string', 'threading', 'webbrowser',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tkinter', 'matplotlib', 'numpy', 'pandas',
        'PyQt5', 'PyQt6', 'wx',
        'reportlab', 'PIL', 'Pillow',
    ],
    noarchive=False,
    optimize=0,
    cipher=block_cipher,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='loftdc',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)
